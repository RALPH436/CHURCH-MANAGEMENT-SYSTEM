<?php
session_start();
include "db.php";

$message = '';
$messageType = '';
$showForm = false;

// Handle reset code verification and password update
if (isset($_POST['reset_password'])) {
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $reset_code = mysqli_real_escape_string($conn, $_POST['reset_code']);
    $new_password = $_POST['new_password'];
    $confirm_password = $_POST['confirm_password'];
    
    // Validate passwords match
    if ($new_password !== $confirm_password) {
        $message = 'Passwords do not match.';
        $messageType = 'error';
        $showForm = true;
    } elseif (strlen($new_password) < 6) {
        $message = 'Password must be at least 6 characters long.';
        $messageType = 'error';
        $showForm = true;
    } else {
        // Check if reset code is valid
        $query = "SELECT id, password_reset_code, password_reset_expiry FROM users WHERE email = '$email' AND password_reset_code = '$reset_code'";
        $result = mysqli_query($conn, $query);
        
        if (mysqli_num_rows($result) == 1) {
            $user = mysqli_fetch_assoc($result);
            
            // Check if code has expired
            $now = date('Y-m-d H:i:s');
            if (strtotime($user['password_reset_expiry']) < strtotime($now)) {
                $message = 'Reset code has expired. Please request a new one.';
                $messageType = 'error';
            } else {
                // Update password
                $hashed_password = md5($new_password);
                $updateQuery = "UPDATE users SET password = '$hashed_password', password_reset_code = NULL, password_reset_expiry = NULL WHERE email = '$email'";
                
                if (mysqli_query($conn, $updateQuery)) {
                    $message = 'Password has been reset successfully! You can now login with your new password.';
                    $messageType = 'success';
                    $showForm = false;
                } else {
                    $message = 'Error updating password. Please try again.';
                    $messageType = 'error';
                    $showForm = true;
                }
            }
        } else {
            $message = 'Invalid reset code or email address.';
            $messageType = 'error';
            $showForm = true;
        }
    }
} elseif (isset($_GET['email']) && isset($_GET['code'])) {
    // Pre-fill form if coming from email link
    $email = mysqli_real_escape_string($conn, $_GET['email']);
    $reset_code = mysqli_real_escape_string($conn, $_GET['code']);
    $showForm = true;
} else {
    $showForm = true;
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Reset Password</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body { 
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; 
            background: linear-gradient(to bottom, #0a1929 0%, #1a2f4a 50%, #0f1b2e 100%);
            margin: 0;
            padding: 0;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            position: relative;
            overflow: hidden;
        }
        body::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-image: 
                radial-gradient(2px 2px at 20% 30%, white, transparent),
                radial-gradient(2px 2px at 60% 70%, white, transparent),
                radial-gradient(1px 1px at 50% 50%, white, transparent),
                radial-gradient(1px 1px at 80% 10%, white, transparent),
                radial-gradient(2px 2px at 90% 60%, white, transparent),
                radial-gradient(1px 1px at 33% 80%, white, transparent),
                radial-gradient(1px 1px at 15% 50%, white, transparent),
                radial-gradient(2px 2px at 70% 20%, white, transparent),
                radial-gradient(1px 1px at 40% 90%, white, transparent);
            background-size: 200% 200%;
            background-position: 0 0, 100% 0, 50% 50%, 0 100%, 100% 100%;
            opacity: 0.6;
            animation: twinkle 20s linear infinite;
        }
        body::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 0;
            width: 100%;
            height: 40%;
            background: linear-gradient(to top, #1a1a2e 0%, transparent 100%);
            clip-path: polygon(0% 100%, 100% 100%, 100% 60%, 90% 55%, 80% 50%, 70% 45%, 60% 40%, 50% 35%, 40% 30%, 30% 25%, 20% 20%, 10% 15%, 0% 10%);
        }
        @keyframes twinkle {
            0%, 100% { opacity: 0.6; }
            50% { opacity: 0.8; }
        }
        .container {
            width: 450px;
            max-width: 95%;
            background: #fff;
            border-radius: 12px;
            box-shadow: 0 20px 60px rgba(0, 0, 0, 0.5);
            overflow: hidden;
            position: relative;
            z-index: 1;
            padding: 50px;
        }
        .form-header {
            margin-bottom: 35px;
            text-align: center;
        }
        .form-header h2 {
            font-size: 36px;
            font-weight: 700;
            color: #000;
            text-transform: uppercase;
            margin-bottom: 10px;
        }
        .form-header p {
            color: #666;
            font-size: 14px;
        }
        .form-group {
            margin-bottom: 20px;
        }
        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 500;
            color: #333;
            font-size: 14px;
        }
        .form-group input {
            width: 100%;
            padding: 14px;
            border: 1px solid #e0e0e0;
            border-radius: 4px;
            font-size: 15px;
            color: #424242;
            background: #fff;
            transition: border-color 0.3s;
        }
        .form-group input:focus {
            outline: none;
            border-color: #2D7A8F;
        }
        .form-group input::placeholder {
            color: #9e9e9e;
        }
        .password-wrapper {
            position: relative;
        }
        .password-toggle {
            position: absolute;
            right: 12px;
            top: 50%;
            transform: translateY(-50%);
            background: none;
            border: none;
            cursor: pointer;
            color: #9e9e9e;
            font-size: 18px;
            padding: 5px;
        }
        .submit-button {
            width: 100%;
            padding: 14px;
            background: #2D7A8F;
            color: white;
            border: none;
            border-radius: 4px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: background-color 0.3s;
            margin-bottom: 15px;
        }
        .submit-button:hover {
            background: #1F5F6F;
        }
        .back-link {
            display: block;
            text-align: center;
            color: #2D7A8F;
            font-size: 14px;
            text-decoration: none;
            transition: color 0.3s;
        }
        .back-link:hover {
            color: #1F5F6F;
        }
        .message {
            padding: 12px 20px;
            border-radius: 4px;
            margin-bottom: 20px;
            font-size: 14px;
        }
        .message.success {
            background: #e8f5e9;
            color: #2e7d32;
            border-left: 3px solid #2e7d32;
        }
        .message.error {
            background: #ffebee;
            color: #d32f2f;
            border-left: 3px solid #d32f2f;
        }
    </style>
</head>
<body>

<div class="container">
    <div class="form-header">
        <h2>Reset Password</h2>
        <p>Enter your reset code and new password</p>
    </div>
    
    <?php if (!empty($message)): ?>
        <div class="message <?php echo $messageType; ?>">
            <?php echo htmlspecialchars($message); ?>
        </div>
    <?php endif; ?>

    <?php if ($showForm && $messageType !== 'success'): ?>
        <form method="POST" id="resetForm">
            <div class="form-group">
                <label for="email">Email Address</label>
                <input type="email" id="email" name="email" placeholder="Enter your email" value="<?php echo isset($email) ? htmlspecialchars($email) : ''; ?>" required>
            </div>
            
            <div class="form-group">
                <label for="reset_code">Reset Code</label>
                <input type="text" id="reset_code" name="reset_code" placeholder="Enter 6-digit code" value="<?php echo isset($reset_code) ? htmlspecialchars($reset_code) : ''; ?>" maxlength="6" pattern="[0-9]{6}" required>
            </div>
            
            <div class="form-group">
                <label for="new_password">New Password</label>
                <div class="password-wrapper">
                    <input type="password" id="new_password" name="new_password" placeholder="Enter new password" minlength="6" required>
                    <button type="button" class="password-toggle" onclick="togglePassword('new_password')">👁</button>
                </div>
            </div>
            
            <div class="form-group">
                <label for="confirm_password">Confirm Password</label>
                <div class="password-wrapper">
                    <input type="password" id="confirm_password" name="confirm_password" placeholder="Confirm new password" minlength="6" required>
                    <button type="button" class="password-toggle" onclick="togglePassword('confirm_password')">👁</button>
                </div>
            </div>
            
            <button type="submit" name="reset_password" class="submit-button">Reset Password</button>
            
            <a href="login.php" class="back-link">Back to Login</a>
        </form>
    <?php elseif ($messageType === 'success'): ?>
        <div style="text-align: center;">
            <a href="login.php" class="submit-button" style="text-decoration: none; display: inline-block;">Go to Login</a>
        </div>
    <?php else: ?>
        <a href="forgot_password.php" class="back-link">Request New Reset Code</a>
    <?php endif; ?>
</div>

<script>
function togglePassword(inputId) {
    const passwordInput = document.getElementById(inputId);
    const toggleButton = passwordInput.nextElementSibling;
    if (passwordInput.type === 'password') {
        passwordInput.type = 'text';
        toggleButton.textContent = '👁️';
    } else {
        passwordInput.type = 'password';
        toggleButton.textContent = '👁';
    }
}

// Auto-format reset code input
document.addEventListener('DOMContentLoaded', function() {
    const resetCodeInput = document.getElementById('reset_code');
    if (resetCodeInput) {
        resetCodeInput.addEventListener('input', function(e) {
            e.target.value = e.target.value.replace(/[^0-9]/g, '');
        });
    }
});
</script>

</body>
</html>







