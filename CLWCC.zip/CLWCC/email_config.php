<?php
// Email Configuration for Password Reset
// IMPORTANT: Update these values with your Gmail credentials

// Gmail SMTP Settings
define('SMTP_HOST', 'smtp.gmail.com');
define('SMTP_PORT', 587);
define('SMTP_USERNAME', 'ralphtomespiritu@gmail.com'); // Your Gmail address
define('SMTP_PASSWORD', 'llhw foae qlyp leof'); // Your Gmail App Password (not regular password)
define('SMTP_FROM_EMAIL', 'ralphtomespiritu@gmail.com'); // Sender email (usually same as username)
define('SMTP_FROM_NAME', 'Church Management System'); // Sender name

/*
 * SETUP INSTRUCTIONS:
 * 
 * 1. Enable 2-Step Verification on your Google Account:
 *    - Go to https://myaccount.google.com/security
 *    - Enable 2-Step Verification
 * 
 * 2. Generate an App Password:
 *    - Go to https://myaccount.google.com/apppasswords
 *    - Select "Mail" and "Other (Custom name)"
 *    - Enter "Church Management System" as the name
 *    - Click "Generate"
 *    - Copy the 16-character password (no spaces)
 *    - Paste it in SMTP_PASSWORD above
 * 
 * 3. Update SMTP_USERNAME and SMTP_FROM_EMAIL with your Gmail address
 * 
 * 4. Save this file
 */

?>






