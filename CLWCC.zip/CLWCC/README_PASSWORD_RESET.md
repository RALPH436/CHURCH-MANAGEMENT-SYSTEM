# Password Reset Setup Instructions

## Overview
The forgot password functionality has been implemented with Gmail integration. Users can request a password reset code via email and use it to set a new password.

## Setup Steps

### 1. Install PHPMailer (Recommended)

PHPMailer provides better email delivery and error handling. To install:

**Option A: Using Composer (Recommended)**
```bash
composer require phpmailer/phpmailer
```

**Option B: Manual Installation**
1. Download PHPMailer from: https://github.com/PHPMailer/PHPMailer
2. Extract the files
3. Create a folder named `PHPMailer` in your project root
4. Copy the following files from PHPMailer/src to your PHPMailer folder:
   - PHPMailer.php
   - SMTP.php
   - Exception.php

### 2. Configure Gmail Settings

1. **Enable 2-Step Verification:**
   - Go to https://myaccount.google.com/security
   - Enable 2-Step Verification if not already enabled

2. **Generate App Password:**
   - Go to https://myaccount.google.com/apppasswords
   - Select "Mail" and "Other (Custom name)"
   - Enter "Church Management System" as the name
   - Click "Generate"
   - Copy the 16-character password (it will look like: `abcd efgh ijkl mnop`)
   - Remove spaces when using it

3. **Update email_config.php:**
   - Open `email_config.php`
   - Replace `your-email@gmail.com` with your Gmail address
   - Replace `your-app-password` with the 16-character app password (no spaces)
   - Save the file

### 3. Database Setup

The system will automatically add the required columns to your `users` table:
- `password_reset_code` - Stores the 6-digit reset code
- `password_reset_expiry` - Stores when the code expires (15 minutes)

No manual database changes needed!

## How It Works

1. **User requests reset:**
   - User clicks "Forgot password?" on login page
   - Enters their email address
   - System generates a 6-digit code
   - Code is sent via email (valid for 15 minutes)

2. **User resets password:**
   - User enters email, reset code, and new password
   - System validates the code and expiry time
   - Password is updated if valid

## Files Created

- `forgot_password.php` - Page where users request password reset
- `reset_password.php` - Page where users enter code and new password
- `email_config.php` - Email configuration file
- Updated `login.php` - Added link to forgot password page

## Security Features

- Reset codes expire after 15 minutes
- Codes are 6-digit random numbers
- Codes are cleared after successful password reset
- Passwords are hashed using MD5 (matching your existing system)

## Troubleshooting

### Email not sending?
1. Check that PHPMailer is installed correctly
2. Verify Gmail app password is correct (no spaces)
3. Ensure 2-Step Verification is enabled
4. Check that SMTP settings in `email_config.php` are correct
5. Check server error logs for detailed error messages

### Code not working?
1. Make sure the code hasn't expired (15 minutes)
2. Verify the email address matches exactly
3. Check that the code was entered correctly (6 digits)

## Testing

1. Go to login page
2. Click "Forgot password?"
3. Enter a valid email from your users table
4. Check email inbox for reset code
5. Go to reset password page (or use link from email)
6. Enter code and new password
7. Login with new password

## Notes

- The system uses MD5 hashing to match your existing password storage
- Reset codes are single-use (cleared after successful reset)
- If PHPMailer is not installed, the system will attempt to use PHP's built-in `mail()` function







