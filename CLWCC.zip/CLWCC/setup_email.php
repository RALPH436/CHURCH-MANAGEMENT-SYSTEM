<?php
session_start();
$message = '';
$messageType = '';
$currentConfig = [];

// Read current configuration
if (file_exists('email_config.php')) {
    $configContent = file_get_contents('email_config.php');
    preg_match("/define\('SMTP_USERNAME',\s*'([^']+)'/", $configContent, $usernameMatch);
    preg_match("/define\('SMTP_PASSWORD',\s*'([^']+)'/", $configContent, $passwordMatch);
    preg_match("/define\('SMTP_FROM_EMAIL',\s*'([^']+)'/", $configContent, $emailMatch);
    
    $currentConfig['username'] = isset($usernameMatch[1]) ? $usernameMatch[1] : '';
    $currentConfig['password'] = isset($passwordMatch[1]) ? $passwordMatch[1] : '';
    $currentConfig['from_email'] = isset($emailMatch[1]) ? $emailMatch[1] : '';
}

// Handle form submission
if (isset($_POST['save_config'])) {
    $smtp_username = trim($_POST['smtp_username']);
    $smtp_password = trim($_POST['smtp_password']);
    $smtp_from_email = trim($_POST['smtp_from_email']);
    $smtp_from_name = trim($_POST['smtp_from_name']) ?: 'Church Management System';
    
    // Validate
    if (empty($smtp_username) || empty($smtp_password) || empty($smtp_from_email)) {
        $message = 'Please fill in all required fields.';
        $messageType = 'error';
    } elseif (!filter_var($smtp_username, FILTER_VALIDATE_EMAIL) || !filter_var($smtp_from_email, FILTER_VALIDATE_EMAIL)) {
        $message = 'Please enter valid email addresses.';
        $messageType = 'error';
    } else {
        // Create new config file
        $configContent = "<?php
// Email Configuration for Password Reset
// IMPORTANT: Update these values with your Gmail credentials

// Gmail SMTP Settings
define('SMTP_HOST', 'smtp.gmail.com');
define('SMTP_PORT', 587);
define('SMTP_USERNAME', '" . addslashes($smtp_username) . "'); // Your Gmail address
define('SMTP_PASSWORD', '" . addslashes($smtp_password) . "'); // Your Gmail App Password (not regular password)
define('SMTP_FROM_EMAIL', '" . addslashes($smtp_from_email) . "'); // Sender email (usually same as username)
define('SMTP_FROM_NAME', '" . addslashes($smtp_from_name) . "'); // Sender name

/*
 * SETUP INSTRUCTIONS:
 * 
 * 1. Enable 2-Step Verification on your Google Account:
 *    - Go to https://myaccount.google.com/security
 *    - Enable 2-Step Verification
 * 
 * 2. Generate an App Password:
 *    - Go to https://myaccount.google.com/apppasswords
 *    - Select \"Mail\" and \"Other (Custom name)\"
 *    - Enter \"Church Management System\" as the name
 *    - Click \"Generate\"
 *    - Copy the 16-character password (no spaces)
 *    - Paste it in SMTP_PASSWORD above
 * 
 * 3. Update SMTP_USERNAME and SMTP_FROM_EMAIL with your Gmail address
 * 
 * 4. Save this file
 */

?>
";
        
        if (file_put_contents('email_config.php', $configContent)) {
            $message = 'Email configuration saved successfully! You can now test the password reset feature.';
            $messageType = 'success';
            
            // Update current config for display
            $currentConfig['username'] = $smtp_username;
            $currentConfig['password'] = '••••••••'; // Hide password
            $currentConfig['from_email'] = $smtp_from_email;
        } else {
            $message = 'Error: Could not save configuration file. Please check file permissions.';
            $messageType = 'error';
        }
    }
}

// Test email functionality
if (isset($_POST['test_email'])) {
    $test_email = trim($_POST['test_email']);
    
    if (empty($test_email) || !filter_var($test_email, FILTER_VALIDATE_EMAIL)) {
        $message = 'Please enter a valid email address for testing.';
        $messageType = 'error';
    } else {
        require_once 'email_config.php';
        
        if (file_exists('PHPMailer/PHPMailer.php')) {
            require_once 'PHPMailer/PHPMailer.php';
            require_once 'PHPMailer/SMTP.php';
            require_once 'PHPMailer/Exception.php';
            
            $mail = new \PHPMailer\PHPMailer\PHPMailer(true);
            
            try {
                $mail->isSMTP();
                $mail->Host       = SMTP_HOST;
                $mail->SMTPAuth   = true;
                $mail->Username   = SMTP_USERNAME;
                $mail->Password   = SMTP_PASSWORD;
                $mail->SMTPSecure = \PHPMailer\PHPMailer\PHPMailer::ENCRYPTION_STARTTLS;
                $mail->Port       = SMTP_PORT;
                $mail->CharSet    = 'UTF-8';
                
                $mail->setFrom(SMTP_FROM_EMAIL, SMTP_FROM_NAME);
                $mail->addAddress($test_email);
                
                $mail->isHTML(true);
                $mail->Subject = 'Test Email - Church Management System';
                $mail->Body    = '<html><body><h2>Email Configuration Test</h2><p>Congratulations! Your email configuration is working correctly.</p><p>You can now use the password reset feature.</p></body></html>';
                $mail->AltBody = 'Email Configuration Test - Your email is working correctly!';
                
                $mail->send();
                $message = 'Test email sent successfully to ' . htmlspecialchars($test_email) . '! Please check your inbox.';
                $messageType = 'success';
            } catch (\PHPMailer\PHPMailer\Exception $e) {
                $message = 'Failed to send test email. Error: ' . htmlspecialchars($mail->ErrorInfo);
                $messageType = 'error';
            }
        } else {
            $message = 'PHPMailer is not installed. Please install PHPMailer first.';
            $messageType = 'error';
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Email Configuration Setup</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(to bottom, #0a1929 0%, #1a2f4a 50%, #0f1b2e 100%);
            min-height: 100vh;
            padding: 20px;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .container {
            width: 600px;
            max-width: 100%;
            background: #fff;
            border-radius: 12px;
            box-shadow: 0 20px 60px rgba(0, 0, 0, 0.5);
            padding: 40px;
        }
        h1 {
            color: #2D7A8F;
            margin-bottom: 10px;
            font-size: 28px;
        }
        .subtitle {
            color: #666;
            margin-bottom: 30px;
            font-size: 14px;
        }
        .form-group {
            margin-bottom: 20px;
        }
        label {
            display: block;
            margin-bottom: 8px;
            color: #333;
            font-weight: 600;
            font-size: 14px;
        }
        .required {
            color: #d32f2f;
        }
        input[type="email"],
        input[type="text"],
        input[type="password"] {
            width: 100%;
            padding: 12px;
            border: 1px solid #e0e0e0;
            border-radius: 4px;
            font-size: 15px;
            transition: border-color 0.3s;
        }
        input:focus {
            outline: none;
            border-color: #2D7A8F;
        }
        .help-text {
            font-size: 12px;
            color: #666;
            margin-top: 5px;
        }
        .help-text a {
            color: #2D7A8F;
            text-decoration: none;
        }
        .help-text a:hover {
            text-decoration: underline;
        }
        .button {
            width: 100%;
            padding: 14px;
            background: #2D7A8F;
            color: white;
            border: none;
            border-radius: 4px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: background-color 0.3s;
            margin-bottom: 10px;
        }
        .button:hover {
            background: #1F5F6F;
        }
        .button-secondary {
            background: #666;
        }
        .button-secondary:hover {
            background: #555;
        }
        .message {
            padding: 12px 20px;
            border-radius: 4px;
            margin-bottom: 20px;
            font-size: 14px;
        }
        .message.success {
            background: #e8f5e9;
            color: #2e7d32;
            border-left: 3px solid #2e7d32;
        }
        .message.error {
            background: #ffebee;
            color: #d32f2f;
            border-left: 3px solid #d32f2f;
        }
        .instructions {
            background: #f5f5f5;
            padding: 20px;
            border-radius: 4px;
            margin-bottom: 30px;
            border-left: 4px solid #2D7A8F;
        }
        .instructions h3 {
            color: #2D7A8F;
            margin-bottom: 15px;
            font-size: 18px;
        }
        .instructions ol {
            margin-left: 20px;
            color: #555;
        }
        .instructions li {
            margin-bottom: 10px;
            line-height: 1.6;
        }
        .instructions a {
            color: #2D7A8F;
            text-decoration: none;
        }
        .instructions a:hover {
            text-decoration: underline;
        }
        .back-link {
            display: block;
            text-align: center;
            color: #2D7A8F;
            font-size: 14px;
            text-decoration: none;
            margin-top: 20px;
        }
        .back-link:hover {
            text-decoration: underline;
        }
        .test-section {
            margin-top: 30px;
            padding-top: 30px;
            border-top: 1px solid #e0e0e0;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Email Configuration Setup</h1>
        <p class="subtitle">Configure Gmail SMTP settings for password reset emails</p>
        
        <?php if (!empty($message)): ?>
            <div class="message <?php echo $messageType; ?>">
                <?php echo $message; ?>
            </div>
        <?php endif; ?>
        
        <div class="instructions">
            <h3>📋 Setup Instructions</h3>
            <ol>
                <li><strong>Enable 2-Step Verification:</strong><br>
                    Go to <a href="https://myaccount.google.com/security" target="_blank">Google Account Security</a> and enable 2-Step Verification</li>
                <li><strong>Generate App Password:</strong><br>
                    Go to <a href="https://myaccount.google.com/apppasswords" target="_blank">App Passwords</a>, select "Mail" → "Other", name it "Church Management System", and generate. Copy the 16-character password (remove spaces).</li>
                <li><strong>Enter your credentials below</strong> and click "Save Configuration"</li>
                <li><strong>Test your setup</strong> by sending a test email</li>
            </ol>
        </div>
        
        <form method="POST">
            <div class="form-group">
                <label>Gmail Address <span class="required">*</span></label>
                <input type="email" name="smtp_username" value="<?php echo htmlspecialchars($currentConfig['username'] != 'your-email@gmail.com' ? $currentConfig['username'] : ''); ?>" placeholder="your-email@gmail.com" required>
                <div class="help-text">Your Gmail address (same as SMTP_USERNAME)</div>
            </div>
            
            <div class="form-group">
                <label>Gmail App Password <span class="required">*</span></label>
                <input type="password" name="smtp_password" value="<?php echo htmlspecialchars($currentConfig['password'] != 'your-app-password' && $currentConfig['password'] != '••••••••' ? $currentConfig['password'] : ''); ?>" placeholder="Enter 16-character app password" required>
                <div class="help-text">The 16-character app password from Google (not your regular Gmail password)</div>
            </div>
            
            <div class="form-group">
                <label>From Email Address <span class="required">*</span></label>
                <input type="email" name="smtp_from_email" value="<?php echo htmlspecialchars($currentConfig['from_email'] != 'your-email@gmail.com' ? $currentConfig['from_email'] : ''); ?>" placeholder="your-email@gmail.com" required>
                <div class="help-text">Email address that will appear as sender (usually same as Gmail address)</div>
            </div>
            
            <div class="form-group">
                <label>From Name</label>
                <input type="text" name="smtp_from_name" value="Church Management System" placeholder="Church Management System">
                <div class="help-text">Name that will appear as sender</div>
            </div>
            
            <button type="submit" name="save_config" class="button">Save Configuration</button>
        </form>
        
        <div class="test-section">
            <h3 style="color: #2D7A8F; margin-bottom: 15px;">Test Email Configuration</h3>
            <form method="POST">
                <div class="form-group">
                    <label>Test Email Address</label>
                    <input type="email" name="test_email" placeholder="Enter email to send test message" required>
                    <div class="help-text">Enter an email address to receive a test message</div>
                </div>
                <button type="submit" name="test_email" class="button button-secondary">Send Test Email</button>
            </form>
        </div>
        
        <a href="login.php" class="back-link">← Back to Login</a>
    </div>
</body>
</html>







