<?php
session_start();
include "db.php";

$message = '';
$messageType = '';

// Handle password reset request
if (isset($_POST['request_reset'])) {
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    
    // Check if user exists
    $query = "SELECT id, fullname, email FROM users WHERE email = '$email'";
    $result = mysqli_query($conn, $query);
    
    if (mysqli_num_rows($result) == 1) {
        $user = mysqli_fetch_assoc($result);
        
        // Generate 6-digit reset code
        $reset_code = sprintf("%06d", mt_rand(0, 999999));
        
        // Set expiry time (15 minutes from now)
        $expiry = date('Y-m-d H:i:s', strtotime('+15 minutes'));
        
        // Check if password_reset_code column exists, if not add it
        $checkColumn = mysqli_query($conn, "SHOW COLUMNS FROM users LIKE 'password_reset_code'");
        if (mysqli_num_rows($checkColumn) == 0) {
            mysqli_query($conn, "ALTER TABLE users ADD COLUMN password_reset_code VARCHAR(10) DEFAULT NULL");
        }
        
        // Check if password_reset_expiry column exists, if not add it
        $checkExpiry = mysqli_query($conn, "SHOW COLUMNS FROM users LIKE 'password_reset_expiry'");
        if (mysqli_num_rows($checkExpiry) == 0) {
            mysqli_query($conn, "ALTER TABLE users ADD COLUMN password_reset_expiry DATETIME DEFAULT NULL");
        }
        
        // Store reset code in database
        $updateQuery = "UPDATE users SET password_reset_code = '$reset_code', password_reset_expiry = '$expiry' WHERE email = '$email'";
        mysqli_query($conn, $updateQuery);
        
        // Send email with reset code
        require_once 'email_config.php';
        
        // Check if email is configured before attempting to send
        $emailConfigured = (SMTP_USERNAME != 'your-email@gmail.com' && SMTP_PASSWORD != 'your-app-password');
        
        // Try to use PHPMailer if available and configured
        if (file_exists('PHPMailer/PHPMailer.php') && $emailConfigured) {
            require_once 'PHPMailer/PHPMailer.php';
            require_once 'PHPMailer/SMTP.php';
            require_once 'PHPMailer/Exception.php';
            
            $mail = new \PHPMailer\PHPMailer\PHPMailer(true);
            
            try {
                // Server settings
                $mail->isSMTP();
                $mail->Host       = SMTP_HOST;
                $mail->SMTPAuth   = true;
                $mail->Username   = SMTP_USERNAME;
                $mail->Password   = SMTP_PASSWORD;
                $mail->SMTPSecure = \PHPMailer\PHPMailer\PHPMailer::ENCRYPTION_STARTTLS;
                $mail->Port       = SMTP_PORT;
                $mail->CharSet    = 'UTF-8';
                
                // Recipients
                $mail->setFrom(SMTP_FROM_EMAIL, SMTP_FROM_NAME);
                $mail->addAddress($email, $user['fullname']);
                
                // Content
                $mail->isHTML(true);
                $mail->Subject = 'Password Reset Code - Church Management System';
                $mail->Body    = "
                <html>
                <head>
                    <style>
                        body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
                        .container { max-width: 600px; margin: 0 auto; padding: 20px; }
                        .header { background: #2D7A8F; color: white; padding: 20px; text-align: center; border-radius: 5px 5px 0 0; }
                        .content { background: #f9f9f9; padding: 30px; border-radius: 0 0 5px 5px; }
                        .code-box { background: #fff; border: 2px solid #2D7A8F; padding: 20px; text-align: center; margin: 20px 0; border-radius: 5px; }
                        .code { font-size: 32px; font-weight: bold; color: #2D7A8F; letter-spacing: 5px; }
                        .footer { text-align: center; margin-top: 20px; color: #666; font-size: 12px; }
                    </style>
                </head>
                <body>
                    <div class='container'>
                        <div class='header'>
                            <h2>Password Reset Request</h2>
                        </div>
                        <div class='content'>
                            <p>Hello " . htmlspecialchars($user['fullname']) . ",</p>
                            <p>You have requested to reset your password. Please use the following code to reset your password:</p>
                            <div class='code-box'>
                                <div class='code'>" . $reset_code . "</div>
                            </div>
                            <p><strong>This code will expire in 15 minutes.</strong></p>
                            <p>If you did not request this password reset, please ignore this email.</p>
                            <p>Best regards,<br>Church Management System</p>
                        </div>
                        <div class='footer'>
                            <p>This is an automated message. Please do not reply to this email.</p>
                        </div>
                    </div>
                </body>
                </html>
                ";
                $mail->AltBody = "Hello " . $user['fullname'] . ",\n\nYou have requested to reset your password. Your reset code is: " . $reset_code . "\n\nThis code will expire in 15 minutes.\n\nIf you did not request this password reset, please ignore this email.\n\nBest regards,\nChurch Management System";
                
                $mail->send();
                $message = 'Password reset code has been sent to your email address. Please check your inbox.';
                $messageType = 'success';
                // Clear any display code from session if email was sent
                unset($_SESSION['display_reset_code']);
            } catch (\PHPMailer\PHPMailer\Exception $e) {
                $message = "Email could not be sent. Error: {$mail->ErrorInfo}";
                $messageType = 'error';
                // Still show code for debugging
                $message .= '<br><br><strong>Note:</strong> Your reset code is: <strong style="font-size: 20px; color: #2D7A8F;">' . $reset_code . '</strong><br>This code expires in 15 minutes.';
                $message .= '<br><br><small><a href="setup_email.php" style="color: #2D7A8F; font-weight: 600;">Check email configuration</a></small>';
            }
        } else {
            // Email not configured or PHPMailer not available - show code in development mode
            $message = 'Password Reset Code Generated';
            $messageType = 'success';
            // Store reset_code in session so we can display it in the view
            $_SESSION['display_reset_code'] = $reset_code;
            // Store the reason for display
            if (!$emailConfigured) {
                $_SESSION['email_not_configured'] = true;
            } else {
                $_SESSION['phpmailer_missing'] = true;
            }
        }
    } else {
        $message = 'Email address not found in our system.';
        $messageType = 'error';
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Forgot Password</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body { 
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; 
            background: linear-gradient(to bottom, #0a1929 0%, #1a2f4a 50%, #0f1b2e 100%);
            margin: 0;
            padding: 0;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            position: relative;
            overflow: hidden;
        }
        body::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-image: 
                radial-gradient(2px 2px at 20% 30%, white, transparent),
                radial-gradient(2px 2px at 60% 70%, white, transparent),
                radial-gradient(1px 1px at 50% 50%, white, transparent),
                radial-gradient(1px 1px at 80% 10%, white, transparent),
                radial-gradient(2px 2px at 90% 60%, white, transparent),
                radial-gradient(1px 1px at 33% 80%, white, transparent),
                radial-gradient(1px 1px at 15% 50%, white, transparent),
                radial-gradient(2px 2px at 70% 20%, white, transparent),
                radial-gradient(1px 1px at 40% 90%, white, transparent);
            background-size: 200% 200%;
            background-position: 0 0, 100% 0, 50% 50%, 0 100%, 100% 100%;
            opacity: 0.6;
            animation: twinkle 20s linear infinite;
        }
        body::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 0;
            width: 100%;
            height: 40%;
            background: linear-gradient(to top, #1a1a2e 0%, transparent 100%);
            clip-path: polygon(0% 100%, 100% 100%, 100% 60%, 90% 55%, 80% 50%, 70% 45%, 60% 40%, 50% 35%, 40% 30%, 30% 25%, 20% 20%, 10% 15%, 0% 10%);
        }
        @keyframes twinkle {
            0%, 100% { opacity: 0.6; }
            50% { opacity: 0.8; }
        }
        .container {
            width: 450px;
            max-width: 95%;
            background: #fff;
            border-radius: 12px;
            box-shadow: 0 20px 60px rgba(0, 0, 0, 0.5);
            overflow: hidden;
            position: relative;
            z-index: 1;
            padding: 50px;
        }
        .form-header {
            margin-bottom: 35px;
            text-align: center;
        }
        .form-header h2 {
            font-size: 36px;
            font-weight: 700;
            color: #000;
            text-transform: uppercase;
            margin-bottom: 10px;
        }
        .form-header p {
            color: #666;
            font-size: 14px;
        }
        .form-group {
            margin-bottom: 20px;
        }
        .form-group input {
            width: 100%;
            padding: 14px;
            border: 1px solid #e0e0e0;
            border-radius: 4px;
            font-size: 15px;
            color: #424242;
            background: #fff;
            transition: border-color 0.3s;
        }
        .form-group input:focus {
            outline: none;
            border-color: #2D7A8F;
        }
        .form-group input::placeholder {
            color: #9e9e9e;
        }
        .submit-button {
            width: 100%;
            padding: 14px;
            background: #2D7A8F;
            color: white;
            border: none;
            border-radius: 4px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: background-color 0.3s;
            margin-bottom: 15px;
        }
        .submit-button:hover {
            background: #1F5F6F;
        }
        .back-link {
            display: block;
            text-align: center;
            color: #2D7A8F;
            font-size: 14px;
            text-decoration: none;
            transition: color 0.3s;
        }
        .back-link:hover {
            color: #1F5F6F;
        }
        .message {
            padding: 12px 20px;
            border-radius: 4px;
            margin-bottom: 20px;
            font-size: 14px;
        }
        .message.success {
            background: #e8f5e9;
            color: #2e7d32;
            border-left: 3px solid #2e7d32;
        }
        .message.error {
            background: #ffebee;
            color: #d32f2f;
            border-left: 3px solid #d32f2f;
        }
        .code-display-box {
            background: #e8f5e9;
            border: 2px solid #2D7A8F;
            border-radius: 4px;
            padding: 20px;
            margin: 20px 0;
            text-align: center;
        }
        .code-display-box .code-title {
            color: #2D7A8F;
            font-weight: bold;
            font-size: 16px;
            margin-bottom: 15px;
        }
        .code-display-box .code-label {
            margin-bottom: 10px;
            color: #333;
        }
        .code-display-box .reset-code {
            font-size: 24px;
            font-weight: bold;
            color: #2D7A8F;
            letter-spacing: 3px;
            margin: 10px 0;
        }
        .code-display-box .expiry-text {
            margin-top: 15px;
            color: #333;
        }
        .code-display-box .email-note {
            margin-top: 15px;
            font-size: 13px;
            color: #666;
        }
        .code-display-box .email-note a {
            color: #2D7A8F;
            font-weight: 600;
            text-decoration: none;
        }
        .code-display-box .email-note a:hover {
            text-decoration: underline;
        }
        .action-links {
            margin-top: 20px;
            text-align: center;
        }
        .action-links a {
            display: block;
            margin: 10px 0;
            color: #2D7A8F;
            text-decoration: underline;
            font-size: 14px;
        }
        .action-links a:hover {
            color: #1F5F6F;
        }
    </style>
</head>
<body>

<div class="container">
    <div class="form-header">
        <h2>Forgot Password</h2>
        <p>Enter your email address to receive a password reset code</p>
    </div>
    
    <?php if (!empty($message)): ?>
        <?php if ($messageType === 'success' && $message === 'Password Reset Code Generated' && isset($_SESSION['display_reset_code'])): ?>
            <?php 
            $display_code = $_SESSION['display_reset_code'];
            $email_not_configured = isset($_SESSION['email_not_configured']) ? $_SESSION['email_not_configured'] : false;
            $phpmailer_missing = isset($_SESSION['phpmailer_missing']) ? $_SESSION['phpmailer_missing'] : false;
            unset($_SESSION['display_reset_code'], $_SESSION['email_not_configured'], $_SESSION['phpmailer_missing']); // Clear after use
            ?>
            <div class="code-display-box">
                <div class="code-title">Password Reset Code Generated</div>
                <div class="code-label">Your reset code is:</div>
                <div class="reset-code"><?php echo htmlspecialchars($display_code); ?></div>
                <div class="expiry-text">This code expires in 15 minutes.</div>
                <div class="email-note">
                    <?php if ($email_not_configured): ?>
                        Note: Email service is not configured. <a href="setup_email.php">Click here to configure Gmail</a> to receive codes via email.
                    <?php elseif ($phpmailer_missing): ?>
                        Note: PHPMailer is not installed. See SETUP_EMAIL.txt for installation instructions.
                    <?php endif; ?>
                </div>
            </div>
            <div class="action-links">
                <a href="reset_password.php">Click here to reset your password</a>
                <a href="login.php">Back to Login</a>
            </div>
        <?php else: ?>
            <div class="message <?php echo $messageType; ?>">
                <?php echo $messageType === 'success' ? $message : htmlspecialchars($message); ?>
                <?php if ($messageType === 'success' && strpos($message, 'Password Reset Code Generated') === false): ?>
                    <div style="margin-top: 15px;">
                        <a href="reset_password.php" style="color: #2e7d32; font-weight: 600; text-decoration: underline;">Click here to reset your password</a>
                    </div>
                <?php endif; ?>
            </div>
        <?php endif; ?>
    <?php endif; ?>

    <?php if ($messageType !== 'success' || empty($message)): ?>
    <form method="POST">
        <div class="form-group">
            <input type="email" name="email" placeholder="Enter your email address" required>
        </div>
        
        <button type="submit" name="request_reset" class="submit-button">Send Reset Code</button>
        
        <a href="login.php" class="back-link">Back to Login</a>
    </form>
    <?php endif; ?>
</div>

</body>
</html>

