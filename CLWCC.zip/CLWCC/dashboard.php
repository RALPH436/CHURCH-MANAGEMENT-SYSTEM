<?php
session_start();
include "db.php";

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Get total members
$totalMembers = 0;
$tableCheck = mysqli_query($conn, "SHOW TABLES LIKE 'members'");
if (mysqli_num_rows($tableCheck) > 0) {
    $result = mysqli_query($conn, "SELECT COUNT(*) as total FROM members WHERE status = 'Active'");
    if ($result) {
        $row = mysqli_fetch_assoc($result);
        $totalMembers = $row['total'];
    }
}

// Get today's attendance
$todayAttendance = 0;
$today = date('Y-m-d');
$tableCheck = mysqli_query($conn, "SHOW TABLES LIKE 'attendance'");
if (mysqli_num_rows($tableCheck) > 0) {
    $result = mysqli_query($conn, "SELECT COUNT(DISTINCT member_id) as total FROM attendance WHERE DATE(attendance_date) = '$today'");
    if ($result) {
        $row = mysqli_fetch_assoc($result);
        $todayAttendance = $row['total'];
    }
}

// Get this month's offerings
$monthOfferings = 0;
$currentMonth = date('Y-m');
$tableCheck = mysqli_query($conn, "SHOW TABLES LIKE 'offerings'");
if (mysqli_num_rows($tableCheck) > 0) {
    $result = mysqli_query($conn, "SELECT COALESCE(SUM(amount), 0) as total FROM offerings WHERE DATE_FORMAT(offering_date, '%Y-%m') = '$currentMonth'");
    if ($result) {
        $row = mysqli_fetch_assoc($result);
        $monthOfferings = $row['total'];
    }
}

// Get this month's expenses
$monthExpenses = 0;
$tableCheck = mysqli_query($conn, "SHOW TABLES LIKE 'expenses'");
if (mysqli_num_rows($tableCheck) > 0) {
    $result = mysqli_query($conn, "SELECT COALESCE(SUM(amount), 0) as total FROM expenses WHERE DATE_FORMAT(expense_date, '%Y-%m') = '$currentMonth'");
    if ($result) {
        $row = mysqli_fetch_assoc($result);
        $monthExpenses = $row['total'];
    }
}

// Calculate net balance (offerings - expenses)
$netBalance = $monthOfferings - $monthExpenses;

// Get upcoming events (next 30 days)
$upcomingEvents = 0;
$futureDate = date('Y-m-d', strtotime('+30 days'));
$tableCheck = mysqli_query($conn, "SHOW TABLES LIKE 'events'");
if (mysqli_num_rows($tableCheck) > 0) {
    $result = mysqli_query($conn, "SELECT COUNT(*) as total FROM events WHERE event_date >= CURDATE() AND event_date <= '$futureDate'");
    if ($result) {
        $row = mysqli_fetch_assoc($result);
        $upcomingEvents = $row['total'];
    }
}

// Get data for charts
// Monthly attendance data (last 6 months)
$attendanceData = [];
$attendanceLabels = [];
$attendanceTableCheck = mysqli_query($conn, "SHOW TABLES LIKE 'attendance'");
$attendanceTableExists = mysqli_num_rows($attendanceTableCheck) > 0;

for ($i = 5; $i >= 0; $i--) {
    $month = date('Y-m', strtotime("-$i months"));
    $monthName = date('M Y', strtotime("-$i months"));
    $attendanceLabels[] = $monthName;
    
    $count = 0;
    if ($attendanceTableExists) {
        $result = mysqli_query($conn, "SELECT COUNT(DISTINCT member_id) as total FROM attendance WHERE DATE_FORMAT(attendance_date, '%Y-%m') = '$month'");
        if ($result && $row = mysqli_fetch_assoc($result)) {
            $count = $row['total'];
        }
    }
    $attendanceData[] = $count;
}

// Monthly offerings data (last 6 months)
$offeringsData = [];
$offeringsLabels = [];
$offeringsTableCheck = mysqli_query($conn, "SHOW TABLES LIKE 'offerings'");
$offeringsTableExists = mysqli_num_rows($offeringsTableCheck) > 0;

for ($i = 5; $i >= 0; $i--) {
    $month = date('Y-m', strtotime("-$i months"));
    $monthName = date('M Y', strtotime("-$i months"));
    $offeringsLabels[] = $monthName;
    
    $amount = 0;
    if ($offeringsTableExists) {
        $result = mysqli_query($conn, "SELECT COALESCE(SUM(amount), 0) as total FROM offerings WHERE DATE_FORMAT(offering_date, '%Y-%m') = '$month'");
        if ($result && $row = mysqli_fetch_assoc($result)) {
            $amount = $row['total'];
        }
    }
    $offeringsData[] = $amount;
}

// Member status distribution for pie chart
$activeMembers = 0;
$inactiveMembers = 0;
$tableCheck = mysqli_query($conn, "SHOW TABLES LIKE 'members'");
if (mysqli_num_rows($tableCheck) > 0) {
    $result = mysqli_query($conn, "SELECT status, COUNT(*) as total FROM members GROUP BY status");
    if ($result) {
        while ($row = mysqli_fetch_assoc($result)) {
            if ($row['status'] == 'Active') {
                $activeMembers = $row['total'];
            } else {
                $inactiveMembers = $row['total'];
            }
        }
    }
}

// Initialize cleared notifications array in session if not exists
if (!isset($_SESSION['cleared_notifications'])) {
    $_SESSION['cleared_notifications'] = [];
}

// Get upcoming events for notifications (next 7 days)
$upcomingEventsList = [];
$eventsTableCheck = mysqli_query($conn, "SHOW TABLES LIKE 'events'");
if (mysqli_num_rows($eventsTableCheck) > 0) {
    $today = date('Y-m-d');
    $nextWeek = date('Y-m-d', strtotime('+7 days'));
    $eventsQuery = "SELECT * FROM events WHERE event_date >= '$today' AND event_date <= '$nextWeek' ORDER BY event_date ASC LIMIT 10";
    $eventsResult = mysqli_query($conn, $eventsQuery);
    if ($eventsResult) {
        while ($row = mysqli_fetch_assoc($eventsResult)) {
            // Generate notification ID for this event
            $notificationId = 'event_' . (isset($row['id']) ? $row['id'] : uniqid());
            // Only add if not cleared
            if (!in_array($notificationId, $_SESSION['cleared_notifications'])) {
                $upcomingEventsList[] = $row;
            }
        }
    }
}

// Get birthday celebrants (today and next 7 days)
$birthdayCelebrants = [];
$membersTableCheck = mysqli_query($conn, "SHOW TABLES LIKE 'members'");
if (mysqli_num_rows($membersTableCheck) > 0) {
    $todayFull = date('Y-m-d');
    $nextWeek = date('Y-m-d', strtotime('+7 days'));
    
    // Get members with birthdays in the next 7 days
    $birthdayQuery = "SELECT id, full_name, birthdate, profile_picture, status FROM members WHERE status = 'Active'";
    $birthdayResult = mysqli_query($conn, $birthdayQuery);
    if ($birthdayResult) {
        while ($member = mysqli_fetch_assoc($birthdayResult)) {
            $birthdate = $member['birthdate'];
            $birthMonthDay = date('m-d', strtotime($birthdate));
            
            // Check if birthday is today or in the next 7 days
            $currentYear = date('Y');
            $birthdayThisYear = $currentYear . '-' . $birthMonthDay;
            $birthdayDate = date('Y-m-d', strtotime($birthdayThisYear));
            
            // If birthday has passed this year, check next year
            if ($birthdayDate < $todayFull) {
                $nextYear = date('Y', strtotime('+1 year'));
                $birthdayThisYear = $nextYear . '-' . $birthMonthDay;
                $birthdayDate = date('Y-m-d', strtotime($birthdayThisYear));
            }
            
            // Check if birthday falls within the next 7 days
            if ($birthdayDate >= $todayFull && $birthdayDate <= $nextWeek) {
                // Generate notification ID for this birthday
                $notificationId = 'birthday_' . $member['id'];
                // Only add if not cleared
                if (!in_array($notificationId, $_SESSION['cleared_notifications'])) {
                    $daysUntil = (strtotime($birthdayDate) - strtotime($todayFull)) / (60 * 60 * 24);
                    $member['days_until'] = intval($daysUntil);
                    $member['birthday_date'] = $birthdayDate;
                    $birthdayCelebrants[] = $member;
                }
            }
        }
        
        // Sort by days until birthday
        usort($birthdayCelebrants, function($a, $b) {
            return $a['days_until'] - $b['days_until'];
        });
    }
}

// Calculate total notification count
$notificationCount = count($upcomingEventsList) + count($birthdayCelebrants);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Dashboard - Church Management</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        html, body {
            height: 100%;
            overflow: hidden;
        }
        body { 
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; 
            background: #f5f7fa;
            color: #333;
            position: relative;
        }
        .header {
            background: linear-gradient(135deg, #0a1929 0%, #1a2f4a 100%);
            color: white;
            padding: 0 30px;
            height: 70px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            width: 100%;
            z-index: 1000;
        }
        .header h1 {
            font-size: 24px;
            font-weight: 600;
            margin: 0;
            line-height: 1;
        }
        .header-right {
            display: flex;
            align-items: center;
            gap: 20px;
            height: 100%;
        }
        .user-info {
            display: flex;
            align-items: center;
            gap: 10px;
            height: 100%;
        }
        .user-name {
            font-size: 14px;
            font-weight: 500;
            margin: 0;
            line-height: 1;
        }
        .notification-icon {
            position: relative;
            cursor: pointer;
            padding: 8px;
            border-radius: 50%;
            transition: background-color 0.3s;
            display: flex;
            align-items: center;
            justify-content: center;
            width: 36px;
            height: 36px;
            text-decoration: none;
            color: white;
        }
        .notification-icon:hover {
            background: rgba(255, 255, 255, 0.1);
        }
        .notification-badge {
            position: absolute;
            top: 0;
            right: 0;
            background: #ff4444;
            color: white;
            border-radius: 50%;
            width: 20px;
            height: 20px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 11px;
            font-weight: 600;
            border: 2px solid #0a1929;
        }
        .notification-icon svg {
            width: 20px;
            height: 20px;
            stroke: white;
        }
        .notification-dropdown-container {
            position: relative;
        }
        .notification-dropdown {
            position: absolute;
            top: calc(100% + 10px);
            right: 0;
            width: 380px;
            max-height: 500px;
            background: white;
            border-radius: 8px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.15);
            z-index: 1001;
            display: none;
            overflow: hidden;
            animation: slideDown 0.2s ease-out;
        }
        @keyframes slideDown {
            from {
                opacity: 0;
                transform: translateY(-10px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        .notification-dropdown.active {
            display: block;
        }
        .notification-dropdown-header {
            padding: 15px 20px;
            border-bottom: 1px solid #e0e0e0;
            background: #f8f9fa;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .notification-dropdown-header h3 {
            margin: 0;
            font-size: 16px;
            font-weight: 600;
            color: #0a1929;
        }
        .notification-dropdown-close {
            background: none;
            border: none;
            font-size: 20px;
            cursor: pointer;
            color: #666;
            padding: 0;
            width: 24px;
            height: 24px;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 4px;
            transition: background 0.2s;
        }
        .notification-dropdown-close:hover {
            background: #e0e0e0;
        }
        .notification-dropdown-list {
            max-height: 400px;
            overflow-y: auto;
            overflow-x: hidden;
        }
        .notification-dropdown-list::-webkit-scrollbar {
            width: 6px;
        }
        .notification-dropdown-list::-webkit-scrollbar-track {
            background: #f1f1f1;
        }
        .notification-dropdown-list::-webkit-scrollbar-thumb {
            background: #888;
            border-radius: 3px;
        }
        .notification-dropdown-list::-webkit-scrollbar-thumb:hover {
            background: #555;
        }
        .notification-dropdown-item {
            padding: 12px 20px;
            border-bottom: 1px solid #f0f0f0;
            cursor: pointer;
            transition: background 0.2s;
            display: flex;
            align-items: flex-start;
            gap: 12px;
            position: relative;
        }
        .notification-dropdown-item:hover {
            background: #f8f9fa;
        }
        .notification-dropdown-item.read {
            opacity: 0.7;
            background: #fafafa;
        }
        .notification-dropdown-item.read:hover {
            background: #f0f0f0;
        }
        .notification-dropdown-item-icon {
            font-size: 24px;
            flex-shrink: 0;
            margin-top: 2px;
            display: inline-flex;
            align-items: center;
            justify-content: center;
        }
        .notification-dropdown-item-icon svg {
            width: 20px;
            height: 20px;
        }
        .notification-dropdown-item-content {
            flex: 1;
            min-width: 0;
        }
        .notification-dropdown-item-title {
            font-weight: 600;
            font-size: 14px;
            color: #0a1929;
            margin-bottom: 4px;
        }
        .notification-dropdown-item-message {
            font-size: 13px;
            color: #666;
            line-height: 1.4;
            margin-bottom: 6px;
            word-wrap: break-word;
        }
        .notification-dropdown-item-time {
            font-size: 11px;
            color: #999;
        }
        .notification-dropdown-item-profile {
            width: 36px;
            height: 36px;
            border-radius: 50%;
            object-fit: cover;
            border: 2px solid #e0e0e0;
            flex-shrink: 0;
        }
        .notification-dropdown-empty {
            padding: 40px 20px;
            text-align: center;
            color: #999;
            font-size: 14px;
        }
        .notification-dropdown-footer {
            padding: 12px 20px;
            border-top: 1px solid #e0e0e0;
            text-align: center;
            background: #f8f9fa;
        }
        .notification-dropdown-footer a {
            color: #2D7A8F;
            text-decoration: none;
            font-size: 13px;
            font-weight: 500;
        }
        .notification-dropdown-footer a:hover {
            text-decoration: underline;
        }
        @media (max-width: 768px) {
            .notification-dropdown {
                width: 320px;
                right: -10px;
            }
        }
        .notifications-section {
            background: white;
            padding: 25px;
            border-radius: 8px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);
            margin-top: 30px;
            margin-bottom: 20px;
        }
        .notification-item {
            padding: 15px;
            border-left: 4px solid #2D7A8F;
            background: #f8f9fa;
            border-radius: 4px;
            margin-bottom: 12px;
            transition: transform 0.2s, box-shadow 0.2s;
            cursor: pointer;
        }
        .notification-item:hover {
            transform: translateX(5px);
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
        }
        .notification-item:last-child {
            margin-bottom: 0;
        }
        .notification-item.event {
            border-left-color: #2D7A8F;
        }
        .notification-item.birthday {
            border-left-color: #ff6b6b;
        }
        .notification-item.expanded {
            background: #fff;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
        }
        .notification-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 10px;
            margin-bottom: 8px;
        }
        .notification-header-left {
            display: flex;
            align-items: center;
            gap: 10px;
            flex: 1;
        }
        .notification-icon-small {
            font-size: 20px;
            display: inline-flex;
            align-items: center;
            justify-content: center;
        }
        .notification-icon-small svg {
            width: 20px;
            height: 20px;
        }
        .birthday-icon {
            color: #ff6b6b;
        }
        .event-icon {
            color: #2D7A8F;
        }
        .notification-title {
            font-weight: 600;
            color: #0a1929;
            font-size: 15px;
        }
        .notification-content {
            color: #666;
            font-size: 14px;
            margin-left: 30px;
            margin-top: 8px;
        }
        .notification-date {
            color: #888;
            font-size: 12px;
            margin-left: 30px;
            margin-top: 5px;
        }
        .notification-actions {
            display: flex;
            gap: 5px;
            align-items: center;
        }
        .notification-clear-item-btn {
            background: #ff4444;
            color: white;
            border: none;
            padding: 5px 10px;
            border-radius: 4px;
            cursor: pointer;
            font-size: 11px;
            font-weight: 500;
            transition: background 0.3s;
        }
        .notification-clear-item-btn:hover {
            background: #cc0000;
        }
        .no-notifications {
            text-align: center;
            padding: 40px;
            color: #888;
            font-size: 14px;
        }
        .notification-profile {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            object-fit: cover;
            border: 2px solid #e0e0e0;
            margin-right: 10px;
        }
        .logout-btn {
            background: #2D7A8F;
            color: white;
            padding: 8px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 14px;
            font-weight: 500;
            text-decoration: none;
            transition: background-color 0.3s;
        }
        .logout-btn:hover {
            background: #1F5F6F;
        }
        .container {
            display: flex;
            margin-top: 70px;
            height: calc(100vh - 70px);
            position: relative;
            overflow: hidden;
        }
        .sidebar {
            width: 260px;
            background: #fff;
            box-shadow: 2px 0 10px rgba(0, 0, 0, 0.05);
            position: fixed;
            left: 0;
            top: 70px;
            height: calc(100vh - 70px);
            overflow-y: auto;
            z-index: 999;
        }
        .sidebar-menu {
            list-style: none;
            padding: 20px 0;
        }
        .sidebar-menu li {
            margin-bottom: 5px;
        }
        .sidebar-menu a {
            display: flex;
            align-items: center;
            padding: 14px 25px;
            color: #555;
            text-decoration: none;
            font-size: 15px;
            font-weight: 500;
            transition: all 0.3s;
            border-left: 3px solid transparent;
        }
        .sidebar-menu a:hover {
            background: #f5f7fa;
            color: #2D7A8F;
            border-left-color: #2D7A8F;
        }
        .sidebar-menu a.active {
            background: #f0f8ff;
            color: #2D7A8F;
            border-left-color: #2D7A8F;
            font-weight: 600;
        }
        .sidebar-menu a .sidebar-icon {
            width: 18px;
            height: 18px;
            margin-right: 12px;
            flex-shrink: 0;
            stroke: currentColor;
            opacity: 0.7;
            transition: opacity 0.3s;
        }
        .sidebar-menu a:hover .sidebar-icon,
        .sidebar-menu a.active .sidebar-icon {
            opacity: 1;
        }
        .main-content {
            flex: 1;
            margin-left: 260px;
            padding: 30px;
            background: #f5f7fa;
            height: calc(100vh - 70px);
            overflow-y: auto;
            overflow-x: hidden;
        }
        .page-title {
            font-size: 28px;
            font-weight: 700;
            color: #0a1929;
            margin-bottom: 10px;
        }
        .page-subtitle {
            color: #666;
            font-size: 14px;
            margin-bottom: 30px;
        }
        .dashboard-cards {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 20px;
            margin-bottom: 30px;
        }
        @media (max-width: 1200px) {
            .dashboard-cards {
                grid-template-columns: repeat(2, 1fr);
            }
        }
        @media (max-width: 768px) {
            .dashboard-cards {
                grid-template-columns: 1fr;
            }
        }
        .card {
            background: white;
            padding: 20px;
            border-radius: 12px;
            box-shadow: 0 2px 12px rgba(0, 0, 0, 0.08);
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            position: relative;
            overflow: hidden;
            border: 1px solid rgba(0, 0, 0, 0.05);
        }
        .card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 5px;
            background: linear-gradient(90deg, #2D7A8F, #1a2f4a);
            transition: height 0.3s;
        }
        .card:hover {
            transform: translateY(-4px);
            box-shadow: 0 8px 24px rgba(0, 0, 0, 0.12);
        }
        .card:hover::before {
            height: 6px;
        }
        .card.card-members::before {
            background: linear-gradient(135deg, #2D7A8F 0%, #1a2f4a 100%);
        }
        .card.card-attendance::before {
            background: linear-gradient(135deg, #4a90e2 0%, #2D7A8F 100%);
        }
        .card.card-offerings::before {
            background: linear-gradient(135deg, #1a2f4a 0%, #0a1929 100%);
        }
        .card.card-events::before {
            background: linear-gradient(135deg, #5b7fa8 0%, #2D7A8F 100%);
        }
        .card-header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            margin-bottom: 12px;
        }
        .card-icon-wrapper {
            width: 42px;
            height: 42px;
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            flex-shrink: 0;
            transition: transform 0.3s;
        }
        .card:hover .card-icon-wrapper {
            transform: scale(1.1) rotate(5deg);
        }
        .card.card-members .card-icon-wrapper {
            background: linear-gradient(135deg, rgba(45, 122, 143, 0.15) 0%, rgba(26, 47, 74, 0.15) 100%);
        }
        .card.card-attendance .card-icon-wrapper {
            background: linear-gradient(135deg, rgba(74, 144, 226, 0.15) 0%, rgba(45, 122, 143, 0.15) 100%);
        }
        .card.card-offerings .card-icon-wrapper {
            background: linear-gradient(135deg, rgba(26, 47, 74, 0.15) 0%, rgba(10, 25, 41, 0.15) 100%);
        }
        .card.card-events .card-icon-wrapper {
            background: linear-gradient(135deg, rgba(91, 127, 168, 0.15) 0%, rgba(45, 122, 143, 0.15) 100%);
        }
        .card-icon {
            width: 20px;
            height: 20px;
            stroke: currentColor;
        }
        .card.card-members .card-icon {
            color: #2D7A8F;
        }
        .card.card-attendance .card-icon {
            color: #4a90e2;
        }
        .card.card-offerings .card-icon {
            color: #1a2f4a;
        }
        .card.card-events .card-icon {
            color: #5b7fa8;
        }
        .card-title {
            font-size: 12px;
            color: #666;
            text-transform: uppercase;
            letter-spacing: 0.8px;
            font-weight: 600;
            margin-bottom: 8px;
        }
        .card-value-wrapper {
            margin-bottom: 4px;
        }
        .card-value {
            font-size: 32px;
            font-weight: 700;
            color: #0a1929;
            line-height: 1.2;
            margin: 0;
        }
        .card.card-members .card-value {
            color: #2D7A8F;
        }
        .card.card-attendance .card-value {
            color: #4a90e2;
        }
        .card.card-offerings .card-value {
            color: #1a2f4a;
        }
        .card.card-events .card-value {
            color: #5b7fa8;
        }
        .card-footer {
            font-size: 12px;
            color: #888;
            margin-top: 8px;
            padding-top: 8px;
            border-top: 1px solid rgba(0, 0, 0, 0.06);
            display: flex;
            align-items: center;
            gap: 6px;
        }
        .card-footer-icon {
            width: 14px;
            height: 14px;
            opacity: 0.6;
        }
        .card.card-members .card-footer {
            color: #2D7A8F;
        }
        .card.card-attendance .card-footer {
            color: #4a90e2;
        }
        .card.card-offerings .card-footer {
            color: #1a2f4a;
        }
        .card.card-events .card-footer {
            color: #5b7fa8;
        }
        .content-section {
            background: white;
            padding: 25px;
            border-radius: 8px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);
            margin-bottom: 20px;
        }
        .section-title {
            font-size: 18px;
            font-weight: 600;
            color: #0a1929;
            margin-bottom: 15px;
            padding-bottom: 10px;
            border-bottom: 2px solid #f0f0f0;
        }
        .charts-container {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 20px;
            margin-bottom: 20px;
        }
        .chart-wrapper {
            background: white;
            padding: 25px;
            border-radius: 8px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);
        }
        .chart-title {
            font-size: 16px;
            font-weight: 600;
            color: #0a1929;
            margin-bottom: 15px;
            text-align: center;
        }
        .chart-container {
            position: relative;
            height: 300px;
        }
        @media (max-width: 968px) {
            .charts-container {
                grid-template-columns: 1fr;
            }
        }
        @media (max-width: 768px) {
            .sidebar {
                width: 100%;
                position: relative;
                top: 0;
                height: auto;
            }
            .main-content {
                margin-left: 0;
            }
            .container {
                flex-direction: column;
            }
            .header {
                flex-direction: column;
                gap: 15px;
                padding: 15px;
            }
        }
    </style>
</head>
<body>

<div class="header">
    <h1>Church Management System</h1>
    <div class="header-right">
        <div class="notification-dropdown-container">
            <div class="notification-icon" id="notificationIcon" onclick="toggleNotificationDropdown(event)" title="View Notifications">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"></path>
                    <path d="M13.73 21a2 2 0 0 1-3.46 0"></path>
                </svg>
                <?php if ($notificationCount > 0): ?>
                    <span class="notification-badge" id="notificationBadge"><?php echo $notificationCount; ?></span>
                <?php endif; ?>
            </div>
            <div class="notification-dropdown" id="notificationDropdown">
                <div class="notification-dropdown-header">
                    <h3>Notifications</h3>
                    <button class="notification-dropdown-close" onclick="closeNotificationDropdown()" title="Close">×</button>
                </div>
                <div class="notification-dropdown-list" id="notificationDropdownList">
                    <div class="notification-dropdown-empty">Loading notifications...</div>
                </div>
                <div class="notification-dropdown-footer">
                    <a href="dashboard.php#notifications-section" onclick="closeNotificationDropdown();">View All Notifications</a>
                </div>
            </div>
        </div>
        <div class="user-info">
            <span class="user-name">Welcome, <?php echo htmlspecialchars($_SESSION['fullname']); ?></span>
        </div>
        <a href="logout.php" class="logout-btn">Logout</a>
    </div>
</div>

<div class="container">
    <aside class="sidebar">
        <ul class="sidebar-menu">
            <li><a href="dashboard.php" class="active">
                <svg class="sidebar-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="7" height="7"></rect><rect x="14" y="3" width="7" height="7"></rect><rect x="14" y="14" width="7" height="7"></rect><rect x="3" y="14" width="7" height="7"></rect></svg>
                Dashboard</a></li>
            <li><a href="members.php">
                <svg class="sidebar-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path><circle cx="9" cy="7" r="4"></circle><path d="M23 21v-2a4 4 0 0 0-3-3.87"></path><path d="M16 3.13a4 4 0 0 1 0 7.75"></path></svg>
                Members</a></li>
            <li><a href="attendance.php">
                <svg class="sidebar-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path><polyline points="14 2 14 8 20 8"></polyline><line x1="16" y1="13" x2="8" y2="13"></line><line x1="16" y1="17" x2="8" y2="17"></line><polyline points="10 9 9 9 8 9"></line></svg>
                Attendance</a></li>
            <li><a href="offerings.php">
                <svg class="sidebar-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="12" y1="1" x2="12" y2="23"></line><path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"></path></svg>
                Offerings</a></li>
            <li><a href="expenses.php">
                <svg class="sidebar-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path><polyline points="14 2 14 8 20 8"></polyline><line x1="16" y1="13" x2="8" y2="13"></line><line x1="16" y1="17" x2="8" y2="17"></line></svg>
                Expenses</a></li>
            <li><a href="events.php">
                <svg class="sidebar-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect><line x1="16" y1="2" x2="16" y2="6"></line><line x1="8" y1="2" x2="8" y2="6"></line><line x1="3" y1="10" x2="21" y2="10"></line></svg>
                Events</a></li>
            <li><a href="reports.php">
                <svg class="sidebar-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="20" x2="18" y2="10"></line><line x1="12" y1="20" x2="12" y2="4"></line><line x1="6" y1="20" x2="6" y2="14"></line></svg>
                Reports</a></li>
            <li><a href="users.php">
                <svg class="sidebar-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path><circle cx="12" cy="7" r="4"></circle></svg>
                Users</a></li>
        </ul>
    </aside>

    <main class="main-content">
        <h2 class="page-title">Dashboard</h2>
        <p class="page-subtitle">Overview of church management activities</p>

        <div class="dashboard-cards">
            <div class="card card-members">
                <div class="card-header">
                    <div>
                        <div class="card-title">Total Members</div>
                        <div class="card-value-wrapper">
                            <div class="card-value"><?php echo number_format($totalMembers); ?></div>
                        </div>
                    </div>
                    <div class="card-icon-wrapper">
                        <svg class="card-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                            <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path>
                            <circle cx="9" cy="7" r="4"></circle>
                            <path d="M23 21v-2a4 4 0 0 0-3-3.87"></path>
                            <path d="M16 3.13a4 4 0 0 1 0 7.75"></path>
                        </svg>
                    </div>
                </div>
                <div class="card-footer">
                    <svg class="card-footer-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <circle cx="12" cy="12" r="10"></circle>
                        <polyline points="12 6 12 12 16 14"></polyline>
                    </svg>
                    <span>Active members</span>
                </div>
            </div>
            <div class="card card-attendance">
                <div class="card-header">
                    <div>
                        <div class="card-title">Today's Attendance</div>
                        <div class="card-value-wrapper">
                            <div class="card-value"><?php echo number_format($todayAttendance); ?></div>
                        </div>
                    </div>
                    <div class="card-icon-wrapper">
                        <svg class="card-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                            <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path>
                            <polyline points="14 2 14 8 20 8"></polyline>
                            <line x1="16" y1="13" x2="8" y2="13"></line>
                            <line x1="16" y1="17" x2="8" y2="17"></line>
                            <polyline points="10 9 9 9 8 9"></polyline>
                        </svg>
                    </div>
                </div>
                <div class="card-footer">
                    <svg class="card-footer-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <circle cx="12" cy="12" r="10"></circle>
                        <polyline points="12 6 12 12 16 14"></polyline>
                    </svg>
                    <span>Members present today</span>
                </div>
            </div>
            <div class="card card-offerings">
                <div class="card-header">
                    <div>
                        <div class="card-title">This Month's Net Balance</div>
                        <div class="card-value-wrapper">
                            <div class="card-value" style="color: <?php echo $netBalance >= 0 ? '#2e7d32' : '#d32f2f'; ?>;">₱<?php echo number_format($netBalance, 2); ?></div>
                        </div>
                    </div>
                    <div class="card-icon-wrapper">
                        <svg class="card-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                            <path d="M8 18V6h6a4 4 0 0 1 0 8H8"></path>
                            <line x1="8" y1="10" x2="16" y2="10"></line>
                            <line x1="8" y1="14" x2="16" y2="14"></line>
                        </svg>
                    </div>
                </div>
                <div class="card-footer">
                    <svg class="card-footer-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <path d="M8 18V6h6a4 4 0 0 1 0 8H8"></path>
                        <line x1="8" y1="10" x2="16" y2="10"></line>
                        <line x1="8" y1="14" x2="16" y2="14"></line>
                    </svg>
                    <span>Offerings: ₱<?php echo number_format($monthOfferings, 2); ?> - Expenses: ₱<?php echo number_format($monthExpenses, 2); ?></span>
                </div>
            </div>
            <div class="card card-events">
                <div class="card-header">
                    <div>
                        <div class="card-title">Upcoming Events</div>
                        <div class="card-value-wrapper">
                            <div class="card-value"><?php echo number_format($upcomingEvents); ?></div>
                        </div>
                    </div>
                    <div class="card-icon-wrapper">
                        <svg class="card-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                            <rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect>
                            <line x1="16" y1="2" x2="16" y2="6"></line>
                            <line x1="8" y1="2" x2="8" y2="6"></line>
                            <line x1="3" y1="10" x2="21" y2="10"></line>
                        </svg>
                    </div>
                </div>
                <div class="card-footer">
                    <svg class="card-footer-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <circle cx="12" cy="12" r="10"></circle>
                        <polyline points="12 6 12 12 16 14"></polyline>
                    </svg>
                    <span>Scheduled events (next 30 days)</span>
                </div>
            </div>
        </div>

        <div class="charts-container">
            <div class="chart-wrapper">
                <h3 class="chart-title">Monthly Attendance Trend</h3>
                <div class="chart-container">
                    <canvas id="attendanceChart"></canvas>
                </div>
            </div>
            <div class="chart-wrapper">
                <h3 class="chart-title">Monthly Offerings Trend</h3>
                <div class="chart-container">
                    <canvas id="offeringsChart"></canvas>
                </div>
            </div>
        </div>

        <div class="chart-wrapper">
            <h3 class="chart-title">Member Status Distribution</h3>
            <div class="chart-container">
                <canvas id="memberStatusChart"></canvas>
            </div>
        </div>

        <!-- Notifications Section -->
        <div class="notifications-section" id="notifications-section">
            <h3 class="section-title">Notifications</h3>
            <?php if ($notificationCount > 0): ?>
                <!-- Upcoming Events -->
                <?php if (count($upcomingEventsList) > 0): ?>
                    <?php foreach ($upcomingEventsList as $index => $event): ?>
                        <?php $notificationId = 'event_' . (isset($event['id']) ? $event['id'] : uniqid()); ?>
                        <div class="notification-item event" data-type="event" data-index="<?php echo $index; ?>" data-notification-id="<?php echo $notificationId; ?>">
                            <div class="notification-header">
                                <div class="notification-header-left">
                                    <span class="notification-icon-small event-icon">
                                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                            <rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect>
                                            <line x1="16" y1="2" x2="16" y2="6"></line>
                                            <line x1="8" y1="2" x2="8" y2="6"></line>
                                            <line x1="3" y1="10" x2="21" y2="10"></line>
                                        </svg>
                                    </span>
                                    <span class="notification-title">Upcoming Event</span>
                                </div>
                                <div class="notification-actions">
                                    <button class="notification-clear-item-btn" onclick="clearNotificationSection(event, this, '<?php echo $notificationId; ?>')">Clear</button>
                                </div>
                            </div>
                            <div class="notification-content">
                                <?php 
                                // Handle different possible column names
                                $eventName = '';
                                if (isset($event['event_name'])) {
                                    $eventName = htmlspecialchars($event['event_name']);
                                } elseif (isset($event['title'])) {
                                    $eventName = htmlspecialchars($event['title']);
                                } elseif (isset($event['name'])) {
                                    $eventName = htmlspecialchars($event['name']);
                                } else {
                                    $eventName = 'Event';
                                }
                                
                                $eventDate = isset($event['event_date']) ? date('M d, Y', strtotime($event['event_date'])) : '';
                                $eventDescription = '';
                                if (isset($event['description'])) {
                                    $eventDescription = htmlspecialchars($event['description']);
                                } elseif (isset($event['details'])) {
                                    $eventDescription = htmlspecialchars($event['details']);
                                }
                                
                                echo '<strong>' . $eventName . '</strong>';
                                if (!empty($eventDescription)) {
                                    echo '<br>' . $eventDescription;
                                }
                                ?>
                            </div>
                            <div class="notification-date">
                                <?php 
                                if (isset($event['event_date'])) {
                                    $daysUntil = (strtotime($event['event_date']) - strtotime(date('Y-m-d'))) / (60 * 60 * 24);
                                    if ($daysUntil == 0) {
                                        echo 'Today - ' . $eventDate;
                                    } elseif ($daysUntil == 1) {
                                        echo 'Tomorrow - ' . $eventDate;
                                    } else {
                                        echo 'In ' . intval($daysUntil) . ' days - ' . $eventDate;
                                    }
                                }
                                ?>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
                
                <!-- Birthday Celebrants -->
                <?php if (count($birthdayCelebrants) > 0): ?>
                    <?php foreach ($birthdayCelebrants as $index => $celebrant): ?>
                        <?php $notificationId = 'birthday_' . $celebrant['id']; ?>
                        <div class="notification-item birthday" data-type="birthday" data-index="<?php echo $index; ?>" data-notification-id="<?php echo $notificationId; ?>">
                            <div class="notification-header">
                                <div class="notification-header-left">
                                    <span class="notification-icon-small birthday-icon">
                                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                            <rect x="2" y="12" width="20" height="8" rx="2" fill="currentColor" opacity="0.2"></rect>
                                            <rect x="4" y="8" width="16" height="6" rx="1" fill="currentColor" opacity="0.3"></rect>
                                            <line x1="6" y1="4" x2="6" y2="8"></line>
                                            <line x1="10" y1="4" x2="10" y2="8"></line>
                                            <line x1="14" y1="4" x2="14" y2="8"></line>
                                            <line x1="18" y1="4" x2="18" y2="8"></line>
                                            <circle cx="6" cy="3" r="1" fill="currentColor"></circle>
                                            <circle cx="10" cy="3" r="1" fill="currentColor"></circle>
                                            <circle cx="14" cy="3" r="1" fill="currentColor"></circle>
                                            <circle cx="18" cy="3" r="1" fill="currentColor"></circle>
                                        </svg>
                                    </span>
                                    <span class="notification-title">Birthday Celebrant</span>
                                </div>
                                <div class="notification-actions">
                                    <button class="notification-clear-item-btn" onclick="clearNotificationSection(event, this, '<?php echo $notificationId; ?>')">Clear</button>
                                </div>
                            </div>
                            <div class="notification-content" style="display: flex; align-items: center;">
                                <?php if ($celebrant['profile_picture'] && file_exists($celebrant['profile_picture'])): ?>
                                    <img src="<?php echo htmlspecialchars($celebrant['profile_picture']); ?>" alt="Profile" class="notification-profile">
                                <?php else: ?>
                                    <div class="notification-profile" style="background: #e0e0e0; display: flex; align-items: center; justify-content: center; color: #999; font-size: 12px;">No Image</div>
                                <?php endif; ?>
                                <div>
                                    <strong><?php echo htmlspecialchars($celebrant['full_name']); ?></strong> is celebrating their birthday
                                    <?php 
                                    $birthdate = new DateTime($celebrant['birthdate']);
                                    $today = new DateTime();
                                    $age = $today->diff($birthdate)->y;
                                    echo ' (turning ' . ($age + 1) . ')';
                                    ?>
                                </div>
                            </div>
                            <div class="notification-date">
                                <?php 
                                if ($celebrant['days_until'] == 0) {
                                    echo 'Today - ' . date('M d, Y', strtotime($celebrant['birthday_date']));
                                } elseif ($celebrant['days_until'] == 1) {
                                    echo 'Tomorrow - ' . date('M d, Y', strtotime($celebrant['birthday_date']));
                                } else {
                                    echo 'In ' . $celebrant['days_until'] . ' days - ' . date('M d, Y', strtotime($celebrant['birthday_date']));
                                }
                                ?>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            <?php else: ?>
                <div class="no-notifications">
                    <p>No notifications at this time.</p>
                </div>
            <?php endif; ?>
        </div>

        <div class="content-section">
            <h3 class="section-title">Recent Activity</h3>
            <p style="color: #888; font-size: 14px;">No recent activity to display.</p>
        </div>

        <div class="content-section">
            <h3 class="section-title">Quick Actions</h3>
            <div style="display: flex; gap: 15px; flex-wrap: wrap;">
                <a href="members.php" style="background: #2D7A8F; color: white; padding: 12px 24px; border-radius: 4px; text-decoration: none; font-size: 14px; font-weight: 500; transition: background 0.3s;">Add Member</a>
                <a href="attendance.php" style="background: #2D7A8F; color: white; padding: 12px 24px; border-radius: 4px; text-decoration: none; font-size: 14px; font-weight: 500; transition: background 0.3s;">Record Attendance</a>
                <a href="offerings.php" style="background: #2D7A8F; color: white; padding: 12px 24px; border-radius: 4px; text-decoration: none; font-size: 14px; font-weight: 500; transition: background 0.3s;">Add Offering</a>
                <a href="events.php" style="background: #2D7A8F; color: white; padding: 12px 24px; border-radius: 4px; text-decoration: none; font-size: 14px; font-weight: 500; transition: background 0.3s;">Create Event</a>
            </div>
        </div>
    </main>
</div>

<script>
// Clear individual notification in section
function clearNotificationSection(event, button, notificationId) {
    event.stopPropagation();
    const item = button.closest('.notification-item');
    
    // Send AJAX request to persist the cleared state
    const formData = new FormData();
    formData.append('notification_id', notificationId);
    
    fetch('clear_notification.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.success || data.error) {
            // Remove from DOM
            item.style.transition = 'opacity 0.3s, transform 0.3s';
            item.style.opacity = '0';
            item.style.transform = 'translateX(-20px)';
            setTimeout(() => {
                item.remove();
                updateNotificationCount();
                // If no notifications left, show empty message
                const section = document.getElementById('notifications-section');
                const items = section.querySelectorAll('.notification-item');
                if (items.length === 0) {
                    section.innerHTML = '<h3 class="section-title">Notifications</h3><div class="no-notifications"><p>No notifications at this time.</p></div>';
                }
            }, 300);
        }
    })
    .catch(error => {
        console.error('Error clearing notification:', error);
        // Still remove from DOM even if request fails
        item.style.transition = 'opacity 0.3s, transform 0.3s';
        item.style.opacity = '0';
        item.style.transform = 'translateX(-20px)';
        setTimeout(() => {
            item.remove();
            updateNotificationCount();
        }, 300);
    });
}

// Update notification badge count
function updateNotificationCount() {
    const sectionItems = document.querySelectorAll('.notification-item').length;
    const badge = document.querySelector('.notification-badge');
    if (sectionItems > 0) {
        if (badge) {
            badge.textContent = sectionItems;
        } else {
            const icon = document.querySelector('.notification-icon');
            if (icon) {
                const newBadge = document.createElement('span');
                newBadge.className = 'notification-badge';
                newBadge.textContent = sectionItems;
                icon.appendChild(newBadge);
            }
        }
    } else {
        if (badge) badge.remove();
    }
}

// Attendance Bar Chart
const attendanceCtx = document.getElementById('attendanceChart').getContext('2d');
const attendanceChart = new Chart(attendanceCtx, {
    type: 'bar',
    data: {
        labels: <?php echo json_encode($attendanceLabels); ?>,
        datasets: [{
            label: 'Attendance',
            data: <?php echo json_encode($attendanceData); ?>,
            backgroundColor: 'rgba(45, 122, 143, 0.8)',
            borderColor: 'rgba(45, 122, 143, 1)',
            borderWidth: 1
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false,
        scales: {
            y: {
                beginAtZero: true,
                ticks: {
                    stepSize: 1
                }
            }
        },
        plugins: {
            legend: {
                display: false
            }
        }
    }
});

// Offerings Bar Chart
const offeringsCtx = document.getElementById('offeringsChart').getContext('2d');
const offeringsChart = new Chart(offeringsCtx, {
    type: 'bar',
    data: {
        labels: <?php echo json_encode($offeringsLabels); ?>,
        datasets: [{
            label: 'Offerings (₱)',
            data: <?php echo json_encode($offeringsData); ?>,
            backgroundColor: 'rgba(26, 47, 74, 0.8)',
            borderColor: 'rgba(26, 47, 74, 1)',
            borderWidth: 1
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false,
        scales: {
            y: {
                beginAtZero: true,
                ticks: {
                    callback: function(value) {
                        return '₱' + value.toLocaleString();
                    }
                }
            }
        },
        plugins: {
            legend: {
                display: false
            }
        }
    }
});

// Member Status Pie Chart
const memberStatusCtx = document.getElementById('memberStatusChart').getContext('2d');
const memberStatusChart = new Chart(memberStatusCtx, {
    type: 'pie',
    data: {
        labels: ['Active Members', 'Inactive Members'],
        datasets: [{
            data: [<?php echo $activeMembers; ?>, <?php echo $inactiveMembers; ?>],
            backgroundColor: [
                'rgba(45, 122, 143, 0.8)',
                'rgba(200, 200, 200, 0.8)'
            ],
            borderColor: [
                'rgba(45, 122, 143, 1)',
                'rgba(200, 200, 200, 1)'
            ],
            borderWidth: 1
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
            legend: {
                position: 'bottom'
            }
        }
    }
});

// Notification Dropdown Functions
let notificationDropdownOpen = false;
let readNotifications = JSON.parse(localStorage.getItem('readNotifications') || '[]');

function toggleNotificationDropdown(event) {
    event.stopPropagation();
    const dropdown = document.getElementById('notificationDropdown');
    const list = document.getElementById('notificationDropdownList');
    
    if (dropdown.classList.contains('active')) {
        closeNotificationDropdown();
    } else {
        dropdown.classList.add('active');
        notificationDropdownOpen = true;
        loadNotifications();
    }
}

function closeNotificationDropdown() {
    const dropdown = document.getElementById('notificationDropdown');
    dropdown.classList.remove('active');
    notificationDropdownOpen = false;
}

function loadNotifications() {
    const list = document.getElementById('notificationDropdownList');
    
    // Use existing PHP data if available, otherwise fetch via AJAX
    <?php if (isset($upcomingEventsList) && isset($birthdayCelebrants)): ?>
        // Use PHP data from dashboard
        const notifications = <?php 
            $notifications = [];
            foreach ($upcomingEventsList as $event) {
                $eventName = '';
                if (isset($event['event_name'])) {
                    $eventName = htmlspecialchars($event['event_name'], ENT_QUOTES);
                } elseif (isset($event['title'])) {
                    $eventName = htmlspecialchars($event['title'], ENT_QUOTES);
                } elseif (isset($event['name'])) {
                    $eventName = htmlspecialchars($event['name'], ENT_QUOTES);
                } else {
                    $eventName = 'Event';
                }
                
                $eventDate = isset($event['event_date']) ? $event['event_date'] : '';
                $daysUntil = 0;
                if ($eventDate) {
                    $daysUntil = (strtotime($eventDate) - strtotime(date('Y-m-d'))) / (60 * 60 * 24);
                }
                
                $notifications[] = [
                    'type' => 'event',
                    'id' => 'event_' . (isset($event['id']) ? $event['id'] : uniqid()),
                    'title' => 'Upcoming Event',
                    'message' => $eventName,
                    'date' => $eventDate,
                    'days_until' => intval($daysUntil),
                    'timestamp' => $eventDate ? strtotime($eventDate) : time(),
                    'icon' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="#2D7A8F" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect><line x1="16" y1="2" x2="16" y2="6"></line><line x1="8" y1="2" x2="8" y2="6"></line><line x1="3" y1="10" x2="21" y2="10"></line></svg>'
                ];
            }
            
            foreach ($birthdayCelebrants as $celebrant) {
                $birthdate = new DateTime($celebrant['birthdate']);
                $today = new DateTime();
                $age = $today->diff($birthdate)->y;
                
                $notifications[] = [
                    'type' => 'birthday',
                    'id' => 'birthday_' . $celebrant['id'],
                    'title' => 'Birthday Celebrant',
                    'message' => htmlspecialchars($celebrant['full_name'], ENT_QUOTES) . ' is celebrating their birthday (turning ' . ($age + 1) . ')',
                    'date' => $celebrant['birthday_date'],
                    'days_until' => $celebrant['days_until'],
                    'timestamp' => strtotime($celebrant['birthday_date']),
                    'icon' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="#ff6b6b" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="12" width="20" height="8" rx="2" fill="#ff6b6b" opacity="0.2"></rect><rect x="4" y="8" width="16" height="6" rx="1" fill="#ff6b6b" opacity="0.3"></rect><line x1="6" y1="4" x2="6" y2="8" stroke="#ff6b6b"></line><line x1="10" y1="4" x2="10" y2="8" stroke="#ff6b6b"></line><line x1="14" y1="4" x2="14" y2="8" stroke="#ff6b6b"></line><line x1="18" y1="4" x2="18" y2="8" stroke="#ff6b6b"></line><circle cx="6" cy="3" r="1" fill="#ff6b6b"></circle><circle cx="10" cy="3" r="1" fill="#ff6b6b"></circle><circle cx="14" cy="3" r="1" fill="#ff6b6b"></circle><circle cx="18" cy="3" r="1" fill="#ff6b6b"></circle></svg>',
                    'profile_picture' => $celebrant['profile_picture'] ?? null
                ];
            }
            
            usort($notifications, function($a, $b) {
                return $a['timestamp'] - $b['timestamp'];
            });
            
            echo json_encode($notifications, JSON_HEX_APOS | JSON_HEX_QUOT);
        ?>;
        renderNotifications(notifications);
    <?php else: ?>
        // Fetch via AJAX
        fetch('get_notifications.php')
            .then(response => response.json())
            .then(data => {
                if (data.error) {
                    list.innerHTML = '<div class="notification-dropdown-empty">Error loading notifications</div>';
                } else {
                    renderNotifications(data.notifications);
                }
            })
            .catch(error => {
                console.error('Error:', error);
                list.innerHTML = '<div class="notification-dropdown-empty">Error loading notifications</div>';
            });
    <?php endif; ?>
}

function renderNotifications(notifications) {
    const list = document.getElementById('notificationDropdownList');
    
    if (!notifications || notifications.length === 0) {
        list.innerHTML = '<div class="notification-dropdown-empty">No notifications at this time.</div>';
        return;
    }
    
    list.innerHTML = notifications.map(notif => {
        const isRead = readNotifications.includes(notif.id);
        const timeAgo = formatTimeAgo(notif.timestamp, notif.days_until);
        const profileImg = notif.profile_picture && notif.profile_picture.trim() !== '' 
            ? `<img src="${escapeHtml(notif.profile_picture)}" alt="Profile" class="notification-dropdown-item-profile" onerror="this.style.display='none'">`
            : '';
        
        // Icon can be SVG HTML, so don't escape it
        const iconHtml = notif.icon || '';
        
        return `
            <div class="notification-dropdown-item ${isRead ? 'read' : ''}" 
                 onclick="markNotificationAsRead('${notif.id}', this)" 
                 data-notification-id="${notif.id}">
                <span class="notification-dropdown-item-icon">${iconHtml}</span>
                ${profileImg}
                <div class="notification-dropdown-item-content">
                    <div class="notification-dropdown-item-title">${escapeHtml(notif.title)}</div>
                    <div class="notification-dropdown-item-message">${escapeHtml(notif.message)}</div>
                    <div class="notification-dropdown-item-time">${timeAgo}</div>
                </div>
            </div>
        `;
    }).join('');
}

function markNotificationAsRead(notificationId, element) {
    if (!readNotifications.includes(notificationId)) {
        readNotifications.push(notificationId);
        localStorage.setItem('readNotifications', JSON.stringify(readNotifications));
        element.classList.add('read');
        updateNotificationBadge();
    }
}

function formatTimeAgo(timestamp, daysUntil) {
    const now = Math.floor(Date.now() / 1000);
    const diff = timestamp - now;
    const days = Math.floor(diff / 86400);
    
    if (days < 0) {
        return 'Past';
    } else if (days === 0) {
        return 'Today';
    } else if (days === 1) {
        return 'Tomorrow';
    } else {
        return `In ${days} days`;
    }
}

function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

function updateNotificationBadge() {
    const badge = document.getElementById('notificationBadge');
    if (!badge) return;
    
    const allItems = document.querySelectorAll('.notification-dropdown-item');
    const unreadCount = Array.from(allItems).filter(item => !item.classList.contains('read')).length;
    
    if (unreadCount > 0) {
        badge.textContent = unreadCount;
        badge.style.display = 'flex';
    } else {
        badge.style.display = 'none';
    }
}

// Close dropdown when clicking outside
document.addEventListener('click', function(event) {
    const container = document.querySelector('.notification-dropdown-container');
    if (container && !container.contains(event.target) && notificationDropdownOpen) {
        closeNotificationDropdown();
    }
});

// Handle hash navigation on page load
function handleHashNavigation() {
    if (window.location.hash === '#notifications-section') {
        setTimeout(() => {
            const section = document.getElementById('notifications-section');
            if (section) {
                section.scrollIntoView({ behavior: 'smooth', block: 'start' });
                // Add a highlight effect
                section.style.transition = 'box-shadow 0.3s';
                section.style.boxShadow = '0 0 20px rgba(45, 122, 143, 0.3)';
                setTimeout(() => {
                    section.style.boxShadow = '';
                }, 2000);
            }
        }, 300);
    }
}

// Load notifications on page load to update badge
document.addEventListener('DOMContentLoaded', function() {
    handleHashNavigation();
    
    <?php if (isset($upcomingEventsList) && isset($birthdayCelebrants)): ?>
        const notifications = <?php 
            $notifications = [];
            foreach ($upcomingEventsList as $event) {
                $eventName = '';
                if (isset($event['event_name'])) {
                    $eventName = htmlspecialchars($event['event_name'], ENT_QUOTES);
                } elseif (isset($event['title'])) {
                    $eventName = htmlspecialchars($event['title'], ENT_QUOTES);
                } elseif (isset($event['name'])) {
                    $eventName = htmlspecialchars($event['name'], ENT_QUOTES);
                } else {
                    $eventName = 'Event';
                }
                
                $eventDate = isset($event['event_date']) ? $event['event_date'] : '';
                $daysUntil = 0;
                if ($eventDate) {
                    $daysUntil = (strtotime($eventDate) - strtotime(date('Y-m-d'))) / (60 * 60 * 24);
                }
                
                $notifications[] = [
                    'type' => 'event',
                    'id' => 'event_' . (isset($event['id']) ? $event['id'] : uniqid()),
                    'title' => 'Upcoming Event',
                    'message' => $eventName,
                    'date' => $eventDate,
                    'days_until' => intval($daysUntil),
                    'timestamp' => $eventDate ? strtotime($eventDate) : time(),
                    'icon' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="#2D7A8F" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect><line x1="16" y1="2" x2="16" y2="6"></line><line x1="8" y1="2" x2="8" y2="6"></line><line x1="3" y1="10" x2="21" y2="10"></line></svg>'
                ];
            }
            
            foreach ($birthdayCelebrants as $celebrant) {
                $birthdate = new DateTime($celebrant['birthdate']);
                $today = new DateTime();
                $age = $today->diff($birthdate)->y;
                
                $notifications[] = [
                    'type' => 'birthday',
                    'id' => 'birthday_' . $celebrant['id'],
                    'title' => 'Birthday Celebrant',
                    'message' => htmlspecialchars($celebrant['full_name'], ENT_QUOTES) . ' is celebrating their birthday (turning ' . ($age + 1) . ')',
                    'date' => $celebrant['birthday_date'],
                    'days_until' => $celebrant['days_until'],
                    'timestamp' => strtotime($celebrant['birthday_date']),
                    'icon' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="#ff6b6b" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="12" width="20" height="8" rx="2" fill="#ff6b6b" opacity="0.2"></rect><rect x="4" y="8" width="16" height="6" rx="1" fill="#ff6b6b" opacity="0.3"></rect><line x1="6" y1="4" x2="6" y2="8" stroke="#ff6b6b"></line><line x1="10" y1="4" x2="10" y2="8" stroke="#ff6b6b"></line><line x1="14" y1="4" x2="14" y2="8" stroke="#ff6b6b"></line><line x1="18" y1="4" x2="18" y2="8" stroke="#ff6b6b"></line><circle cx="6" cy="3" r="1" fill="#ff6b6b"></circle><circle cx="10" cy="3" r="1" fill="#ff6b6b"></circle><circle cx="14" cy="3" r="1" fill="#ff6b6b"></circle><circle cx="18" cy="3" r="1" fill="#ff6b6b"></circle></svg>',
                    'profile_picture' => $celebrant['profile_picture'] ?? null
                ];
            }
            
            usort($notifications, function($a, $b) {
                return $a['timestamp'] - $b['timestamp'];
            });
            
            echo json_encode($notifications, JSON_HEX_APOS | JSON_HEX_QUOT);
        ?>;
        // Update badge based on read status
        const unreadCount = notifications.filter(n => !readNotifications.includes(n.id)).length;
        const badge = document.getElementById('notificationBadge');
        if (badge) {
            if (unreadCount > 0) {
                badge.textContent = unreadCount;
                badge.style.display = 'flex';
            } else {
                badge.style.display = 'none';
            }
        }
    <?php endif; ?>
});
</script>

</body>
</html>
