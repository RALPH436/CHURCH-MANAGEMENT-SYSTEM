<?php
session_start();
include "db.php";

if (!isset($_SESSION['user_id'])) {
    header('Content-Type: application/json');
    echo json_encode(['error' => 'Unauthorized']);
    exit();
}

if (!isset($_GET['id']) || empty($_GET['id'])) {
    header('Content-Type: application/json');
    echo json_encode(['error' => 'Member ID is required']);
    exit();
}

$member_id = intval($_GET['id']);

$query = "SELECT * FROM members WHERE id = $member_id";
$result = mysqli_query($conn, $query);

if (!$result || mysqli_num_rows($result) == 0) {
    header('Content-Type: application/json');
    echo json_encode(['error' => 'Member not found']);
    exit();
}

$member = mysqli_fetch_assoc($result);

header('Content-Type: application/json');
echo json_encode(['member' => $member]);
?>






