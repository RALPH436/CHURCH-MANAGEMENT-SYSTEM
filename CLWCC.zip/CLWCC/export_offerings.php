<?php
session_start();
include "db.php";

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Get filter parameters (same as offerings.php)
$search = isset($_GET['search']) ? mysqli_real_escape_string($conn, $_GET['search']) : '';
$type_filter = isset($_GET['type_filter']) ? mysqli_real_escape_string($conn, $_GET['type_filter']) : '';
$date_from = isset($_GET['date_from']) ? mysqli_real_escape_string($conn, $_GET['date_from']) : '';
$date_to = isset($_GET['date_to']) ? mysqli_real_escape_string($conn, $_GET['date_to']) : '';
$format = isset($_GET['format']) ? strtolower($_GET['format']) : 'csv';

// Build query (same as offerings.php)
$where = "1=1";
if (!empty($search)) {
    $where .= " AND (offering_type LIKE '%$search%' OR notes LIKE '%$search%')";
}
if (!empty($type_filter)) {
    $where .= " AND offering_type = '$type_filter'";
}
if (!empty($date_from)) {
    $where .= " AND offering_date >= '$date_from'";
}
if (!empty($date_to)) {
    $where .= " AND offering_date <= '$date_to'";
}

// Get all offerings records (no pagination for export)
$query = "SELECT * FROM offerings 
          WHERE $where 
          ORDER BY offering_date DESC, offering_type ASC";
$result = mysqli_query($conn, $query);

// Calculate total amount
$totalAmount = 0;
$totalQuery = "SELECT COALESCE(SUM(amount), 0) as total FROM offerings WHERE $where";
$totalResult = mysqli_query($conn, $totalQuery);
if ($totalResult) {
    $totalRow = mysqli_fetch_assoc($totalResult);
    $totalAmount = $totalRow['total'];
}

// Prepare data
$data = [];

// Header Section
$data[] = ['OFFERINGS REPORT'];
$data[] = []; // Empty row for spacing
if (!empty($date_from) && !empty($date_to)) {
    $data[] = ['Report Period:', date('F d, Y', strtotime($date_from)) . ' to ' . date('F d, Y', strtotime($date_to))];
} elseif (!empty($date_from)) {
    $data[] = ['From Date:', date('F d, Y', strtotime($date_from))];
} elseif (!empty($date_to)) {
    $data[] = ['Until Date:', date('F d, Y', strtotime($date_to))];
} else {
    $data[] = ['Report Period:', 'All Records'];
}
$data[] = ['Generated On:', date('F d, Y \a\t g:i A', strtotime('now'))];
if (!empty($type_filter)) {
    $data[] = ['Filter:', 'Type = ' . $type_filter];
}
if (!empty($search)) {
    $data[] = ['Search:', $search];
}
$data[] = []; // Empty row for spacing
$data[] = []; // Empty row for spacing

// Data Section
$data[] = ['═══════════════════════════════════════════════════════════════════════════════'];
$data[] = ['OFFERINGS DATA'];
$data[] = ['═══════════════════════════════════════════════════════════════════════════════'];
$data[] = []; // Empty row for spacing
$data[] = ['Date', 'Offering Type', 'Amount (₱)', 'Notes', 'Recorded At'];
$data[] = ['─────────────────────────────────────────────────────────────────────────────────'];

if ($result && mysqli_num_rows($result) > 0) {
    while ($row = mysqli_fetch_assoc($result)) {
        $data[] = [
            date('F d, Y', strtotime($row['offering_date'])),
            $row['offering_type'],
            '₱' . number_format($row['amount'], 2),
            $row['notes'] ?? '',
            date('F d, Y \a\t g:i A', strtotime($row['created_at']))
        ];
    }
} else {
    // If no data, still export header row
    $data[] = ['No records found for the selected criteria', '', '', '', ''];
}

$data[] = ['─────────────────────────────────────────────────────────────────────────────────'];
$data[] = []; // Empty row for spacing
$data[] = []; // Empty row for spacing

// Summary Section
$data[] = ['═══════════════════════════════════════════════════════════════════════════════'];
$data[] = ['SUMMARY'];
$data[] = ['═══════════════════════════════════════════════════════════════════════════════'];
$data[] = []; // Empty row for spacing
$data[] = ['Total Records', 'Total Amount (₱)'];
$data[] = ['─────────────────────────────────────────────────────────────────────────────────'];
$data[] = [number_format(mysqli_num_rows($result) > 0 ? mysqli_num_rows($result) : 0, 0), '₱' . number_format($totalAmount, 2)];
$data[] = []; // Empty row for spacing

// Generate filename based on date range
$filename = 'offerings';
if (!empty($date_from) && !empty($date_to)) {
    $filename .= '_' . $date_from . '_to_' . $date_to;
} elseif (!empty($date_from)) {
    $filename .= '_from_' . $date_from;
} elseif (!empty($date_to)) {
    $filename .= '_until_' . $date_to;
} else {
    $filename .= '_all';
}
$filename .= '_' . date('Y-m-d_His');

// Helper function to format CSV row for Excel compatibility
function formatCSVRow($row) {
    $formatted_row = [];
    foreach ($row as $cell) {
        // Convert cell to string and handle null values
        $cell = $cell ?? '';
        $cell = (string)$cell;
        
        // Escape cells that contain commas, quotes, or newlines
        if (strpos($cell, ',') !== false || strpos($cell, '"') !== false || strpos($cell, "\n") !== false || strpos($cell, "\r") !== false) {
            $cell = '"' . str_replace('"', '""', $cell) . '"';
        }
        $formatted_row[] = $cell;
    }
    return $formatted_row;
}

if ($format === 'excel' || $format === 'xlsx') {
    // Export as Excel (using CSV with Excel-compatible headers)
    $filename .= '.csv';
    header('Content-Type: application/vnd.ms-excel; charset=utf-8');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
    header('Pragma: public');
    header('Expires: 0');
    
    // Add BOM for UTF-8 to ensure Excel displays special characters correctly
    echo "\xEF\xBB\xBF";
    
    $output = fopen('php://output', 'w');
    
    foreach ($data as $row) {
        $formatted_row = formatCSVRow($row);
        fputcsv($output, $formatted_row, ',', '"', '');
    }
    
    fclose($output);
    exit();
} else {
    // Export as CSV
    $filename .= '.csv';
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
    header('Pragma: public');
    header('Expires: 0');
    
    // Add BOM for UTF-8
    echo "\xEF\xBB\xBF";
    
    $output = fopen('php://output', 'w');
    
    foreach ($data as $row) {
        $formatted_row = formatCSVRow($row);
        fputcsv($output, $formatted_row, ',', '"', '');
    }
    
    fclose($output);
    exit();
}
?>

