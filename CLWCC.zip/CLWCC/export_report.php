<?php
// Build a cleaner, fixed-width financial report layout for PDF
function buildFinancialPdfLines($reportPeriodText, $generatedOnText, $offeringsRows, $totalOfferings, $expensesRows, $totalExpenses, $netBalance) {
    $lines = [];

    $padRight = function($text, $length) {
        $text = (string)$text;
        $text = mb_substr($text, 0, $length);
        return str_pad($text, $length, ' ', STR_PAD_RIGHT);
    };
    $padLeft = function($text, $length) {
        $text = (string)$text;
        $text = mb_substr($text, 0, $length);
        return str_pad($text, $length, ' ', STR_PAD_LEFT);
    };

    $addTitle = function($title) use (&$lines) {
        $lines[] = $title;
        $lines[] = str_repeat('=', 80);
    };

    $addSubTitle = function($title) use (&$lines) {
        $lines[] = '';
        $lines[] = $title;
        $lines[] = str_repeat('-', 80);
    };

    $addTable = function($headers, $rows) use (&$lines, $padRight, $padLeft) {
        $lines[] = $padRight($headers[0], 14) . $padRight($headers[1], 24) . $padLeft($headers[2], 12) . '  ' . $padRight($headers[3], 26);
        $lines[] = str_repeat('-', 80);
        foreach ($rows as $row) {
            $date = isset($row['offering_date']) ? date('M d, Y', strtotime($row['offering_date'])) : (isset($row['expense_date']) ? date('M d, Y', strtotime($row['expense_date'])) : '');
            $type = $row['offering_type'] ?? ($row['expense_type'] ?? '');
            $amount = '₱' . number_format($row['amount'] ?? 0, 2);
            $notes = $row['notes'] ?? '';
            $lines[] = $padRight($date, 14) . $padRight($type, 24) . $padLeft($amount, 12) . '  ' . $padRight($notes, 26);
        }
    };

    // Header
    $addTitle('FINANCIAL REPORT');
    $lines[] = 'Report Period : ' . $reportPeriodText;
    $lines[] = 'Generated On  : ' . $generatedOnText;
    $lines[] = '';

    // Offerings
    $addSubTitle('Offerings');
    if (!empty($offeringsRows)) {
        $addTable(['Date', 'Offering Type', 'Amount', 'Notes'], $offeringsRows);
        $lines[] = str_repeat('-', 80);
        $lines[] = $padRight('', 38) . $padRight('TOTAL OFFERINGS', 18) . $padLeft('₱' . number_format($totalOfferings, 2), 12);
    } else {
        $lines[] = 'No offerings found for this period.';
    }

    // Expenses
    $addSubTitle('Expenses');
    if (!empty($expensesRows)) {
        $addTable(['Date', 'Expense Type', 'Amount', 'Notes'], $expensesRows);
        $lines[] = str_repeat('-', 80);
        $lines[] = $padRight('', 38) . $padRight('TOTAL EXPENSES', 18) . $padLeft('₱' . number_format($totalExpenses, 2), 12);
    } else {
        $lines[] = 'No expenses found for this period.';
    }

    // Summary
    $addSubTitle('Summary');
    $lines[] = $padRight('Total Offerings', 40) . $padLeft('₱' . number_format($totalOfferings, 2), 12);
    $lines[] = $padRight('Total Expenses', 40) . $padLeft('₱' . number_format($totalExpenses, 2), 12);
    $lines[] = str_repeat('-', 80);
    $lines[] = $padRight('NET BALANCE', 40) . $padLeft('₱' . number_format($netBalance, 2), 12);

    return $lines;
}
session_start();
include "db.php";

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$report_type = isset($_GET['type']) ? mysqli_real_escape_string($conn, $_GET['type']) : 'financial';
$date_from = isset($_GET['from']) ? mysqli_real_escape_string($conn, $_GET['from']) : date('Y-m-01');
$date_to = isset($_GET['to']) ? mysqli_real_escape_string($conn, $_GET['to']) : date('Y-m-t');
$format = isset($_GET['format']) ? strtolower($_GET['format']) : 'csv';

$data = [];
$filename = '';
$totalOfferings = 0;
$totalExpenses = 0;
$offeringsRows = [];
$expensesRows = [];
$reportPeriodText = date('F d, Y', strtotime($date_from)) . ' to ' . date('F d, Y', strtotime($date_to));
$generatedOnText = date('F d, Y \a\t g:i A', strtotime('now'));

if ($report_type == 'financial') {
    $filename = 'financial_report';
    
    // Financial Report Header Section - Clean format for CSV/Excel
    $data[] = ['Financial Report'];
    $data[] = ['Report Period', $reportPeriodText];
    $data[] = ['Generated On', $generatedOnText];
    $data[] = []; // Empty row for spacing
    
    // Offerings Section
    $offeringsTableCheck = mysqli_query($conn, "SHOW TABLES LIKE 'offerings'");
    if (mysqli_num_rows($offeringsTableCheck) > 0) {
        $offeringsQuery = "SELECT 
            offering_date,
            offering_type,
            amount,
            notes
            FROM offerings 
            WHERE offering_date >= '$date_from' AND offering_date <= '$date_to'
            ORDER BY offering_date DESC, offering_type ASC";
        $offeringsResult = mysqli_query($conn, $offeringsQuery);
        
        $data[] = ['OFFERINGS'];
        $data[] = []; // Empty row for spacing
        $data[] = ['Date', 'Type', 'Amount', 'Notes'];
        
        if ($offeringsResult && mysqli_num_rows($offeringsResult) > 0) {
            while ($row = mysqli_fetch_assoc($offeringsResult)) {
                $offeringsRows[] = $row;
                $data[] = [
                    date('Y-m-d', strtotime($row['offering_date'])),
                    $row['offering_type'],
                    number_format($row['amount'], 2, '.', ''), // Numeric format for Excel
                    $row['notes'] ?? ''
                ];
                $totalOfferings += $row['amount'];
            }
        } else {
            $data[] = ['No offerings found for this period', '', '', ''];
        }
        
        $data[] = []; // Empty row for spacing
        $data[] = ['Total Offerings', '', number_format($totalOfferings, 2, '.', ''), ''];
        $data[] = []; // Empty row for spacing
        $data[] = []; // Empty row for spacing
    }
    
    // Expenses Section
    $expensesTableCheck = mysqli_query($conn, "SHOW TABLES LIKE 'expenses'");
    if (mysqli_num_rows($expensesTableCheck) > 0) {
        $expensesQuery = "SELECT 
            expense_date,
            expense_type,
            amount,
            notes
            FROM expenses 
            WHERE expense_date >= '$date_from' AND expense_date <= '$date_to'
            ORDER BY expense_date DESC, expense_type ASC";
        $expensesResult = mysqli_query($conn, $expensesQuery);
        
        $data[] = ['EXPENSES'];
        $data[] = []; // Empty row for spacing
        $data[] = ['Date', 'Type', 'Amount', 'Notes'];
        
        if ($expensesResult && mysqli_num_rows($expensesResult) > 0) {
            while ($row = mysqli_fetch_assoc($expensesResult)) {
                $expensesRows[] = $row;
                $data[] = [
                    date('Y-m-d', strtotime($row['expense_date'])),
                    $row['expense_type'],
                    number_format($row['amount'], 2, '.', ''), // Numeric format for Excel
                    $row['notes'] ?? ''
                ];
                $totalExpenses += $row['amount'];
            }
        } else {
            $data[] = ['No expenses found for this period', '', '', ''];
        }
        
        $data[] = []; // Empty row for spacing
        $data[] = ['Total Expenses', '', number_format($totalExpenses, 2, '.', ''), ''];
        $data[] = []; // Empty row for spacing
        $data[] = []; // Empty row for spacing
    }
    
    // Summary Section
    $netBalance = $totalOfferings - $totalExpenses;
    $data[] = ['SUMMARY'];
    $data[] = []; // Empty row for spacing
    $data[] = ['Description', 'Amount'];
    $data[] = ['Total Offerings', number_format($totalOfferings, 2, '.', '')];
    $data[] = ['Total Expenses', number_format($totalExpenses, 2, '.', '')];
    $data[] = ['Net Balance', number_format($netBalance, 2, '.', '')];
    
} elseif ($report_type == 'attendance') {
    $filename = 'attendance_report';
    
    // Attendance Report Header Section - Clean format
    $data[] = ['Attendance Report'];
    $data[] = ['Report Period', date('F d, Y', strtotime($date_from)) . ' to ' . date('F d, Y', strtotime($date_to))];
    $data[] = ['Generated On', date('F d, Y \a\t g:i A', strtotime('now'))];
    $data[] = []; // Empty row for spacing
    
    $attendanceTableCheck = mysqli_query($conn, "SHOW TABLES LIKE 'attendance'");
    if (mysqli_num_rows($attendanceTableCheck) > 0) {
        $attendanceQuery = "SELECT 
            a.attendance_date,
            a.member_id,
            m.full_name,
            m.contact_number,
            a.event_type,
            a.status
            FROM attendance a
            LEFT JOIN members m ON a.member_id = m.id
            WHERE a.attendance_date >= '$date_from' AND a.attendance_date <= '$date_to'
            ORDER BY a.attendance_date DESC, m.full_name ASC";
        $attendanceResult = mysqli_query($conn, $attendanceQuery);
        
        $data[] = ['ATTENDANCE RECORDS'];
        $data[] = []; // Empty row for spacing
        $data[] = ['Date', 'Member ID', 'Member Name', 'Contact Number', 'Event Type', 'Status'];
        
        $totalRecords = 0;
        $uniqueMembers = [];
        
        if ($attendanceResult && mysqli_num_rows($attendanceResult) > 0) {
            while ($row = mysqli_fetch_assoc($attendanceResult)) {
                $data[] = [
                    date('Y-m-d', strtotime($row['attendance_date'])),
                    $row['member_id'] ?? 'N/A',
                    $row['full_name'] ?? 'N/A',
                    $row['contact_number'] ?? 'N/A',
                    $row['event_type'] ?? 'N/A',
                    $row['status'] ?? 'N/A'
                ];
                $totalRecords++;
                if ($row['member_id']) {
                    $uniqueMembers[$row['member_id']] = true;
                }
            }
        } else {
            $data[] = ['No attendance records found for this period', '', '', '', '', ''];
        }
        
        $data[] = []; // Empty row for spacing
        $data[] = []; // Empty row for spacing
        $data[] = ['ATTENDANCE SUMMARY'];
        $data[] = []; // Empty row for spacing
        $data[] = ['Metric', 'Count'];
        $data[] = ['Total Attendance Records', number_format($totalRecords, 0)];
        $data[] = ['Unique Members Attended', number_format(count($uniqueMembers), 0)];
    }
    
} elseif ($report_type == 'members') {
    $filename = 'member_report';
    
    // Member Report Header Section - Clean format
    $data[] = ['Member Report'];
    $data[] = ['Report Period', date('F d, Y', strtotime($date_from)) . ' to ' . date('F d, Y', strtotime($date_to))];
    $data[] = ['Generated On', date('F d, Y \a\t g:i A', strtotime('now'))];
    $data[] = []; // Empty row for spacing
    
    $membersTableCheck = mysqli_query($conn, "SHOW TABLES LIKE 'members'");
    if (mysqli_num_rows($membersTableCheck) > 0) {
        $membersQuery = "SELECT 
            id,
            full_name,
            birthdate,
            address,
            contact_number,
            status,
            created_at
            FROM members
            ORDER BY status DESC, full_name ASC";
        $membersResult = mysqli_query($conn, $membersQuery);
        
        $data[] = ['MEMBER LIST'];
        $data[] = []; // Empty row for spacing
        $data[] = ['ID', 'Full Name', 'Birthdate', 'Address', 'Contact Number', 'Status', 'Date Added'];
        
        $totalMembers = 0;
        $activeMembers = 0;
        $inactiveMembers = 0;
        $newInPeriod = 0;
        
        if ($membersResult && mysqli_num_rows($membersResult) > 0) {
            while ($row = mysqli_fetch_assoc($membersResult)) {
                $birthdate = !empty($row['birthdate']) ? date('Y-m-d', strtotime($row['birthdate'])) : 'N/A';
                $createdAt = !empty($row['created_at']) ? date('Y-m-d', strtotime($row['created_at'])) : 'N/A';
                
                $data[] = [
                    $row['id'],
                    $row['full_name'],
                    $birthdate,
                    $row['address'],
                    $row['contact_number'],
                    $row['status'],
                    $createdAt
                ];
                $totalMembers++;
                if ($row['status'] == 'Active') {
                    $activeMembers++;
                } else {
                    $inactiveMembers++;
                }
                if ($row['created_at'] >= $date_from && $row['created_at'] <= $date_to) {
                    $newInPeriod++;
                }
            }
        } else {
            $data[] = ['No members found', '', '', '', '', '', ''];
        }
        
        $data[] = []; // Empty row for spacing
        $data[] = []; // Empty row for spacing
        $data[] = ['MEMBER SUMMARY'];
        $data[] = []; // Empty row for spacing
        $data[] = ['Metric', 'Count'];
        $data[] = ['Total Members', number_format($totalMembers, 0)];
        $data[] = ['Active Members', number_format($activeMembers, 0)];
        $data[] = ['Inactive Members', number_format($inactiveMembers, 0)];
        $data[] = ['New Members (Period)', number_format($newInPeriod, 0)];
    }
}

// Generate filename
$filename .= '_' . $date_from . '_to_' . $date_to;
$filename .= '_' . date('Y-m-d_His');

// Simple PDF generator using basic PDF syntax (no external libs)
function exportAsSimplePdf($data, $filename) {
    // If data is already preformatted lines, use as-is; otherwise flatten rows into lines.
    $lines = [];
    $isPreformatted = !empty($data) && is_string($data[0]);
    if ($isPreformatted) {
        $lines = array_map(function($line) {
            $line = $line ?? '';
            $line = strip_tags((string)$line);
            return str_replace(["\r", "\n"], ' ', $line);
        }, $data);
    } else {
        foreach ($data as $row) {
            if (is_array($row)) {
                $line = implode(' | ', array_map(function($cell) {
                    $cell = $cell ?? '';
                    $cell = strip_tags((string)$cell);
                    $cell = str_replace(["\r", "\n"], ' ', $cell);
                    return $cell;
                }, $row));
                $lines[] = trim($line);
            } else {
                $cell = strip_tags((string)$row);
                $cell = str_replace(["\r", "\n"], ' ', $cell);
                $lines[] = trim($cell);
            }
        }
    }

    // PDF helpers
    $escapePdfText = function($text) {
        return str_replace(
            ['\\', '(', ')'],
            ['\\\\', '\\(', '\\)'],
            $text
        );
    };

    $pageWidth = 595;   // A4 width in points (72 dpi)
    $pageHeight = 842;  // A4 height in points
    $marginLeft = 40;
    $marginTop = $pageHeight - 40;
    $lineHeight = 14;
    $currentY = $marginTop;

    $contentStreams = [];
    $currentStream = '';

    foreach ($lines as $line) {
        if ($currentY < 40) {
            // Start a new page
            $contentStreams[] = $currentStream;
            $currentStream = '';
            $currentY = $marginTop;
        }
        $safeLine = $escapePdfText(substr($line, 0, 180)); // trim overly long lines
        $currentStream .= "BT /F1 12 Tf {$marginLeft} {$currentY} Td ({$safeLine}) Tj ET\n";
        $currentY -= $lineHeight;
    }
    $contentStreams[] = $currentStream;

    $objects = [];
    $pages = [];
    $fontObjId = 3;
    $pageIndex = 0;

    // Font object
    $objects[] = "<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>";

    // Page content and page objects
    foreach ($contentStreams as $stream) {
        $streamObjId = count($objects) + 1;
        $pageObjId = $streamObjId + 1;

        $objects[] = "<< /Length " . strlen($stream) . " >>\nstream\n{$stream}endstream";
        $objects[] = "<< /Type /Page /Parent 2 0 R /MediaBox [0 0 {$pageWidth} {$pageHeight}] /Contents {$streamObjId} 0 R /Resources << /Font << /F1 {$fontObjId} 0 R >> >> >>";
        $pages[] = "{$pageObjId} 0 R";
    }

    // Pages object
    $objects[] = "<< /Type /Pages /Kids [" . implode(' ', $pages) . "] /Count " . count($pages) . " >>";
    $pagesObjId = count($objects);

    // Catalog object
    $objects[] = "<< /Type /Catalog /Pages {$pagesObjId} 0 R >>";

    // Build PDF
    $pdf = "%PDF-1.4\n";
    $offsets = [];
    foreach ($objects as $i => $obj) {
        $objId = $i + 1;
        $offsets[$objId] = strlen($pdf);
        $pdf .= "{$objId} 0 obj\n{$obj}\nendobj\n";
    }

    // Xref
    $xrefOffset = strlen($pdf);
    $pdf .= "xref\n0 " . (count($objects) + 1) . "\n";
    $pdf .= "0000000000 65535 f \n";
    for ($i = 1; $i <= count($objects); $i++) {
        $pdf .= sprintf("%010d 00000 n \n", $offsets[$i]);
    }

    // Trailer
    $pdf .= "trailer\n<< /Size " . (count($objects) + 1) . " /Root " . count($objects) . " 0 R >>\nstartxref\n{$xrefOffset}\n%%EOF";

    // Output
    $filename .= '.pdf';
    header('Content-Type: application/pdf');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
    header('Pragma: public');
    header('Expires: 0');

    echo $pdf;
    exit();
}

// Helper function to format CSV row for Excel compatibility
function formatCSVRow($row) {
    $formatted_row = [];
    foreach ($row as $cell) {
        // Convert cell to string and handle null values
        $cell = $cell ?? '';
        $cell = (string)$cell;
        
        // Escape cells that contain commas, quotes, or newlines
        if (strpos($cell, ',') !== false || strpos($cell, '"') !== false || strpos($cell, "\n") !== false || strpos($cell, "\r") !== false) {
            $cell = '"' . str_replace('"', '""', $cell) . '"';
        }
        $formatted_row[] = $cell;
    }
    return $formatted_row;
}

// Clean data for CSV/Excel export - remove empty rows and ensure proper structure
function cleanDataForTabularExport($data) {
    $clean = [];
    foreach ($data as $row) {
        // Normalize row to array
        if (!is_array($row)) {
            $row = [$row];
        }

        // Skip completely empty rows
        $isEmpty = true;
        foreach ($row as $cell) {
            if (trim((string)$cell) !== '') {
                $isEmpty = false;
                break;
            }
        }
        
        if ($isEmpty) {
            // Keep empty rows for spacing, but ensure they have consistent column count
            if (!empty($clean)) {
                // Get column count from previous row
                $prevColCount = count($clean[count($clean) - 1]);
                $clean[] = array_fill(0, $prevColCount, '');
            }
            continue;
        }

        $clean[] = $row;
    }
    return $clean;
}

if ($format === 'excel' || $format === 'xlsx') {
    // Export as Excel (using CSV with Excel-compatible headers)
    $filename .= '.csv';
    header('Content-Type: application/vnd.ms-excel; charset=utf-8');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
    header('Pragma: public');
    header('Expires: 0');
    
    // Add BOM for UTF-8 to ensure Excel displays special characters correctly
    echo "\xEF\xBB\xBF";
    
    $output = fopen('php://output', 'w');
    
    $exportData = cleanDataForTabularExport($data);
    foreach ($exportData as $row) {
        $formatted_row = formatCSVRow($row);
        fputcsv($output, $formatted_row, ',', '"', '');
    }
    
    fclose($output);
    exit();
} elseif ($format === 'pdf') {
    if ($report_type === 'financial') {
        $lines = buildFinancialPdfLines($reportPeriodText, $generatedOnText, $offeringsRows, $totalOfferings, $expensesRows, $totalExpenses, $netBalance);
        exportAsSimplePdf($lines, $filename);
    } else {
        exportAsSimplePdf($data, $filename);
    }
} else {
    // Export as CSV
    $filename .= '.csv';
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
    header('Pragma: public');
    header('Expires: 0');
    
    // Add BOM for UTF-8
    echo "\xEF\xBB\xBF";
    
    $output = fopen('php://output', 'w');
    
    $exportData = cleanDataForTabularExport($data);
    foreach ($exportData as $row) {
        $formatted_row = formatCSVRow($row);
        fputcsv($output, $formatted_row, ',', '"', '');
    }
    
    fclose($output);
    exit();
}
?>
