<?php
session_start();
include "db.php";

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Get filter parameters (same as attendance.php)
$search = isset($_GET['search']) ? mysqli_real_escape_string($conn, $_GET['search']) : '';
$status_filter = isset($_GET['status_filter']) ? mysqli_real_escape_string($conn, $_GET['status_filter']) : '';
$event_filter = isset($_GET['event_filter']) ? mysqli_real_escape_string($conn, $_GET['event_filter']) : '';
$date_from = isset($_GET['date_from']) ? mysqli_real_escape_string($conn, $_GET['date_from']) : '';
$date_to = isset($_GET['date_to']) ? mysqli_real_escape_string($conn, $_GET['date_to']) : '';
$format = isset($_GET['format']) ? strtolower($_GET['format']) : 'csv';

// Build query (same as attendance.php)
$where = "1=1";
if (!empty($search)) {
    $where .= " AND (m.full_name LIKE '%$search%' OR a.event_type LIKE '%$search%' OR a.notes LIKE '%$search%')";
}
if (!empty($status_filter)) {
    $where .= " AND a.status = '$status_filter'";
}
if (!empty($event_filter)) {
    $where .= " AND a.event_type = '$event_filter'";
}
if (!empty($date_from)) {
    $where .= " AND a.attendance_date >= '$date_from'";
}
if (!empty($date_to)) {
    $where .= " AND a.attendance_date <= '$date_to'";
}

// Get all attendance records (no pagination for export)
$query = "SELECT a.*, m.full_name, m.contact_number 
          FROM attendance a 
          LEFT JOIN members m ON a.member_id = m.id 
          WHERE $where 
          ORDER BY a.attendance_date DESC, m.full_name ASC";
$result = mysqli_query($conn, $query);

// Calculate summary statistics
$totalRecords = 0;
$uniqueMembers = [];
$statusCounts = [];
$eventTypeCounts = [];

if ($result && mysqli_num_rows($result) > 0) {
    while ($row = mysqli_fetch_assoc($result)) {
        $totalRecords++;
        if ($row['member_id']) {
            $uniqueMembers[$row['member_id']] = true;
        }
        $status = $row['status'] ?? 'Unknown';
        $statusCounts[$status] = ($statusCounts[$status] ?? 0) + 1;
        $eventType = $row['event_type'] ?? 'Unknown';
        $eventTypeCounts[$eventType] = ($eventTypeCounts[$eventType] ?? 0) + 1;
    }
    // Reset result pointer
    mysqli_data_seek($result, 0);
}

// Prepare data in clean, tabular form (no decorative lines)
$data = [];

// Header Section
$data[] = ['Attendance Report'];

if (!empty($date_from) && !empty($date_to)) {
    $data[] = ['Report Period', date('F d, Y', strtotime($date_from)) . ' to ' . date('F d, Y', strtotime($date_to))];
} elseif (!empty($date_from)) {
    $data[] = ['Report Period', 'From ' . date('F d, Y', strtotime($date_from))];
} elseif (!empty($date_to)) {
    $data[] = ['Report Period', 'Until ' . date('F d, Y', strtotime($date_to))];
} else {
    $data[] = ['Report Period', 'All Records'];
}
$data[] = ['Generated On', date('F d, Y \a\t g:i A', strtotime('now'))];
if (!empty($status_filter)) {
    $data[] = ['Filter - Status', $status_filter];
}
if (!empty($event_filter)) {
    $data[] = ['Filter - Event Type', $event_filter];
}
if (!empty($search)) {
    $data[] = ['Search', $search];
}
$data[] = []; // spacing

// Attendance Records
$data[] = ['Attendance Records'];
$data[] = ['Date', 'Member Name', 'Contact Number', 'Event Type', 'Status', 'Notes', 'Recorded At'];

if ($result && mysqli_num_rows($result) > 0) {
    while ($row = mysqli_fetch_assoc($result)) {
        $data[] = [
            date('Y-m-d', strtotime($row['attendance_date'])),
            $row['full_name'] ?? 'N/A',
            $row['contact_number'] ?? 'N/A',
            $row['event_type'] ?? 'N/A',
            $row['status'] ?? 'N/A',
            $row['notes'] ?? '',
            date('Y-m-d H:i', strtotime($row['created_at']))
        ];
    }
} else {
    $data[] = ['No records found for the selected criteria', '', '', '', '', '', ''];
}

$data[] = []; // spacing

// Summary Section
$data[] = ['Summary'];
$data[] = ['Metric', 'Count'];
$data[] = ['Total Attendance Records', number_format($totalRecords, 0)];
$data[] = ['Unique Members Attended', number_format(count($uniqueMembers), 0)];
$data[] = []; // spacing

// Status Breakdown
if (!empty($statusCounts)) {
    $data[] = ['Status Breakdown', 'Count'];
    foreach ($statusCounts as $status => $count) {
        $data[] = [$status, number_format($count, 0)];
    }
    $data[] = []; // spacing
}

// Event Type Breakdown
if (!empty($eventTypeCounts)) {
    $data[] = ['Event Type Breakdown', 'Count'];
    foreach ($eventTypeCounts as $eventType => $count) {
        $data[] = [$eventType, number_format($count, 0)];
    }
    $data[] = []; // spacing
}

// Helper function to format CSV row for Excel compatibility
function formatCSVRow($row) {
    $formatted_row = [];
    foreach ($row as $cell) {
        $cell = $cell ?? '';
        $cell = (string)$cell;

        if (strpos($cell, ',') !== false || strpos($cell, '"') !== false || strpos($cell, "\n") !== false || strpos($cell, "\r") !== false) {
            $cell = '"' . str_replace('"', '""', $cell) . '"';
        }
        $formatted_row[] = $cell;
    }
    return $formatted_row;
}

// Ensure consistent column counts and drop empty spacer rows
function normalizeRows($data) {
    $normalized = [];
    $maxCols = 0;
    // Find max column count
    foreach ($data as $row) {
        if (is_array($row)) {
            $maxCols = max($maxCols, count($row));
        }
    }
    if ($maxCols === 0) {
        $maxCols = 1;
    }
    foreach ($data as $row) {
        if (!is_array($row)) {
            $row = [$row];
        }
        // Pad to max columns for alignment (keeps spacing rows)
        if (count($row) < $maxCols) {
            $row = array_pad($row, $maxCols, '');
        }
        $normalized[] = $row;
    }
    return $normalized;
}

// Generate filename
$filename = 'attendance';
if (!empty($date_from) && !empty($date_to)) {
    $filename .= '_' . $date_from . '_to_' . $date_to;
} elseif (!empty($date_from)) {
    $filename .= '_from_' . $date_from;
} elseif (!empty($date_to)) {
    $filename .= '_until_' . $date_to;
} else {
    $filename .= '_all';
}
$filename .= '_' . date('Y-m-d_His');

if ($format === 'excel' || $format === 'xlsx') {
    // Export as Excel (using CSV with Excel-compatible headers)
    $filename .= '.csv';
    header('Content-Type: application/vnd.ms-excel; charset=utf-8');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
    header('Pragma: public');
    header('Expires: 0');
    
    // Add BOM for UTF-8 to ensure Excel displays special characters correctly
    echo "\xEF\xBB\xBF";
    
    $output = fopen('php://output', 'w');

    $rows = normalizeRows($data);
    foreach ($rows as $row) {
        $formatted_row = formatCSVRow($row);
        fputcsv($output, $formatted_row, ',', '"', '');
    }
    
    fclose($output);
    exit();
} else {
    // Export as CSV
    $filename .= '.csv';
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
    header('Pragma: public');
    header('Expires: 0');
    
    // Add BOM for UTF-8
    echo "\xEF\xBB\xBF";
    
    $output = fopen('php://output', 'w');

    $rows = normalizeRows($data);
    foreach ($rows as $row) {
        $formatted_row = formatCSVRow($row);
        fputcsv($output, $formatted_row, ',', '"', '');
    }
    
    fclose($output);
    exit();
}
?>

