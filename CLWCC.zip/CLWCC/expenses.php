<?php
session_start();
include "db.php";

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Create expenses table if it doesn't exist
$createTable = "CREATE TABLE IF NOT EXISTS expenses (
    id INT AUTO_INCREMENT PRIMARY KEY,
    expense_date DATE NOT NULL,
    expense_type VARCHAR(100) NOT NULL,
    amount DECIMAL(10, 2) NOT NULL,
    notes TEXT DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_date (expense_date),
    INDEX idx_type (expense_type)
)";

mysqli_query($conn, $createTable);

// Alter existing table if expense_type is ENUM (migration)
$tableCheck = mysqli_query($conn, "SHOW TABLES LIKE 'expenses'");
if (mysqli_num_rows($tableCheck) > 0) {
    $columnCheck = mysqli_query($conn, "SHOW COLUMNS FROM expenses WHERE Field = 'expense_type'");
    if ($columnCheck && $row = mysqli_fetch_assoc($columnCheck)) {
        if (strpos($row['Type'], 'enum') !== false) {
            // Table exists with ENUM, alter it to VARCHAR
            mysqli_query($conn, "ALTER TABLE expenses MODIFY expense_type VARCHAR(100) NOT NULL");
        }
    }
}

$message = '';
$messageType = '';

// Handle form submission
if (isset($_POST['add_expense'])) {
    $expense_date = mysqli_real_escape_string($conn, $_POST['expense_date']);
    $expense_type = mysqli_real_escape_string($conn, $_POST['expense_type']);
    $amount = floatval($_POST['amount']);
    $notes = mysqli_real_escape_string($conn, $_POST['notes'] ?? '');

    if ($amount <= 0) {
        $message = 'Amount must be greater than 0.';
        $messageType = 'error';
    } else {
        $query = "INSERT INTO expenses (expense_date, expense_type, amount, notes) 
                  VALUES ('$expense_date', '$expense_type', $amount, '$notes')";
        
        if (mysqli_query($conn, $query)) {
            $message = 'Expense recorded successfully!';
            $messageType = 'success';
        } else {
            $message = 'Error recording expense: ' . mysqli_error($conn);
            $messageType = 'error';
        }
    }
}

// Handle update expense
if (isset($_POST['update_expense'])) {
    $id = intval($_POST['expense_id']);
    $expense_date = mysqli_real_escape_string($conn, $_POST['expense_date']);
    $expense_type = mysqli_real_escape_string($conn, $_POST['expense_type']);
    $amount = floatval($_POST['amount']);
    $notes = mysqli_real_escape_string($conn, $_POST['notes'] ?? '');

    if ($amount <= 0) {
        $message = 'Amount must be greater than 0.';
        $messageType = 'error';
    } else {
        $query = "UPDATE expenses SET expense_date='$expense_date', 
                  expense_type='$expense_type', amount=$amount, notes='$notes' WHERE id=$id";
        
        if (mysqli_query($conn, $query)) {
            $message = 'Expense updated successfully!';
            $messageType = 'success';
        } else {
            $message = 'Error updating expense: ' . mysqli_error($conn);
            $messageType = 'error';
        }
    }
}

// Get expense data for editing
$edit_expense = null;
if (isset($_GET['edit'])) {
    $id = intval($_GET['edit']);
    $query = "SELECT * FROM expenses WHERE id = $id";
    $result = mysqli_query($conn, $query);
    if (mysqli_num_rows($result) > 0) {
        $edit_expense = mysqli_fetch_assoc($result);
    }
}

// Handle delete
if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    $deleteQuery = "DELETE FROM expenses WHERE id = $id";
    if (mysqli_query($conn, $deleteQuery)) {
        $message = 'Expense record deleted successfully!';
        $messageType = 'success';
    } else {
        $message = 'Error deleting expense: ' . mysqli_error($conn);
        $messageType = 'error';
    }
}

// Get filter and search parameters
$search = isset($_GET['search']) ? mysqli_real_escape_string($conn, $_GET['search']) : '';
$date_from = isset($_GET['date_from']) ? mysqli_real_escape_string($conn, $_GET['date_from']) : '';
$date_to = isset($_GET['date_to']) ? mysqli_real_escape_string($conn, $_GET['date_to']) : '';
$sort_by = isset($_GET['sort_by']) ? mysqli_real_escape_string($conn, $_GET['sort_by']) : 'expense_date';
$sort_order = isset($_GET['sort_order']) ? mysqli_real_escape_string($conn, $_GET['sort_order']) : 'DESC';
$entries_per_page = isset($_GET['entries']) ? intval($_GET['entries']) : 10;
$page = isset($_GET['page']) ? intval($_GET['page']) : 1;
$offset = ($page - 1) * $entries_per_page;

// Validate sort_by to prevent SQL injection
$allowed_sort_columns = ['expense_date', 'expense_type', 'amount', 'created_at'];
if (!in_array($sort_by, $allowed_sort_columns)) {
    $sort_by = 'expense_date';
}
$sort_order = strtoupper($sort_order) === 'ASC' ? 'ASC' : 'DESC';

// Build query
$where = "1=1";
if (!empty($search)) {
    $where .= " AND (expense_type LIKE '%$search%' OR notes LIKE '%$search%')";
}
if (!empty($date_from)) {
    $where .= " AND expense_date >= '$date_from'";
}
if (!empty($date_to)) {
    $where .= " AND expense_date <= '$date_to'";
}

// Get total count
$countQuery = "SELECT COUNT(*) as total FROM expenses WHERE $where";
$countResult = mysqli_query($conn, $countQuery);
$totalRecords = mysqli_fetch_assoc($countResult)['total'];
$totalPages = ceil($totalRecords / $entries_per_page);

// Get expenses records
$query = "SELECT * FROM expenses 
          WHERE $where 
          ORDER BY $sort_by $sort_order 
          LIMIT $entries_per_page OFFSET $offset";
$result = mysqli_query($conn, $query);

// Get total amount for display (filtered)
$totalAmountQuery = "SELECT COALESCE(SUM(amount), 0) as total FROM expenses WHERE $where";
$totalAmountResult = mysqli_query($conn, $totalAmountQuery);
$totalAmount = mysqli_fetch_assoc($totalAmountResult)['total'];

// Get total expenses (all expenses, not filtered)
$totalExpensesQuery = "SELECT COALESCE(SUM(amount), 0) as total FROM expenses";
$totalExpensesResult = mysqli_query($conn, $totalExpensesQuery);
$totalExpenses = mysqli_fetch_assoc($totalExpensesResult)['total'];

// Get total offerings (all offerings)
$totalOfferings = 0;
$offeringsTableCheck = mysqli_query($conn, "SHOW TABLES LIKE 'offerings'");
if (mysqli_num_rows($offeringsTableCheck) > 0) {
    $totalOfferingsQuery = "SELECT COALESCE(SUM(amount), 0) as total FROM offerings";
    $totalOfferingsResult = mysqli_query($conn, $totalOfferingsQuery);
    if ($totalOfferingsResult) {
        $totalOfferings = mysqli_fetch_assoc($totalOfferingsResult)['total'];
    }
}

// Calculate remaining offering (total offerings - total expenses)
$remainingOffering = $totalOfferings - $totalExpenses;

// Get notification count (events and birthdays)
$notificationCount = 0;
// Get upcoming events for notifications (next 7 days)
$eventsTableCheck = mysqli_query($conn, "SHOW TABLES LIKE 'events'");
if (mysqli_num_rows($eventsTableCheck) > 0) {
    $today = date('Y-m-d');
    $nextWeek = date('Y-m-d', strtotime('+7 days'));
    $eventsQuery = "SELECT COUNT(*) as total FROM events WHERE event_date >= '$today' AND event_date <= '$nextWeek'";
    $eventsResult = mysqli_query($conn, $eventsQuery);
    if ($eventsResult && $row = mysqli_fetch_assoc($eventsResult)) {
        $notificationCount += $row['total'];
    }
}

// Get birthday celebrants (today and next 7 days)
$membersTableCheck = mysqli_query($conn, "SHOW TABLES LIKE 'members'");
if (mysqli_num_rows($membersTableCheck) > 0) {
    $todayFull = date('Y-m-d');
    $nextWeek = date('Y-m-d', strtotime('+7 days'));
    $birthdayQuery = "SELECT birthdate FROM members WHERE status = 'Active'";
    $birthdayResult = mysqli_query($conn, $birthdayQuery);
    if ($birthdayResult) {
        while ($member = mysqli_fetch_assoc($birthdayResult)) {
            $birthdate = $member['birthdate'];
            $birthMonthDay = date('m-d', strtotime($birthdate));
            $currentYear = date('Y');
            $birthdayThisYear = $currentYear . '-' . $birthMonthDay;
            $birthdayDate = date('Y-m-d', strtotime($birthdayThisYear));
            if ($birthdayDate < $todayFull) {
                $nextYear = date('Y', strtotime('+1 year'));
                $birthdayThisYear = $nextYear . '-' . $birthMonthDay;
                $birthdayDate = date('Y-m-d', strtotime($birthdayThisYear));
            }
            if ($birthdayDate >= $todayFull && $birthdayDate <= $nextWeek) {
                $notificationCount++;
            }
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Expenses - Church Management</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        html, body {
            height: 100%;
            overflow: hidden;
        }
        body { 
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; 
            background: #f5f7fa;
            color: #333;
            position: relative;
        }
        .header {
            background: linear-gradient(135deg, #0a1929 0%, #1a2f4a 100%);
            color: white;
            padding: 0 30px;
            height: 70px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            width: 100%;
            z-index: 1000;
        }
        .header h1 {
            font-size: 24px;
            font-weight: 600;
            margin: 0;
            line-height: 1;
        }
        .header-right {
            display: flex;
            align-items: center;
            gap: 20px;
            height: 100%;
        }
        .user-info {
            display: flex;
            align-items: center;
            gap: 10px;
            height: 100%;
        }
        .user-name {
            font-size: 14px;
            font-weight: 500;
            margin: 0;
            line-height: 1;
        }
        .notification-icon {
            position: relative;
            cursor: pointer;
            padding: 8px;
            border-radius: 50%;
            transition: background-color 0.3s;
            display: flex;
            align-items: center;
            justify-content: center;
            width: 36px;
            height: 36px;
            text-decoration: none;
            color: white;
        }
        .notification-icon:hover {
            background: rgba(255, 255, 255, 0.1);
        }
        .notification-badge {
            position: absolute;
            top: 0;
            right: 0;
            background: #ff4444;
            color: white;
            border-radius: 50%;
            width: 20px;
            height: 20px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 11px;
            font-weight: 600;
            border: 2px solid #0a1929;
        }
        .notification-icon svg {
            width: 20px;
            height: 20px;
            stroke: white;
        }
        .notification-dropdown-container {
            position: relative;
        }
        .notification-dropdown {
            position: absolute;
            top: calc(100% + 10px);
            right: 0;
            width: 380px;
            max-height: 500px;
            background: white;
            border-radius: 8px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.15);
            z-index: 1001;
            display: none;
            overflow: hidden;
            animation: slideDown 0.2s ease-out;
        }
        @keyframes slideDown {
            from {
                opacity: 0;
                transform: translateY(-10px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        .notification-dropdown.active {
            display: block;
        }
        .notification-dropdown-header {
            padding: 15px 20px;
            border-bottom: 1px solid #e0e0e0;
            background: #f8f9fa;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .notification-dropdown-header h3 {
            margin: 0;
            font-size: 16px;
            font-weight: 600;
            color: #0a1929;
        }
        .notification-dropdown-close {
            background: none;
            border: none;
            font-size: 20px;
            cursor: pointer;
            color: #666;
            padding: 0;
            width: 24px;
            height: 24px;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 4px;
            transition: background 0.2s;
        }
        .notification-dropdown-close:hover {
            background: #e0e0e0;
        }
        .notification-dropdown-list {
            max-height: 400px;
            overflow-y: auto;
            overflow-x: hidden;
        }
        .notification-dropdown-list::-webkit-scrollbar {
            width: 6px;
        }
        .notification-dropdown-list::-webkit-scrollbar-track {
            background: #f1f1f1;
        }
        .notification-dropdown-list::-webkit-scrollbar-thumb {
            background: #888;
            border-radius: 3px;
        }
        .notification-dropdown-list::-webkit-scrollbar-thumb:hover {
            background: #555;
        }
        .notification-dropdown-item {
            padding: 12px 20px;
            border-bottom: 1px solid #f0f0f0;
            cursor: pointer;
            transition: background 0.2s;
            display: flex;
            align-items: flex-start;
            gap: 12px;
            position: relative;
        }
        .notification-dropdown-item:hover {
            background: #f8f9fa;
        }
        .notification-dropdown-item.read {
            opacity: 0.7;
            background: #fafafa;
        }
        .notification-dropdown-item.read:hover {
            background: #f0f0f0;
        }
        .notification-dropdown-item-icon {
            font-size: 24px;
            flex-shrink: 0;
            margin-top: 2px;
            display: inline-flex;
            align-items: center;
            justify-content: center;
        }
        .notification-dropdown-item-icon svg {
            width: 20px;
            height: 20px;
        }
        .notification-dropdown-item-content {
            flex: 1;
            min-width: 0;
        }
        .notification-dropdown-item-title {
            font-weight: 600;
            font-size: 14px;
            color: #0a1929;
            margin-bottom: 4px;
        }
        .notification-dropdown-item-message {
            font-size: 13px;
            color: #666;
            line-height: 1.4;
            margin-bottom: 6px;
            word-wrap: break-word;
        }
        .notification-dropdown-item-time {
            font-size: 11px;
            color: #999;
        }
        .notification-dropdown-item-profile {
            width: 36px;
            height: 36px;
            border-radius: 50%;
            object-fit: cover;
            border: 2px solid #e0e0e0;
            flex-shrink: 0;
        }
        .notification-dropdown-empty {
            padding: 40px 20px;
            text-align: center;
            color: #999;
            font-size: 14px;
        }
        .notification-dropdown-footer {
            padding: 12px 20px;
            border-top: 1px solid #e0e0e0;
            text-align: center;
            background: #f8f9fa;
        }
        .notification-dropdown-footer a {
            color: #2D7A8F;
            text-decoration: none;
            font-size: 13px;
            font-weight: 500;
        }
        .notification-dropdown-footer a:hover {
            text-decoration: underline;
        }
        @media (max-width: 768px) {
            .notification-dropdown {
                width: 320px;
                right: -10px;
            }
        }
        .logout-btn {
            background: #2D7A8F;
            color: white;
            padding: 8px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 14px;
            font-weight: 500;
            text-decoration: none;
            transition: background-color 0.3s;
        }
        .logout-btn:hover {
            background: #1F5F6F;
        }
        .container {
            display: flex;
            margin-top: 70px;
            height: calc(100vh - 70px);
            position: relative;
            overflow: hidden;
        }
        .sidebar {
            width: 260px;
            background: #fff;
            box-shadow: 2px 0 10px rgba(0, 0, 0, 0.05);
            position: fixed;
            left: 0;
            top: 70px;
            height: calc(100vh - 70px);
            overflow-y: auto;
            z-index: 999;
        }
        .sidebar-menu {
            list-style: none;
            padding: 20px 0;
        }
        .sidebar-menu li {
            margin-bottom: 5px;
        }
        .sidebar-menu a {
            display: flex;
            align-items: center;
            padding: 14px 25px;
            color: #555;
            text-decoration: none;
            font-size: 15px;
            font-weight: 500;
            transition: all 0.3s;
            border-left: 3px solid transparent;
        }
        .sidebar-menu a:hover {
            background: #f5f7fa;
            color: #2D7A8F;
            border-left-color: #2D7A8F;
        }
        .sidebar-menu a.active {
            background: #f0f8ff;
            color: #2D7A8F;
            border-left-color: #2D7A8F;
            font-weight: 600;
        }
        .sidebar-menu a .sidebar-icon {
            width: 18px;
            height: 18px;
            margin-right: 12px;
            flex-shrink: 0;
            stroke: currentColor;
            opacity: 0.7;
            transition: opacity 0.3s;
        }
        .sidebar-menu a:hover .sidebar-icon,
        .sidebar-menu a.active .sidebar-icon {
            opacity: 1;
        }
        .main-content {
            flex: 1;
            margin-left: 260px;
            padding: 30px;
            background: #f5f7fa;
            height: calc(100vh - 70px);
            overflow-y: auto;
            overflow-x: hidden;
        }
        .page-title {
            font-size: 28px;
            font-weight: 700;
            color: #0a1929;
            margin-bottom: 10px;
        }
        .page-subtitle {
            color: #666;
            font-size: 14px;
            margin-bottom: 30px;
        }
        .content-section {
            background: white;
            padding: 25px;
            border-radius: 8px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);
            margin-bottom: 20px;
        }
        .section-title {
            font-size: 18px;
            font-weight: 600;
            color: #0a1929;
            margin-bottom: 15px;
            padding-bottom: 10px;
            border-bottom: 2px solid #f0f0f0;
        }
        .form-group {
            margin-bottom: 20px;
        }
        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 500;
            color: #333;
            font-size: 14px;
        }
        .form-group input,
        .form-group select,
        .form-group textarea {
            width: 100%;
            padding: 12px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 14px;
            font-family: inherit;
            transition: border-color 0.3s;
        }
        .form-group input:focus,
        .form-group select:focus,
        .form-group textarea:focus {
            outline: none;
            border-color: #2D7A8F;
        }
        .form-group textarea {
            resize: vertical;
            min-height: 80px;
        }
        .form-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
        }
        .btn {
            padding: 12px 24px;
            border: none;
            border-radius: 4px;
            font-size: 14px;
            font-weight: 500;
            cursor: pointer;
            transition: background-color 0.3s;
            text-decoration: none;
            display: inline-block;
        }
        .btn-primary {
            background: #2D7A8F;
            color: white;
        }
        .btn-primary:hover {
            background: #1F5F6F;
        }
        .btn-danger {
            background: #d32f2f;
            color: white;
            padding: 6px 12px;
            font-size: 12px;
        }
        .btn-danger:hover {
            background: #b71c1c;
        }
        .btn-edit {
            background: #2D7A8F;
            color: white;
            padding: 6px 12px;
            font-size: 12px;
            margin-right: 5px;
        }
        .btn-edit:hover {
            background: #1F5F6F;
        }
        .action-buttons {
            display: flex;
            gap: 5px;
            flex-wrap: wrap;
        }
        .message {
            padding: 12px 20px;
            border-radius: 4px;
            margin-bottom: 20px;
            font-size: 14px;
        }
        .message.success {
            background: #e8f5e9;
            color: #2e7d32;
            border-left: 3px solid #2e7d32;
        }
        .message.error {
            background: #ffebee;
            color: #d32f2f;
            border-left: 3px solid #d32f2f;
        }
        .table-container {
            overflow-x: auto;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        thead {
            background: #f5f7fa;
        }
        th, td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #e0e0e0;
        }
        th {
            font-weight: 600;
            color: #0a1929;
            font-size: 13px;
            text-transform: uppercase;
        }
        th.sortable {
            cursor: pointer;
            user-select: none;
            position: relative;
            padding-right: 20px;
        }
        th.sortable:hover {
            background: #e8e8e8;
        }
        th.sortable::after {
            content: ' ↕';
            position: absolute;
            right: 5px;
            opacity: 0.5;
        }
        th.sort-asc::after {
            content: ' ↑';
            opacity: 1;
        }
        th.sort-desc::after {
            content: ' ↓';
            opacity: 1;
        }
        td {
            font-size: 14px;
            color: #555;
        }
        tr:hover {
            background: #f9f9f9;
        }
        .amount {
            font-weight: 600;
            color: #d32f2f;
        }
        .total-summary {
            background: #f8f9fa;
            padding: 20px;
            border-radius: 8px;
            margin-bottom: 0;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.05);
            transition: transform 0.2s, box-shadow 0.2s;
        }
        .total-summary:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        .total-summary-label {
            font-size: 14px;
            color: #666;
            font-weight: 500;
        }
        .total-summary-value {
            font-size: 24px;
            font-weight: 700;
            color: #d32f2f;
        }
        .filters {
            display: flex;
            gap: 15px;
            margin-bottom: 20px;
            flex-wrap: wrap;
            align-items: center;
        }
        .filter-group {
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .filter-group label {
            font-size: 14px;
            font-weight: 500;
            color: #555;
        }
        .filter-group input,
        .filter-group select {
            padding: 8px 12px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 14px;
        }
        .filter-group input:focus,
        .filter-group select:focus {
            outline: none;
            border-color: #2D7A8F;
        }
        .pagination {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-top: 20px;
            flex-wrap: wrap;
            gap: 15px;
        }
        .pagination-info {
            font-size: 14px;
            color: #666;
        }
        .pagination-controls {
            display: flex;
            gap: 10px;
            align-items: center;
        }
        .pagination-btn {
            padding: 8px 12px;
            border: 1px solid #ddd;
            background: white;
            border-radius: 4px;
            cursor: pointer;
            font-size: 14px;
            text-decoration: none;
            color: #333;
            transition: all 0.3s;
        }
        .pagination-btn:hover:not(.disabled) {
            background: #2D7A8F;
            color: white;
            border-color: #2D7A8F;
        }
        .pagination-btn.disabled {
            opacity: 0.5;
            cursor: not-allowed;
        }
        .pagination-btn.active {
            background: #2D7A8F;
            color: white;
            border-color: #2D7A8F;
        }
        .no-data {
            text-align: center;
            padding: 40px;
            color: #888;
            font-size: 14px;
        }
        @media (max-width: 768px) {
            .sidebar {
                width: 100%;
                position: relative;
                top: 0;
                height: auto;
            }
            .main-content {
                margin-left: 0;
            }
            .container {
                flex-direction: column;
            }
            .header {
                flex-direction: column;
                gap: 15px;
                padding: 15px;
            }
            .form-row {
                grid-template-columns: 1fr;
            }
            .filters {
                flex-direction: column;
                align-items: stretch;
            }
        }
    </style>
</head>
<body>

<div class="header">
    <h1>Church Management System</h1>
    <div class="header-right">
        <div class="notification-dropdown-container">
            <div class="notification-icon" id="notificationIcon" onclick="toggleNotificationDropdown(event)" title="View Notifications">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"></path>
                    <path d="M13.73 21a2 2 0 0 1-3.46 0"></path>
                </svg>
                <?php if ($notificationCount > 0): ?>
                    <span class="notification-badge" id="notificationBadge"><?php echo $notificationCount; ?></span>
                <?php endif; ?>
            </div>
            <div class="notification-dropdown" id="notificationDropdown">
                <div class="notification-dropdown-header">
                    <h3>Notifications</h3>
                    <button class="notification-dropdown-close" onclick="closeNotificationDropdown()" title="Close">×</button>
                </div>
                <div class="notification-dropdown-list" id="notificationDropdownList">
                    <div class="notification-dropdown-empty">Loading notifications...</div>
                </div>
                <div class="notification-dropdown-footer">
                    <a href="dashboard.php#notifications-section" onclick="closeNotificationDropdown();">View All Notifications</a>
                </div>
            </div>
        </div>
        <div class="user-info">
            <span class="user-name">Welcome, <?php echo htmlspecialchars($_SESSION['fullname']); ?></span>
        </div>
        <a href="logout.php" class="logout-btn">Logout</a>
    </div>
</div>

<div class="container">
    <aside class="sidebar">
        <ul class="sidebar-menu">
            <li><a href="dashboard.php">
                <svg class="sidebar-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="7" height="7"></rect><rect x="14" y="3" width="7" height="7"></rect><rect x="14" y="14" width="7" height="7"></rect><rect x="3" y="14" width="7" height="7"></rect></svg>
                Dashboard</a></li>
            <li><a href="members.php">
                <svg class="sidebar-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path><circle cx="9" cy="7" r="4"></circle><path d="M23 21v-2a4 4 0 0 0-3-3.87"></path><path d="M16 3.13a4 4 0 0 1 0 7.75"></path></svg>
                Members</a></li>
            <li><a href="attendance.php">
                <svg class="sidebar-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path><polyline points="14 2 14 8 20 8"></polyline><line x1="16" y1="13" x2="8" y2="13"></line><line x1="16" y1="17" x2="8" y2="17"></line><polyline points="10 9 9 9 8 9"></line></svg>
                Attendance</a></li>
            <li><a href="offerings.php">
                <svg class="sidebar-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="12" y1="1" x2="12" y2="23"></line><path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"></path></svg>
                Offerings</a></li>
            <li><a href="expenses.php" class="active">
                <svg class="sidebar-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path><polyline points="14 2 14 8 20 8"></polyline><line x1="16" y1="13" x2="8" y2="13"></line><line x1="16" y1="17" x2="8" y2="17"></line></svg>
                Expenses</a></li>
            <li><a href="events.php">
                <svg class="sidebar-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect><line x1="16" y1="2" x2="16" y2="6"></line><line x1="8" y1="2" x2="8" y2="6"></line><line x1="3" y1="10" x2="21" y2="10"></line></svg>
                Events</a></li>
            <li><a href="reports.php">
                <svg class="sidebar-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="20" x2="18" y2="10"></line><line x1="12" y1="20" x2="12" y2="4"></line><line x1="6" y1="20" x2="6" y2="14"></line></svg>
                Reports</a></li>
            <li><a href="users.php">
                <svg class="sidebar-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path><circle cx="12" cy="7" r="4"></circle></svg>
                Users</a></li>
        </ul>
    </aside>

    <main class="main-content">
        <h2 class="page-title">Expenses Management</h2>
        <p class="page-subtitle">Record and manage church expenses</p>

        <?php if (!empty($message)): ?>
            <div class="message <?php echo $messageType; ?>">
                <?php echo htmlspecialchars($message); ?>
            </div>
        <?php endif; ?>

        <!-- Add/Edit Expense Form -->
        <div class="content-section">
            <h3 class="section-title"><?php echo $edit_expense ? 'Edit Expense Record' : 'Record New Expense'; ?></h3>
            <?php if ($edit_expense): ?>
                <a href="expenses.php" class="btn btn-primary" style="margin-bottom: 15px; display: inline-block;">Cancel Edit</a>
            <?php endif; ?>
            <form method="POST">
                <?php if ($edit_expense): ?>
                    <input type="hidden" name="expense_id" value="<?php echo $edit_expense['id']; ?>">
                <?php endif; ?>
                <div class="form-row">
                    <div class="form-group">
                        <label for="expense_date">Date *</label>
                        <input type="date" id="expense_date" name="expense_date" 
                               value="<?php echo $edit_expense ? $edit_expense['expense_date'] : date('Y-m-d'); ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="expense_type">Expense Type *</label>
                        <input type="text" id="expense_type" name="expense_type" 
                               value="<?php echo $edit_expense ? htmlspecialchars($edit_expense['expense_type']) : ''; ?>" 
                               placeholder="e.g., Utilities, Maintenance, Supplies, etc." required>
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label for="amount">Amount (₱) *</label>
                        <input type="number" id="amount" name="amount" step="0.01" min="0.01" 
                               value="<?php echo $edit_expense ? number_format($edit_expense['amount'], 2, '.', '') : ''; ?>" 
                               placeholder="0.00" required>
                    </div>
                </div>
                <div class="form-group">
                    <label for="notes">Notes (Optional)</label>
                    <textarea id="notes" name="notes" placeholder="Additional notes about this expense..."><?php echo $edit_expense ? htmlspecialchars($edit_expense['notes']) : ''; ?></textarea>
                </div>
                <?php if ($edit_expense): ?>
                    <button type="submit" name="update_expense" class="btn btn-primary">Update Expense</button>
                <?php else: ?>
                    <button type="submit" name="add_expense" class="btn btn-primary">Record Expense</button>
                <?php endif; ?>
            </form>
        </div>

        <!-- Expenses History -->
        <div class="content-section">
            <h3 class="section-title">Expenses History</h3>
            
            <!-- Total Summary -->
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 20px; margin-bottom: 25px;">
                <div class="total-summary" style="background: linear-gradient(135deg, #e8f5e9 0%, #c8e6c9 100%); border-left: 4px solid #2e7d32;">
                    <div style="display: flex; flex-direction: column;">
                        <span class="total-summary-label" style="font-size: 13px; margin-bottom: 8px; color: #555;">Total Offering</span>
                        <span class="total-summary-value" style="color: #2e7d32; font-size: 28px;">₱<?php echo number_format($totalOfferings, 2); ?></span>
                    </div>
                </div>
                <div class="total-summary" style="background: linear-gradient(135deg, #ffebee 0%, #ffcdd2 100%); border-left: 4px solid #d32f2f;">
                    <div style="display: flex; flex-direction: column;">
                        <span class="total-summary-label" style="font-size: 13px; margin-bottom: 8px; color: #555;">Total Expenses</span>
                        <span class="total-summary-value" style="color: #d32f2f; font-size: 28px;">₱<?php echo number_format($totalExpenses, 2); ?></span>
                    </div>
                </div>
                <div class="total-summary" style="background: linear-gradient(135deg, <?php echo $remainingOffering >= 0 ? '#e8f5e9 0%, #c8e6c9 100%' : '#ffebee 0%, #ffcdd2 100%'; ?>); border-left: 4px solid <?php echo $remainingOffering >= 0 ? '#2e7d32' : '#d32f2f'; ?>;">
                    <div style="display: flex; flex-direction: column;">
                        <span class="total-summary-label" style="font-size: 13px; margin-bottom: 8px; color: #555;">Remaining Offering</span>
                        <span class="total-summary-value" style="color: <?php echo $remainingOffering >= 0 ? '#2e7d32' : '#d32f2f'; ?>; font-size: 28px; font-weight: 700;">₱<?php echo number_format($remainingOffering, 2); ?></span>
                    </div>
                </div>
            </div>
            
            <!-- Filters and Search -->
            <form method="GET" action="expenses.php" class="filters">
                <div class="filter-group">
                    <label for="search">Search:</label>
                    <input type="text" id="search" name="search" placeholder="Search by type, notes..." value="<?php echo htmlspecialchars($search); ?>">
                </div>
                <div class="filter-group">
                    <label for="date_from">From:</label>
                    <input type="date" id="date_from" name="date_from" value="<?php echo htmlspecialchars($date_from); ?>">
                </div>
                <div class="filter-group">
                    <label for="date_to">To:</label>
                    <input type="date" id="date_to" name="date_to" value="<?php echo htmlspecialchars($date_to); ?>">
                </div>
                <div class="filter-group">
                    <label for="entries">Show:</label>
                    <select id="entries" name="entries" onchange="this.form.submit()">
                        <option value="10" <?php echo $entries_per_page == 10 ? 'selected' : ''; ?>>10</option>
                        <option value="25" <?php echo $entries_per_page == 25 ? 'selected' : ''; ?>>25</option>
                        <option value="50" <?php echo $entries_per_page == 50 ? 'selected' : ''; ?>>50</option>
                        <option value="100" <?php echo $entries_per_page == 100 ? 'selected' : ''; ?>>100</option>
                    </select>
                </div>
                <button type="submit" class="btn btn-primary">Filter</button>
                <?php if (!empty($search) || !empty($date_from) || !empty($date_to)): ?>
                    <a href="expenses.php" class="btn btn-primary" style="background: #666;">Clear</a>
                <?php endif; ?>
            </form>

            <!-- Table -->
            <div class="table-container">
                <?php if (mysqli_num_rows($result) > 0): ?>
                    <table>
                        <thead>
                            <tr>
                                <th class="sortable <?php echo $sort_by == 'expense_date' ? ($sort_order == 'ASC' ? 'sort-asc' : 'sort-desc') : ''; ?>" 
                                    onclick="sortTable('expense_date')">Date</th>
                                <th class="sortable <?php echo $sort_by == 'expense_type' ? ($sort_order == 'ASC' ? 'sort-asc' : 'sort-desc') : ''; ?>" 
                                    onclick="sortTable('expense_type')">Expense Type</th>
                                <th class="sortable <?php echo $sort_by == 'amount' ? ($sort_order == 'ASC' ? 'sort-asc' : 'sort-desc') : ''; ?>" 
                                    onclick="sortTable('amount')">Amount</th>
                                <th>Notes</th>
                                <th class="sortable <?php echo $sort_by == 'created_at' ? ($sort_order == 'ASC' ? 'sort-asc' : 'sort-desc') : ''; ?>" 
                                    onclick="sortTable('created_at')">Recorded At</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while ($expense = mysqli_fetch_assoc($result)): ?>
                                <tr>
                                    <td><?php echo date('M d, Y', strtotime($expense['expense_date'])); ?></td>
                                    <td><?php echo htmlspecialchars($expense['expense_type']); ?></td>
                                    <td class="amount">₱<?php echo number_format($expense['amount'], 2); ?></td>
                                    <td><?php echo htmlspecialchars($expense['notes'] ?? ''); ?></td>
                                    <td><?php echo date('M d, Y h:i A', strtotime($expense['created_at'])); ?></td>
                                    <td>
                                        <div class="action-buttons">
                                            <?php
                                            $editParams = $_GET;
                                            $editParams['edit'] = $expense['id'];
                                            unset($editParams['delete']);
                                            $editUrl = 'expenses.php?' . http_build_query($editParams);
                                            ?>
                                            <a href="<?php echo $editUrl; ?>" class="btn btn-edit">Edit</a>
                                            <?php
                                            $deleteParams = $_GET;
                                            $deleteParams['delete'] = $expense['id'];
                                            unset($deleteParams['edit']);
                                            $deleteUrl = 'expenses.php?' . http_build_query($deleteParams);
                                            ?>
                                            <a href="<?php echo $deleteUrl; ?>" class="btn btn-danger" onclick="return confirm('Are you sure you want to delete this expense record?');">Delete</a>
                                        </div>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                <?php else: ?>
                    <div class="no-data">No expenses found.</div>
                <?php endif; ?>
            </div>

            <!-- Pagination -->
            <?php if ($totalPages > 1): ?>
                <div class="pagination">
                    <div class="pagination-info">
                        Showing <?php echo $offset + 1; ?> to <?php echo min($offset + $entries_per_page, $totalRecords); ?> of <?php echo $totalRecords; ?> entries
                    </div>
                    <div class="pagination-controls">
                        <?php
                        $queryParams = $_GET;
                        unset($queryParams['page']);
                        $baseUrl = 'expenses.php?' . http_build_query($queryParams);
                        ?>
                        <a href="<?php echo $baseUrl . ($page > 1 ? '&page=' . ($page - 1) : ''); ?>" class="pagination-btn <?php echo $page == 1 ? 'disabled' : ''; ?>">Previous</a>
                        <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                            <?php if ($i == 1 || $i == $totalPages || ($i >= $page - 2 && $i <= $page + 2)): ?>
                                <a href="<?php echo $baseUrl . '&page=' . $i; ?>" class="pagination-btn <?php echo $page == $i ? 'active' : ''; ?>"><?php echo $i; ?></a>
                            <?php elseif ($i == $page - 3 || $i == $page + 3): ?>
                                <span class="pagination-btn disabled">...</span>
                            <?php endif; ?>
                        <?php endfor; ?>
                        <a href="<?php echo $baseUrl . '&page=' . ($page + 1); ?>" class="pagination-btn <?php echo $page >= $totalPages ? 'disabled' : ''; ?>">Next</a>
                    </div>
                </div>
            <?php else: ?>
                <div class="pagination-info" style="margin-top: 20px;">
                    Showing <?php echo $totalRecords; ?> of <?php echo $totalRecords; ?> entries
                </div>
            <?php endif; ?>
        </div>
    </main>
</div>

<script>
function sortTable(column) {
    const urlParams = new URLSearchParams(window.location.search);
    const currentSort = urlParams.get('sort_by');
    const currentOrder = urlParams.get('sort_order') || 'DESC';
    
    let newOrder = 'ASC';
    if (currentSort === column && currentOrder === 'ASC') {
        newOrder = 'DESC';
    }
    
    urlParams.set('sort_by', column);
    urlParams.set('sort_order', newOrder);
    
    window.location.href = 'expenses.php?' + urlParams.toString();
}

// Notification Dropdown Functions
let notificationDropdownOpen = false;
let readNotifications = JSON.parse(localStorage.getItem('readNotifications') || '[]');

function toggleNotificationDropdown(event) {
    event.stopPropagation();
    const dropdown = document.getElementById('notificationDropdown');
    
    if (dropdown.classList.contains('active')) {
        closeNotificationDropdown();
    } else {
        dropdown.classList.add('active');
        notificationDropdownOpen = true;
        loadNotifications();
    }
}

function closeNotificationDropdown() {
    const dropdown = document.getElementById('notificationDropdown');
    dropdown.classList.remove('active');
    notificationDropdownOpen = false;
}

function loadNotifications() {
    const list = document.getElementById('notificationDropdownList');
    
    fetch('get_notifications.php')
        .then(response => response.json())
        .then(data => {
            if (data.error) {
                list.innerHTML = '<div class="notification-dropdown-empty">Error loading notifications</div>';
            } else {
                renderNotifications(data.notifications);
            }
        })
        .catch(error => {
            console.error('Error:', error);
            list.innerHTML = '<div class="notification-dropdown-empty">Error loading notifications</div>';
        });
}

function renderNotifications(notifications) {
    const list = document.getElementById('notificationDropdownList');
    
    if (!notifications || notifications.length === 0) {
        list.innerHTML = '<div class="notification-dropdown-empty">No notifications at this time.</div>';
        return;
    }
    
    list.innerHTML = notifications.map(notif => {
        const isRead = readNotifications.includes(notif.id);
        const timeAgo = formatTimeAgo(notif.timestamp, notif.days_until);
        const profileImg = notif.profile_picture && notif.profile_picture.trim() !== '' 
            ? `<img src="${escapeHtml(notif.profile_picture)}" alt="Profile" class="notification-dropdown-item-profile" onerror="this.style.display='none'">`
            : '';
        
        return `
            <div class="notification-dropdown-item ${isRead ? 'read' : ''}" 
                 onclick="markNotificationAsRead('${notif.id}', this)" 
                 data-notification-id="${notif.id}">
                <span class="notification-dropdown-item-icon">${notif.icon}</span>
                ${profileImg}
                <div class="notification-dropdown-item-content">
                    <div class="notification-dropdown-item-title">${escapeHtml(notif.title)}</div>
                    <div class="notification-dropdown-item-message">${escapeHtml(notif.message)}</div>
                    <div class="notification-dropdown-item-time">${timeAgo}</div>
                </div>
            </div>
        `;
    }).join('');
}

function markNotificationAsRead(notificationId, element) {
    if (!readNotifications.includes(notificationId)) {
        readNotifications.push(notificationId);
        localStorage.setItem('readNotifications', JSON.stringify(readNotifications));
        element.classList.add('read');
        updateNotificationBadge();
    }
}

function formatTimeAgo(timestamp, daysUntil) {
    const now = Math.floor(Date.now() / 1000);
    const diff = timestamp - now;
    const days = Math.floor(diff / 86400);
    
    if (days < 0) {
        return 'Past';
    } else if (days === 0) {
        return 'Today';
    } else if (days === 1) {
        return 'Tomorrow';
    } else {
        return `In ${days} days`;
    }
}

function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

function updateNotificationBadge() {
    const badge = document.getElementById('notificationBadge');
    if (!badge) return;
    
    const allItems = document.querySelectorAll('.notification-dropdown-item');
    const unreadCount = Array.from(allItems).filter(item => !item.classList.contains('read')).length;
    
    if (unreadCount > 0) {
        badge.textContent = unreadCount;
        badge.style.display = 'flex';
    } else {
        badge.style.display = 'none';
    }
}

// Close dropdown when clicking outside
document.addEventListener('click', function(event) {
    const container = document.querySelector('.notification-dropdown-container');
    if (container && !container.contains(event.target) && notificationDropdownOpen) {
        closeNotificationDropdown();
    }
});

// Load notifications on page load to update badge
document.addEventListener('DOMContentLoaded', function() {
    fetch('get_notifications.php')
        .then(response => response.json())
        .then(data => {
            if (!data.error && data.notifications) {
                const unreadCount = data.notifications.filter(n => !readNotifications.includes(n.id)).length;
                const badge = document.getElementById('notificationBadge');
                if (badge) {
                    if (unreadCount > 0) {
                        badge.textContent = unreadCount;
                        badge.style.display = 'flex';
                    } else {
                        badge.style.display = 'none';
                    }
                }
            }
        })
        .catch(error => console.error('Error loading notifications:', error));
});
</script>

</body>
</html>

