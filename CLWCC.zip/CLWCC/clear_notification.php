<?php
session_start();
include "db.php";

if (!isset($_SESSION['user_id'])) {
    header('Content-Type: application/json');
    echo json_encode(['error' => 'Unauthorized']);
    exit();
}

// Initialize cleared notifications array in session if not exists
if (!isset($_SESSION['cleared_notifications'])) {
    $_SESSION['cleared_notifications'] = [];
}

// Get notification ID from POST
if (isset($_POST['notification_id'])) {
    $notificationId = mysqli_real_escape_string($conn, $_POST['notification_id']);
    
    // Add to cleared notifications if not already there
    if (!in_array($notificationId, $_SESSION['cleared_notifications'])) {
        $_SESSION['cleared_notifications'][] = $notificationId;
    }
    
    header('Content-Type: application/json');
    echo json_encode(['success' => true, 'message' => 'Notification cleared']);
} else {
    header('Content-Type: application/json');
    echo json_encode(['error' => 'Notification ID required']);
}
?>






