<?php
session_start();
include "db.php";

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Create members table if it doesn't exist
$createTable = "CREATE TABLE IF NOT EXISTS members (
    id INT AUTO_INCREMENT PRIMARY KEY,
    profile_picture VARCHAR(255) DEFAULT NULL,
    full_name VARCHAR(255) NOT NULL,
    birthdate DATE NOT NULL,
    address TEXT NOT NULL,
    contact_number VARCHAR(20) NOT NULL,
    status ENUM('Active', 'Inactive') DEFAULT 'Active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
)";

mysqli_query($conn, $createTable);

// Create uploads directory if it doesn't exist
if (!file_exists('uploads/members')) {
    mkdir('uploads/members', 0777, true);
}

$message = '';
$messageType = '';

// Handle form submission
if (isset($_POST['add_member'])) {
    $full_name = mysqli_real_escape_string($conn, $_POST['full_name']);
    $birthdate = mysqli_real_escape_string($conn, $_POST['birthdate']);
    $address = mysqli_real_escape_string($conn, $_POST['address']);
    $contact_number = mysqli_real_escape_string($conn, $_POST['contact_number']);
    $status = mysqli_real_escape_string($conn, $_POST['status']);
    $member_since_input = isset($_POST['member_since']) ? mysqli_real_escape_string($conn, $_POST['member_since']) : '';
    $profile_picture = '';

    // Handle file upload
    if (isset($_FILES['profile_picture']) && $_FILES['profile_picture']['error'] == 0) {
        $allowed = ['jpg', 'jpeg', 'png', 'gif'];
        $filename = $_FILES['profile_picture']['name'];
        $filetmp = $_FILES['profile_picture']['tmp_name'];
        $ext = strtolower(pathinfo($filename, PATHINFO_EXTENSION));

        if (in_array($ext, $allowed)) {
            $new_filename = uniqid() . '_' . time() . '.' . $ext;
            $upload_path = 'uploads/members/' . $new_filename;
            
            if (move_uploaded_file($filetmp, $upload_path)) {
                $profile_picture = $upload_path;
            } else {
                $message = 'Error uploading profile picture.';
                $messageType = 'error';
            }
        } else {
            $message = 'Invalid file type. Only JPG, JPEG, PNG, and GIF are allowed.';
            $messageType = 'error';
        }
    }

    if (empty($message)) {
        $member_since_db = !empty($member_since_input) && strtotime($member_since_input) !== false
            ? date('Y-m-d 00:00:00', strtotime($member_since_input))
            : date('Y-m-d 00:00:00');

        $query = "INSERT INTO members (profile_picture, full_name, birthdate, address, contact_number, status, created_at) 
                  VALUES ('$profile_picture', '$full_name', '$birthdate', '$address', '$contact_number', '$status', '$member_since_db')";
        
        if (mysqli_query($conn, $query)) {
            $message = 'Member added successfully!';
            $messageType = 'success';
        } else {
            $message = 'Error adding member: ' . mysqli_error($conn);
            $messageType = 'error';
        }
    }
}

// Handle update member
if (isset($_POST['update_member'])) {
    $id = intval($_POST['member_id']);
    $full_name = mysqli_real_escape_string($conn, $_POST['full_name']);
    $birthdate = mysqli_real_escape_string($conn, $_POST['birthdate']);
    $address = mysqli_real_escape_string($conn, $_POST['address']);
    $contact_number = mysqli_real_escape_string($conn, $_POST['contact_number']);
    $status = mysqli_real_escape_string($conn, $_POST['status']);
    $member_since_input = isset($_POST['member_since']) ? mysqli_real_escape_string($conn, $_POST['member_since']) : '';
    
    // Get current profile picture
    $query = "SELECT profile_picture, created_at FROM members WHERE id = $id";
    $result = mysqli_query($conn, $query);
    $current_member = mysqli_fetch_assoc($result);
    $profile_picture = $current_member['profile_picture'];
    
    // Handle file upload if new file is provided
    if (isset($_FILES['profile_picture']) && $_FILES['profile_picture']['error'] == 0) {
        $allowed = ['jpg', 'jpeg', 'png', 'gif'];
        $filename = $_FILES['profile_picture']['name'];
        $filetmp = $_FILES['profile_picture']['tmp_name'];
        $ext = strtolower(pathinfo($filename, PATHINFO_EXTENSION));

        if (in_array($ext, $allowed)) {
            // Delete old profile picture if exists
            if ($profile_picture && file_exists($profile_picture)) {
                unlink($profile_picture);
            }
            
            $new_filename = uniqid() . '_' . time() . '.' . $ext;
            $upload_path = 'uploads/members/' . $new_filename;
            
            if (move_uploaded_file($filetmp, $upload_path)) {
                $profile_picture = $upload_path;
            } else {
                $message = 'Error uploading profile picture.';
                $messageType = 'error';
            }
        } else {
            $message = 'Invalid file type. Only JPG, JPEG, PNG, and GIF are allowed.';
            $messageType = 'error';
        }
    }

    if (empty($message)) {
        $member_since_db = !empty($member_since_input) && strtotime($member_since_input) !== false
            ? date('Y-m-d 00:00:00', strtotime($member_since_input))
            : $current_member['created_at'];

        $query = "UPDATE members SET full_name='$full_name', birthdate='$birthdate', address='$address', 
                  contact_number='$contact_number', status='$status', profile_picture='$profile_picture', created_at='$member_since_db' WHERE id=$id";
        
        if (mysqli_query($conn, $query)) {
            $message = 'Member updated successfully!';
            $messageType = 'success';
        } else {
            $message = 'Error updating member: ' . mysqli_error($conn);
            $messageType = 'error';
        }
    }
}

// Get member data for editing
$edit_member = null;
if (isset($_GET['edit'])) {
    $id = intval($_GET['edit']);
    $query = "SELECT * FROM members WHERE id = $id";
    $result = mysqli_query($conn, $query);
    if (mysqli_num_rows($result) > 0) {
        $edit_member = mysqli_fetch_assoc($result);
    }
}

// Handle delete
if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    $query = "SELECT profile_picture FROM members WHERE id = $id";
    $result = mysqli_query($conn, $query);
    $member = mysqli_fetch_assoc($result);
    
    if ($member && $member['profile_picture'] && file_exists($member['profile_picture'])) {
        unlink($member['profile_picture']);
    }
    
    $deleteQuery = "DELETE FROM members WHERE id = $id";
    if (mysqli_query($conn, $deleteQuery)) {
        $message = 'Member deleted successfully!';
        $messageType = 'success';
    } else {
        $message = 'Error deleting member: ' . mysqli_error($conn);
        $messageType = 'error';
    }
}

// Get filter and search parameters
$search = isset($_GET['search']) ? mysqli_real_escape_string($conn, $_GET['search']) : '';
$status_filter = isset($_GET['status_filter']) ? mysqli_real_escape_string($conn, $_GET['status_filter']) : '';
$entries_per_page = isset($_GET['entries']) ? intval($_GET['entries']) : 10;
$page = isset($_GET['page']) ? intval($_GET['page']) : 1;
$offset = ($page - 1) * $entries_per_page;

// Build query
$where = "1=1";
if (!empty($search)) {
    $where .= " AND (full_name LIKE '%$search%' OR address LIKE '%$search%' OR contact_number LIKE '%$search%')";
}
if (!empty($status_filter)) {
    $where .= " AND status = '$status_filter'";
}

// Get total count
$countQuery = "SELECT COUNT(*) as total FROM members WHERE $where";
$countResult = mysqli_query($conn, $countQuery);
$totalRecords = mysqli_fetch_assoc($countResult)['total'];
$totalPages = ceil($totalRecords / $entries_per_page);

// Get members
$query = "SELECT * FROM members WHERE $where ORDER BY created_at DESC LIMIT $entries_per_page OFFSET $offset";
$result = mysqli_query($conn, $query);

// Get notification count (events and birthdays)
$notificationCount = 0;
// Get upcoming events for notifications (next 7 days)
$eventsTableCheck = mysqli_query($conn, "SHOW TABLES LIKE 'events'");
if (mysqli_num_rows($eventsTableCheck) > 0) {
    $today = date('Y-m-d');
    $nextWeek = date('Y-m-d', strtotime('+7 days'));
    $eventsQuery = "SELECT COUNT(*) as total FROM events WHERE event_date >= '$today' AND event_date <= '$nextWeek'";
    $eventsResult = mysqli_query($conn, $eventsQuery);
    if ($eventsResult && $row = mysqli_fetch_assoc($eventsResult)) {
        $notificationCount += $row['total'];
    }
}

// Get birthday celebrants (today and next 7 days)
$membersTableCheck = mysqli_query($conn, "SHOW TABLES LIKE 'members'");
if (mysqli_num_rows($membersTableCheck) > 0) {
    $todayFull = date('Y-m-d');
    $nextWeek = date('Y-m-d', strtotime('+7 days'));
    $birthdayQuery = "SELECT birthdate FROM members WHERE status = 'Active'";
    $birthdayResult = mysqli_query($conn, $birthdayQuery);
    if ($birthdayResult) {
        while ($member = mysqli_fetch_assoc($birthdayResult)) {
            $birthdate = $member['birthdate'];
            $birthMonthDay = date('m-d', strtotime($birthdate));
            $currentYear = date('Y');
            $birthdayThisYear = $currentYear . '-' . $birthMonthDay;
            $birthdayDate = date('Y-m-d', strtotime($birthdayThisYear));
            if ($birthdayDate < $todayFull) {
                $nextYear = date('Y', strtotime('+1 year'));
                $birthdayThisYear = $nextYear . '-' . $birthMonthDay;
                $birthdayDate = date('Y-m-d', strtotime($birthdayThisYear));
            }
            if ($birthdayDate >= $todayFull && $birthdayDate <= $nextWeek) {
                $notificationCount++;
            }
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Members - Church Management</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        html, body {
            height: 100%;
            overflow: hidden;
        }
        body { 
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; 
            background: #f5f7fa;
            color: #333;
            position: relative;
        }
        .header {
            background: linear-gradient(135deg, #0a1929 0%, #1a2f4a 100%);
            color: white;
            padding: 0 30px;
            height: 70px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            width: 100%;
            z-index: 1000;
        }
        .header h1 {
            font-size: 24px;
            font-weight: 600;
            margin: 0;
            line-height: 1;
        }
        .header-right {
            display: flex;
            align-items: center;
            gap: 20px;
            height: 100%;
        }
        .user-info {
            display: flex;
            align-items: center;
            gap: 10px;
            height: 100%;
        }
        .user-name {
            font-size: 14px;
            font-weight: 500;
            margin: 0;
            line-height: 1;
        }
        .notification-icon {
            position: relative;
            cursor: pointer;
            padding: 8px;
            border-radius: 50%;
            transition: background-color 0.3s;
            display: flex;
            align-items: center;
            justify-content: center;
            width: 36px;
            height: 36px;
            text-decoration: none;
            color: white;
        }
        .notification-icon:hover {
            background: rgba(255, 255, 255, 0.1);
        }
        .notification-badge {
            position: absolute;
            top: 0;
            right: 0;
            background: #ff4444;
            color: white;
            border-radius: 50%;
            width: 20px;
            height: 20px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 11px;
            font-weight: 600;
            border: 2px solid #0a1929;
        }
        .notification-icon svg {
            width: 20px;
            height: 20px;
            stroke: white;
        }
        .notification-dropdown-container {
            position: relative;
        }
        .notification-dropdown {
            position: absolute;
            top: calc(100% + 10px);
            right: 0;
            width: 380px;
            max-height: 500px;
            background: white;
            border-radius: 8px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.15);
            z-index: 1001;
            display: none;
            overflow: hidden;
            animation: slideDown 0.2s ease-out;
        }
        @keyframes slideDown {
            from {
                opacity: 0;
                transform: translateY(-10px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        .notification-dropdown.active {
            display: block;
        }
        .notification-dropdown-header {
            padding: 15px 20px;
            border-bottom: 1px solid #e0e0e0;
            background: #f8f9fa;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .notification-dropdown-header h3 {
            margin: 0;
            font-size: 16px;
            font-weight: 600;
            color: #0a1929;
        }
        .notification-dropdown-close {
            background: none;
            border: none;
            font-size: 20px;
            cursor: pointer;
            color: #666;
            padding: 0;
            width: 24px;
            height: 24px;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 4px;
            transition: background 0.2s;
        }
        .notification-dropdown-close:hover {
            background: #e0e0e0;
        }
        .notification-dropdown-list {
            max-height: 400px;
            overflow-y: auto;
            overflow-x: hidden;
        }
        .notification-dropdown-list::-webkit-scrollbar {
            width: 6px;
        }
        .notification-dropdown-list::-webkit-scrollbar-track {
            background: #f1f1f1;
        }
        .notification-dropdown-list::-webkit-scrollbar-thumb {
            background: #888;
            border-radius: 3px;
        }
        .notification-dropdown-list::-webkit-scrollbar-thumb:hover {
            background: #555;
        }
        .notification-dropdown-item {
            padding: 12px 20px;
            border-bottom: 1px solid #f0f0f0;
            cursor: pointer;
            transition: background 0.2s;
            display: flex;
            align-items: flex-start;
            gap: 12px;
            position: relative;
        }
        .notification-dropdown-item:hover {
            background: #f8f9fa;
        }
        .notification-dropdown-item.read {
            opacity: 0.7;
            background: #fafafa;
        }
        .notification-dropdown-item.read:hover {
            background: #f0f0f0;
        }
        .notification-dropdown-item-icon {
            font-size: 24px;
            flex-shrink: 0;
            margin-top: 2px;
            display: inline-flex;
            align-items: center;
            justify-content: center;
        }
        .notification-dropdown-item-icon svg {
            width: 20px;
            height: 20px;
        }
        .notification-dropdown-item-content {
            flex: 1;
            min-width: 0;
        }
        .notification-dropdown-item-title {
            font-weight: 600;
            font-size: 14px;
            color: #0a1929;
            margin-bottom: 4px;
        }
        .notification-dropdown-item-message {
            font-size: 13px;
            color: #666;
            line-height: 1.4;
            margin-bottom: 6px;
            word-wrap: break-word;
        }
        .notification-dropdown-item-time {
            font-size: 11px;
            color: #999;
        }
        .notification-dropdown-item-profile {
            width: 36px;
            height: 36px;
            border-radius: 50%;
            object-fit: cover;
            border: 2px solid #e0e0e0;
            flex-shrink: 0;
        }
        .notification-dropdown-empty {
            padding: 40px 20px;
            text-align: center;
            color: #999;
            font-size: 14px;
        }
        .notification-dropdown-footer {
            padding: 12px 20px;
            border-top: 1px solid #e0e0e0;
            text-align: center;
            background: #f8f9fa;
        }
        .notification-dropdown-footer a {
            color: #2D7A8F;
            text-decoration: none;
            font-size: 13px;
            font-weight: 500;
        }
        .notification-dropdown-footer a:hover {
            text-decoration: underline;
        }
        @media (max-width: 768px) {
            .notification-dropdown {
                width: 320px;
                right: -10px;
            }
        }
        .logout-btn {
            background: #2D7A8F;
            color: white;
            padding: 8px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 14px;
            font-weight: 500;
            text-decoration: none;
            transition: background-color 0.3s;
        }
        .logout-btn:hover {
            background: #1F5F6F;
        }
        .container {
            display: flex;
            margin-top: 70px;
            height: calc(100vh - 70px);
            position: relative;
            overflow: hidden;
        }
        .sidebar {
            width: 260px;
            background: #fff;
            box-shadow: 2px 0 10px rgba(0, 0, 0, 0.05);
            position: fixed;
            left: 0;
            top: 70px;
            height: calc(100vh - 70px);
            overflow-y: auto;
            z-index: 999;
        }
        .sidebar-menu {
            list-style: none;
            padding: 20px 0;
        }
        .sidebar-menu li {
            margin-bottom: 5px;
        }
        .sidebar-menu a {
            display: flex;
            align-items: center;
            padding: 14px 25px;
            color: #555;
            text-decoration: none;
            font-size: 15px;
            font-weight: 500;
            transition: all 0.3s;
            border-left: 3px solid transparent;
        }
        .sidebar-menu a:hover {
            background: #f5f7fa;
            color: #2D7A8F;
            border-left-color: #2D7A8F;
        }
        .sidebar-menu a.active {
            background: #f0f8ff;
            color: #2D7A8F;
            border-left-color: #2D7A8F;
            font-weight: 600;
        }
        .sidebar-menu a .sidebar-icon {
            width: 18px;
            height: 18px;
            margin-right: 12px;
            flex-shrink: 0;
            stroke: currentColor;
            opacity: 0.7;
            transition: opacity 0.3s;
        }
        .sidebar-menu a:hover .sidebar-icon,
        .sidebar-menu a.active .sidebar-icon {
            opacity: 1;
        }
        .main-content {
            flex: 1;
            margin-left: 260px;
            padding: 30px;
            background: #f5f7fa;
            height: calc(100vh - 70px);
            overflow-y: auto;
            overflow-x: hidden;
        }
        .page-title {
            font-size: 28px;
            font-weight: 700;
            color: #0a1929;
            margin-bottom: 10px;
        }
        .page-subtitle {
            color: #666;
            font-size: 14px;
            margin-bottom: 30px;
        }
        .content-section {
            background: white;
            padding: 25px;
            border-radius: 8px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);
            margin-bottom: 20px;
        }
        .section-title {
            font-size: 18px;
            font-weight: 600;
            color: #0a1929;
            margin-bottom: 15px;
            padding-bottom: 10px;
            border-bottom: 2px solid #f0f0f0;
        }
        .form-group {
            margin-bottom: 20px;
        }
        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 500;
            color: #333;
            font-size: 14px;
        }
        .form-group input,
        .form-group select,
        .form-group textarea {
            width: 100%;
            padding: 12px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 14px;
            font-family: inherit;
            transition: border-color 0.3s;
        }
        .form-group input:focus,
        .form-group select:focus,
        .form-group textarea:focus {
            outline: none;
            border-color: #2D7A8F;
        }
        .form-group textarea {
            resize: vertical;
            min-height: 80px;
        }
        /* Custom File Input Button Styling - Professional (Button Only) */
        .file-input-wrapper {
            position: relative;
            display: inline-block;
            width: 100%;
        }
        .file-input-wrapper input[type="file"] {
            width: 100%;
            padding: 12px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 14px;
            font-family: inherit;
            transition: border-color 0.3s;
        }
        .file-input-wrapper input[type="file"]:focus {
            outline: none;
            border-color: #2D7A8F;
        }
        /* Style only the button part */
        .file-input-wrapper input[type="file"]::file-selector-button {
            padding: 10px 22px;
            margin-right: 12px;
            background: #2D7A8F;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 14px;
            font-weight: 500;
            transition: background-color 0.3s;
        }
        .file-input-wrapper input[type="file"]::file-selector-button:hover {
            background: #1F5F6F;
        }
        .form-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
        }
        .btn {
            padding: 12px 24px;
            border: none;
            border-radius: 4px;
            font-size: 14px;
            font-weight: 500;
            cursor: pointer;
            transition: background-color 0.3s;
            text-decoration: none;
            display: inline-block;
        }
        .btn-primary {
            background: #2D7A8F;
            color: white;
        }
        .btn-primary:hover {
            background: #1F5F6F;
        }
        .btn-danger {
            background: #d32f2f;
            color: white;
            padding: 6px 12px;
            font-size: 12px;
        }
        .btn-danger:hover {
            background: #b71c1c;
        }
        .btn-edit {
            background: #2D7A8F;
            color: white;
            padding: 6px 12px;
            font-size: 12px;
            margin-right: 5px;
        }
        .btn-edit:hover {
            background: #1F5F6F;
        }
        .action-buttons {
            display: flex;
            gap: 5px;
            flex-wrap: wrap;
        }
        .message {
            padding: 12px 20px;
            border-radius: 4px;
            margin-bottom: 20px;
            font-size: 14px;
        }
        .message.success {
            background: #e8f5e9;
            color: #2e7d32;
            border-left: 3px solid #2e7d32;
        }
        .message.error {
            background: #ffebee;
            color: #d32f2f;
            border-left: 3px solid #d32f2f;
        }
        .table-container {
            overflow-x: auto;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        thead {
            background: #f5f7fa;
        }
        th, td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #e0e0e0;
        }
        th {
            font-weight: 600;
            color: #0a1929;
            font-size: 13px;
            text-transform: uppercase;
        }
        td {
            font-size: 14px;
            color: #555;
        }
        tr:hover {
            background: #f9f9f9;
        }
        .profile-picture {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            object-fit: cover;
            border: 2px solid #e0e0e0;
            cursor: pointer;
            transition: transform 0.2s, box-shadow 0.2s;
        }
        .profile-picture:hover {
            transform: scale(1.1);
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.2);
        }
        .profile-picture-placeholder {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            background: #e0e0e0;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #999;
            font-size: 12px;
            cursor: pointer;
            transition: transform 0.2s, box-shadow 0.2s;
            border: 2px solid #e0e0e0;
        }
        .profile-picture-placeholder:hover {
            transform: scale(1.1);
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.2);
        }
        /* Member Detail Modal */
        .modal {
            display: none;
            position: fixed;
            z-index: 2000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            overflow: auto;
            background-color: rgba(0, 0, 0, 0.5);
            animation: fadeIn 0.3s;
            align-items: center;
            justify-content: center;
            padding: 40px 20px;
        }
        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }
        .modal-content {
            background-color: #fefefe;
            margin: 0;
            padding: 0;
            border: none;
            border-radius: 12px;
            width: 85%;
            max-width: 720px;
            display: flex;
            flex-direction: column;
            max-height: calc(100vh - 120px);
            overflow: hidden;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.3);
            animation: slideDown 0.3s;
        }
        @keyframes slideDown {
            from {
                transform: translateY(-50px);
                opacity: 0;
            }
            to {
                transform: translateY(0);
                opacity: 1;
            }
        }
        .modal-header {
            background: linear-gradient(135deg, #2D7A8F 0%, #1F5F6F 100%);
            color: white;
            padding: 20px 30px;
            border-radius: 12px 12px 0 0;
            display: flex;
            justify-content: space-between;
            align-items: center;
            position: sticky;
            top: 0;
            z-index: 1;
        }
        .modal-header h2 {
            margin: 0;
            font-size: 24px;
            font-weight: 600;
        }
        .modal-close {
            color: white;
            font-size: 28px;
            font-weight: bold;
            cursor: pointer;
            background: none;
            border: none;
            padding: 0;
            width: 32px;
            height: 32px;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 50%;
            transition: background-color 0.2s;
        }
        .modal-close:hover {
            background-color: rgba(255, 255, 255, 0.2);
        }
        .modal-body {
            padding: 30px;
            overflow-y: auto;
            -webkit-overflow-scrolling: touch;
        }
        .member-profile-section {
            text-align: center;
            margin-bottom: 30px;
            padding-bottom: 30px;
            border-bottom: 2px solid #f0f0f0;
        }
        .member-profile-large {
            width: 150px;
            height: 150px;
            border-radius: 50%;
            object-fit: cover;
            border: 4px solid #2D7A8F;
            margin: 0 auto 20px;
            display: block;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
        }
        .member-profile-placeholder-large {
            width: 150px;
            height: 150px;
            border-radius: 50%;
            background: linear-gradient(135deg, #e0e0e0 0%, #d0d0d0 100%);
            display: flex;
            align-items: center;
            justify-content: center;
            color: #999;
            font-size: 16px;
            margin: 0 auto 20px;
            border: 4px solid #2D7A8F;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
        }
        .member-name {
            font-size: 28px;
            font-weight: 700;
            color: #0a1929;
            margin-bottom: 10px;
        }
        .member-details-grid {
            display: grid;
            grid-template-columns: 1fr;
            gap: 20px;
        }
        .member-detail-item {
            display: flex;
            flex-direction: column;
            gap: 5px;
        }
        .member-detail-label {
            font-size: 12px;
            font-weight: 600;
            color: #666;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        .member-detail-value {
            font-size: 16px;
            color: #0a1929;
            font-weight: 500;
        }
        .member-status-modal {
            display: inline-block;
            padding: 6px 16px;
            border-radius: 20px;
            font-size: 14px;
            font-weight: 600;
            margin-top: 5px;
        }
        .status-badge {
            padding: 4px 12px;
            border-radius: 12px;
            font-size: 12px;
            font-weight: 500;
            display: inline-block;
        }
        .status-active {
            background: #e8f5e9;
            color: #2e7d32;
        }
        .status-inactive {
            background: #ffebee;
            color: #d32f2f;
        }
        .filters {
            display: flex;
            gap: 15px;
            margin-bottom: 20px;
            flex-wrap: wrap;
            align-items: center;
        }
        .filter-group {
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .filter-group label {
            font-size: 14px;
            font-weight: 500;
            color: #555;
        }
        .filter-group input,
        .filter-group select {
            padding: 8px 12px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 14px;
        }
        .filter-group input:focus,
        .filter-group select:focus {
            outline: none;
            border-color: #2D7A8F;
        }
        .pagination {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-top: 20px;
            flex-wrap: wrap;
            gap: 15px;
        }
        .pagination-info {
            font-size: 14px;
            color: #666;
        }
        .pagination-controls {
            display: flex;
            gap: 10px;
            align-items: center;
        }
        .pagination-btn {
            padding: 8px 12px;
            border: 1px solid #ddd;
            background: white;
            border-radius: 4px;
            cursor: pointer;
            font-size: 14px;
            text-decoration: none;
            color: #333;
            transition: all 0.3s;
        }
        .pagination-btn:hover:not(.disabled) {
            background: #2D7A8F;
            color: white;
            border-color: #2D7A8F;
        }
        .pagination-btn.disabled {
            opacity: 0.5;
            cursor: not-allowed;
        }
        .pagination-btn.active {
            background: #2D7A8F;
            color: white;
            border-color: #2D7A8F;
        }
        .no-data {
            text-align: center;
            padding: 40px;
            color: #888;
            font-size: 14px;
        }
        @media (max-width: 768px) {
            .sidebar {
                width: 100%;
                position: relative;
                top: 0;
                height: auto;
            }
            .main-content {
                margin-left: 0;
            }
            .container {
                flex-direction: column;
            }
            .header {
                flex-direction: column;
                gap: 15px;
                padding: 15px;
            }
            .form-row {
                grid-template-columns: 1fr;
            }
            .filters {
                flex-direction: column;
                align-items: stretch;
            }
        }
    </style>
</head>
<body>

<div class="header">
    <h1>Church Management System</h1>
    <div class="header-right">
        <div class="notification-dropdown-container">
            <div class="notification-icon" id="notificationIcon" onclick="toggleNotificationDropdown(event)" title="View Notifications">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"></path>
                    <path d="M13.73 21a2 2 0 0 1-3.46 0"></path>
                </svg>
                <?php if ($notificationCount > 0): ?>
                    <span class="notification-badge" id="notificationBadge"><?php echo $notificationCount; ?></span>
                <?php endif; ?>
            </div>
            <div class="notification-dropdown" id="notificationDropdown">
                <div class="notification-dropdown-header">
                    <h3>Notifications</h3>
                    <button class="notification-dropdown-close" onclick="closeNotificationDropdown()" title="Close">×</button>
                </div>
                <div class="notification-dropdown-list" id="notificationDropdownList">
                    <div class="notification-dropdown-empty">Loading notifications...</div>
                </div>
                <div class="notification-dropdown-footer">
                    <a href="dashboard.php#notifications-section" onclick="closeNotificationDropdown();">View All Notifications</a>
                </div>
            </div>
        </div>
        <div class="user-info">
            <span class="user-name">Welcome, <?php echo htmlspecialchars($_SESSION['fullname']); ?></span>
        </div>
        <a href="logout.php" class="logout-btn">Logout</a>
    </div>
</div>

<div class="container">
    <aside class="sidebar">
        <ul class="sidebar-menu">
            <li><a href="dashboard.php">
                <svg class="sidebar-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="7" height="7"></rect><rect x="14" y="3" width="7" height="7"></rect><rect x="14" y="14" width="7" height="7"></rect><rect x="3" y="14" width="7" height="7"></rect></svg>
                Dashboard</a></li>
            <li><a href="members.php" class="active">
                <svg class="sidebar-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path><circle cx="9" cy="7" r="4"></circle><path d="M23 21v-2a4 4 0 0 0-3-3.87"></path><path d="M16 3.13a4 4 0 0 1 0 7.75"></path></svg>
                Members</a></li>
            <li><a href="attendance.php">
                <svg class="sidebar-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path><polyline points="14 2 14 8 20 8"></polyline><line x1="16" y1="13" x2="8" y2="13"></line><line x1="16" y1="17" x2="8" y2="17"></line><polyline points="10 9 9 9 8 9"></line></svg>
                Attendance</a></li>
            <li><a href="offerings.php">
                <svg class="sidebar-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="12" y1="1" x2="12" y2="23"></line><path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"></path></svg>
                Offerings</a></li>
            <li><a href="expenses.php">
                <svg class="sidebar-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path><polyline points="14 2 14 8 20 8"></polyline><line x1="16" y1="13" x2="8" y2="13"></line><line x1="16" y1="17" x2="8" y2="17"></line></svg>
                Expenses</a></li>
            <li><a href="events.php">
                <svg class="sidebar-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect><line x1="16" y1="2" x2="16" y2="6"></line><line x1="8" y1="2" x2="8" y2="6"></line><line x1="3" y1="10" x2="21" y2="10"></line></svg>
                Events</a></li>
            <li><a href="reports.php">
                <svg class="sidebar-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="20" x2="18" y2="10"></line><line x1="12" y1="20" x2="12" y2="4"></line><line x1="6" y1="20" x2="6" y2="14"></line></svg>
                Reports</a></li>
            <li><a href="users.php">
                <svg class="sidebar-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path><circle cx="12" cy="7" r="4"></circle></svg>
                Users</a></li>
        </ul>
    </aside>

    <main class="main-content">
        <h2 class="page-title">Members Management</h2>
        <p class="page-subtitle">Add and manage church members</p>

        <?php if (!empty($message)): ?>
            <div class="message <?php echo $messageType; ?>">
                <?php echo htmlspecialchars($message); ?>
            </div>
        <?php endif; ?>

        <!-- Add/Edit Member Form -->
        <div class="content-section">
            <h3 class="section-title"><?php echo $edit_member ? 'Edit Member' : 'Add New Member'; ?></h3>
            <?php if ($edit_member): ?>
                <a href="members.php" class="btn btn-primary" style="margin-bottom: 15px; display: inline-block;">Cancel Edit</a>
            <?php endif; ?>
            <form method="POST" enctype="multipart/form-data">
                <?php if ($edit_member): ?>
                    <input type="hidden" name="member_id" value="<?php echo $edit_member['id']; ?>">
                <?php endif; ?>
                <div class="form-group">
                    <label for="profile_picture">Profile Picture</label>
                    <?php if ($edit_member && $edit_member['profile_picture'] && file_exists($edit_member['profile_picture'])): ?>
                        <div style="margin-bottom: 10px;">
                            <img src="<?php echo htmlspecialchars($edit_member['profile_picture']); ?>" alt="Current Profile" style="width: 80px; height: 80px; border-radius: 50%; object-fit: cover; border: 2px solid #e0e0e0;">
                            <p style="font-size: 12px; color: #666; margin-top: 5px;">Current profile picture</p>
                        </div>
                    <?php endif; ?>
                    <div class="file-input-wrapper">
                        <input type="file" id="profile_picture" name="profile_picture" accept="image/*">
                    </div>
                    <?php if ($edit_member): ?>
                        <p style="font-size: 12px; color: #666; margin-top: 5px;">Leave empty to keep current picture</p>
                    <?php endif; ?>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label for="full_name">Full Name *</label>
                        <input type="text" id="full_name" name="full_name" value="<?php echo $edit_member ? htmlspecialchars($edit_member['full_name']) : ''; ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="birthdate">Birthdate *</label>
                        <input type="date" id="birthdate" name="birthdate" value="<?php echo $edit_member ? $edit_member['birthdate'] : ''; ?>" required>
                    </div>
                </div>
                <div class="form-group">
                    <label for="address">Address *</label>
                    <textarea id="address" name="address" required><?php echo $edit_member ? htmlspecialchars($edit_member['address']) : ''; ?></textarea>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label for="contact_number">Contact Number *</label>
                        <input type="text" id="contact_number" name="contact_number" value="<?php echo $edit_member ? htmlspecialchars($edit_member['contact_number']) : ''; ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="status">Status *</label>
                        <select id="status" name="status" required>
                            <option value="Active" <?php echo ($edit_member && $edit_member['status'] == 'Active') ? 'selected' : ''; ?>>Active</option>
                            <option value="Inactive" <?php echo ($edit_member && $edit_member['status'] == 'Inactive') ? 'selected' : ''; ?>>Inactive</option>
                        </select>
                    </div>
                </div>
                <div class="form-group">
                    <label for="member_since">Member Since</label>
                    <input 
                        type="date" 
                        id="member_since" 
                        name="member_since" 
                        value="<?php 
                            if ($edit_member && !empty($edit_member['created_at'])) { 
                                echo date('Y-m-d', strtotime($edit_member['created_at'])); 
                            } else { 
                                echo date('Y-m-d'); 
                            } 
                        ?>">
                    <p style="font-size: 12px; color: #666; margin-top: 6px;">Leave as-is to keep current value.</p>
                </div>
                <?php if ($edit_member): ?>
                    <button type="submit" name="update_member" class="btn btn-primary">Update Member</button>
                <?php else: ?>
                    <button type="submit" name="add_member" class="btn btn-primary">Add Member</button>
                <?php endif; ?>
            </form>
        </div>

        <!-- Members Table -->
        <div class="content-section">
            <h3 class="section-title">Members List</h3>
            
            <!-- Filters and Search -->
            <form method="GET" action="members.php" class="filters">
                <div class="filter-group">
                    <label for="search">Search:</label>
                    <input type="text" id="search" name="search" placeholder="Search by name, address, or contact..." value="<?php echo htmlspecialchars($search); ?>">
                </div>
                <div class="filter-group">
                    <label for="status_filter">Status:</label>
                    <select id="status_filter" name="status_filter">
                        <option value="">All</option>
                        <option value="Active" <?php echo $status_filter == 'Active' ? 'selected' : ''; ?>>Active</option>
                        <option value="Inactive" <?php echo $status_filter == 'Inactive' ? 'selected' : ''; ?>>Inactive</option>
                    </select>
                </div>
                <div class="filter-group">
                    <label for="entries">Show:</label>
                    <select id="entries" name="entries" onchange="this.form.submit()">
                        <option value="10" <?php echo $entries_per_page == 10 ? 'selected' : ''; ?>>10</option>
                        <option value="25" <?php echo $entries_per_page == 25 ? 'selected' : ''; ?>>25</option>
                        <option value="50" <?php echo $entries_per_page == 50 ? 'selected' : ''; ?>>50</option>
                        <option value="100" <?php echo $entries_per_page == 100 ? 'selected' : ''; ?>>100</option>
                    </select>
                </div>
                <button type="submit" class="btn btn-primary">Filter</button>
                <?php if (!empty($search) || !empty($status_filter)): ?>
                    <a href="members.php" class="btn btn-primary" style="background: #666;">Clear</a>
                <?php endif; ?>
            </form>

            <!-- Table -->
            <div class="table-container">
                <?php if (mysqli_num_rows($result) > 0): ?>
                    <table>
                        <thead>
                            <tr>
                                <th>Profile</th>
                                <th>Full Name</th>
                                <th>Birthdate</th>
                                <th>Address</th>
                                <th>Contact Number</th>
                                <th>Status</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while ($member = mysqli_fetch_assoc($result)): ?>
                                <tr>
                                    <td>
                                        <?php if ($member['profile_picture'] && file_exists($member['profile_picture'])): ?>
                                            <img src="<?php echo htmlspecialchars($member['profile_picture']); ?>" alt="Profile" class="profile-picture" onclick="showMemberDetails(<?php echo $member['id']; ?>)" title="Click to view details">
                                        <?php else: ?>
                                            <div class="profile-picture-placeholder" onclick="showMemberDetails(<?php echo $member['id']; ?>)" title="Click to view details">No Image</div>
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo htmlspecialchars($member['full_name']); ?></td>
                                    <td><?php echo date('M d, Y', strtotime($member['birthdate'])); ?></td>
                                    <td><?php echo htmlspecialchars($member['address']); ?></td>
                                    <td><?php echo htmlspecialchars($member['contact_number']); ?></td>
                                    <td>
                                        <span class="status-badge status-<?php echo strtolower($member['status']); ?>">
                                            <?php echo htmlspecialchars($member['status']); ?>
                                        </span>
                                    </td>
                                    <td>
                                        <div class="action-buttons">
                                            <?php
                                            $editParams = $_GET;
                                            $editParams['edit'] = $member['id'];
                                            unset($editParams['delete']);
                                            $editUrl = 'members.php?' . http_build_query($editParams);
                                            ?>
                                            <a href="<?php echo $editUrl; ?>" class="btn btn-edit">Edit</a>
                                            <?php
                                            $deleteParams = $_GET;
                                            $deleteParams['delete'] = $member['id'];
                                            unset($deleteParams['edit']);
                                            $deleteUrl = 'members.php?' . http_build_query($deleteParams);
                                            ?>
                                            <a href="<?php echo $deleteUrl; ?>" class="btn btn-danger" onclick="return confirm('Are you sure you want to delete this member?');">Delete</a>
                                        </div>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                <?php else: ?>
                    <div class="no-data">No members found.</div>
                <?php endif; ?>
            </div>

            <!-- Pagination -->
            <?php if ($totalPages > 1): ?>
                <div class="pagination">
                    <div class="pagination-info">
                        Showing <?php echo $offset + 1; ?> to <?php echo min($offset + $entries_per_page, $totalRecords); ?> of <?php echo $totalRecords; ?> entries
                    </div>
                    <div class="pagination-controls">
                        <?php
                        $queryParams = $_GET;
                        unset($queryParams['page']);
                        $baseUrl = 'members.php?' . http_build_query($queryParams);
                        ?>
                        <a href="<?php echo $baseUrl . ($page > 1 ? '&page=' . ($page - 1) : ''); ?>" class="pagination-btn <?php echo $page == 1 ? 'disabled' : ''; ?>">Previous</a>
                        <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                            <?php if ($i == 1 || $i == $totalPages || ($i >= $page - 2 && $i <= $page + 2)): ?>
                                <a href="<?php echo $baseUrl . '&page=' . $i; ?>" class="pagination-btn <?php echo $page == $i ? 'active' : ''; ?>"><?php echo $i; ?></a>
                            <?php elseif ($i == $page - 3 || $i == $page + 3): ?>
                                <span class="pagination-btn disabled">...</span>
                            <?php endif; ?>
                        <?php endfor; ?>
                        <a href="<?php echo $baseUrl . '&page=' . ($page + 1); ?>" class="pagination-btn <?php echo $page >= $totalPages ? 'disabled' : ''; ?>">Next</a>
                    </div>
                </div>
            <?php else: ?>
                <div class="pagination-info" style="margin-top: 20px;">
                    Showing <?php echo $totalRecords; ?> of <?php echo $totalRecords; ?> entries
                </div>
            <?php endif; ?>
        </div>
    </main>
</div>

<!-- Member Detail Modal -->
<div id="memberModal" class="modal">
    <div class="modal-content">
        <div class="modal-header">
            <h2>Member Details</h2>
            <button class="modal-close" onclick="closeMemberModal()">&times;</button>
        </div>
        <div class="modal-body" id="memberModalBody">
            <div style="text-align: center; padding: 40px;">
                <p>Loading member details...</p>
            </div>
        </div>
    </div>
</div>

<script>
// Notification Dropdown Functions
let notificationDropdownOpen = false;
let readNotifications = JSON.parse(localStorage.getItem('readNotifications') || '[]');

function toggleNotificationDropdown(event) {
    event.stopPropagation();
    const dropdown = document.getElementById('notificationDropdown');
    
    if (dropdown.classList.contains('active')) {
        closeNotificationDropdown();
    } else {
        dropdown.classList.add('active');
        notificationDropdownOpen = true;
        loadNotifications();
    }
}

function closeNotificationDropdown() {
    const dropdown = document.getElementById('notificationDropdown');
    dropdown.classList.remove('active');
    notificationDropdownOpen = false;
}

function loadNotifications() {
    const list = document.getElementById('notificationDropdownList');
    
    fetch('get_notifications.php')
        .then(response => response.json())
        .then(data => {
            if (data.error) {
                list.innerHTML = '<div class="notification-dropdown-empty">Error loading notifications</div>';
            } else {
                renderNotifications(data.notifications);
            }
        })
        .catch(error => {
            console.error('Error:', error);
            list.innerHTML = '<div class="notification-dropdown-empty">Error loading notifications</div>';
        });
}

function renderNotifications(notifications) {
    const list = document.getElementById('notificationDropdownList');
    
    if (!notifications || notifications.length === 0) {
        list.innerHTML = '<div class="notification-dropdown-empty">No notifications at this time.</div>';
        return;
    }
    
    list.innerHTML = notifications.map(notif => {
        const isRead = readNotifications.includes(notif.id);
        const timeAgo = formatTimeAgo(notif.timestamp, notif.days_until);
        const profileImg = notif.profile_picture && notif.profile_picture.trim() !== '' 
            ? `<img src="${escapeHtml(notif.profile_picture)}" alt="Profile" class="notification-dropdown-item-profile" onerror="this.style.display='none'">`
            : '';
        
        return `
            <div class="notification-dropdown-item ${isRead ? 'read' : ''}" 
                 onclick="markNotificationAsRead('${notif.id}', this)" 
                 data-notification-id="${notif.id}">
                <span class="notification-dropdown-item-icon">${notif.icon}</span>
                ${profileImg}
                <div class="notification-dropdown-item-content">
                    <div class="notification-dropdown-item-title">${escapeHtml(notif.title)}</div>
                    <div class="notification-dropdown-item-message">${escapeHtml(notif.message)}</div>
                    <div class="notification-dropdown-item-time">${timeAgo}</div>
                </div>
            </div>
        `;
    }).join('');
}

function markNotificationAsRead(notificationId, element) {
    if (!readNotifications.includes(notificationId)) {
        readNotifications.push(notificationId);
        localStorage.setItem('readNotifications', JSON.stringify(readNotifications));
        element.classList.add('read');
        updateNotificationBadge();
    }
}

function formatTimeAgo(timestamp, daysUntil) {
    const now = Math.floor(Date.now() / 1000);
    const diff = timestamp - now;
    const days = Math.floor(diff / 86400);
    
    if (days < 0) {
        return 'Past';
    } else if (days === 0) {
        return 'Today';
    } else if (days === 1) {
        return 'Tomorrow';
    } else {
        return `In ${days} days`;
    }
}

function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

function updateNotificationBadge() {
    const badge = document.getElementById('notificationBadge');
    if (!badge) return;
    
    const allItems = document.querySelectorAll('.notification-dropdown-item');
    const unreadCount = Array.from(allItems).filter(item => !item.classList.contains('read')).length;
    
    if (unreadCount > 0) {
        badge.textContent = unreadCount;
        badge.style.display = 'flex';
    } else {
        badge.style.display = 'none';
    }
}

// Close dropdown when clicking outside
document.addEventListener('click', function(event) {
    const container = document.querySelector('.notification-dropdown-container');
    if (container && !container.contains(event.target) && notificationDropdownOpen) {
        closeNotificationDropdown();
    }
});

// Member Detail Modal Functions
function showMemberDetails(memberId) {
    const modal = document.getElementById('memberModal');
    const modalBody = document.getElementById('memberModalBody');
    
    modal.style.display = 'flex';
    modalBody.innerHTML = '<div style="text-align: center; padding: 40px;"><p>Loading member details...</p></div>';
    
    // Fetch member details via AJAX
    fetch('get_member_details.php?id=' + memberId)
        .then(response => response.json())
        .then(data => {
            if (data.error) {
                modalBody.innerHTML = '<div style="text-align: center; padding: 40px; color: #d32f2f;"><p>Error loading member details: ' + escapeHtml(data.error) + '</p></div>';
            } else {
                const member = data.member;
                const profileImg = member.profile_picture && member.profile_picture.trim() !== '' 
                    ? `<img src="${escapeHtml(member.profile_picture)}" alt="Profile" class="member-profile-large">`
                    : `<div class="member-profile-placeholder-large">No Image</div>`;
                
                const statusClass = member.status === 'Active' ? 'status-active' : 'status-inactive';
                const birthdate = new Date(member.birthdate).toLocaleDateString('en-US', { 
                    year: 'numeric', 
                    month: 'long', 
                    day: 'numeric' 
                });
                const createdDate = new Date(member.created_at).toLocaleDateString('en-US', { 
                    year: 'numeric', 
                    month: 'long', 
                    day: 'numeric'
                });
                const updatedDate = new Date(member.updated_at).toLocaleDateString('en-US', { 
                    year: 'numeric', 
                    month: 'long', 
                    day: 'numeric',
                    hour: '2-digit',
                    minute: '2-digit'
                });
                
                modalBody.innerHTML = `
                    <div class="member-profile-section">
                        ${profileImg}
                        <div class="member-name">${escapeHtml(member.full_name)}</div>
                        <span class="status-badge ${statusClass} member-status-modal">${escapeHtml(member.status)}</span>
                    </div>
                    <div class="member-details-grid">
                        <div class="member-detail-item">
                            <span class="member-detail-label">Full Name</span>
                            <span class="member-detail-value">${escapeHtml(member.full_name)}</span>
                        </div>
                        <div class="member-detail-item">
                            <span class="member-detail-label">Birthdate</span>
                            <span class="member-detail-value">${birthdate}</span>
                        </div>
                        <div class="member-detail-item">
                            <span class="member-detail-label">Address</span>
                            <span class="member-detail-value">${escapeHtml(member.address)}</span>
                        </div>
                        <div class="member-detail-item">
                            <span class="member-detail-label">Contact Number</span>
                            <span class="member-detail-value">${escapeHtml(member.contact_number)}</span>
                        </div>
                        <div class="member-detail-item">
                            <span class="member-detail-label">Member Since</span>
                            <span class="member-detail-value">${createdDate}</span>
                        </div>
                        <div class="member-detail-item">
                            <span class="member-detail-label">Last Updated</span>
                            <span class="member-detail-value">${updatedDate}</span>
                        </div>
                    </div>
                `;
            }
        })
        .catch(error => {
            console.error('Error:', error);
            modalBody.innerHTML = '<div style="text-align: center; padding: 40px; color: #d32f2f;"><p>Error loading member details. Please try again.</p></div>';
        });
}

function closeMemberModal() {
    const modal = document.getElementById('memberModal');
    modal.style.display = 'none';
}

// Close modal when clicking outside of it
window.onclick = function(event) {
    const modal = document.getElementById('memberModal');
    if (event.target == modal) {
        closeMemberModal();
    }
}

// Close modal with Escape key
document.addEventListener('keydown', function(event) {
    if (event.key === 'Escape') {
        closeMemberModal();
    }
});

// Load notifications on page load to update badge
document.addEventListener('DOMContentLoaded', function() {
    fetch('get_notifications.php')
        .then(response => response.json())
        .then(data => {
            if (!data.error && data.notifications) {
                const unreadCount = data.notifications.filter(n => !readNotifications.includes(n.id)).length;
                const badge = document.getElementById('notificationBadge');
                if (badge) {
                    if (unreadCount > 0) {
                        badge.textContent = unreadCount;
                        badge.style.display = 'flex';
                    } else {
                        badge.style.display = 'none';
                    }
                }
            }
        })
        .catch(error => console.error('Error loading notifications:', error));
});

</script>

</body>
</html>

