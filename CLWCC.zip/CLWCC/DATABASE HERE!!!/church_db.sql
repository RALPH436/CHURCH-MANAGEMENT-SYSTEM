-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 16, 2025 at 04:14 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `church_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `attendance`
--

CREATE TABLE `attendance` (
  `id` int(11) NOT NULL,
  `member_id` int(11) NOT NULL,
  `attendance_date` date NOT NULL,
  `event_type` varchar(100) NOT NULL,
  `status` enum('Present','Absent','Late') DEFAULT 'Present',
  `notes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `attendance`
--

INSERT INTO `attendance` (`id`, `member_id`, `attendance_date`, `event_type`, `status`, `notes`, `created_at`, `updated_at`) VALUES
(1, 3, '2025-12-14', 'Sunday Service', 'Present', 'Late kay natulogan', '2025-12-14 14:03:52', '2025-12-14 14:16:40'),
(2, 2, '2025-12-14', 'Sunday Service', 'Present', 'N/A', '2025-12-14 14:06:03', '2025-12-14 14:06:03'),
(3, 4, '2025-12-15', 'Sunday Service', 'Late', '', '2025-12-14 23:48:23', '2025-12-14 23:48:23'),
(4, 3, '2025-12-15', 'Bible study', 'Present', '', '2025-12-15 00:07:56', '2025-12-15 00:07:56'),
(5, 2, '2025-12-15', 'Bible study', 'Present', '', '2025-12-15 00:08:02', '2025-12-15 00:08:02'),
(6, 4, '2025-12-15', 'Bible study', 'Present', '', '2025-12-15 00:08:07', '2025-12-15 00:08:07'),
(7, 3, '2025-12-15', 'Prayer meeting', 'Present', '', '2025-12-15 00:08:24', '2025-12-15 00:08:24'),
(8, 2, '2025-12-15', 'Prayer meeting', 'Present', '', '2025-12-15 00:08:27', '2025-12-15 00:08:27'),
(9, 4, '2025-12-15', 'Prayer meeting', 'Present', '', '2025-12-15 00:08:32', '2025-12-15 00:08:32'),
(10, 3, '2025-12-15', 'DGROUP', 'Present', '', '2025-12-15 00:08:41', '2025-12-15 00:08:41'),
(11, 2, '2025-12-15', 'DGROUP', 'Present', '', '2025-12-15 00:08:48', '2025-12-15 00:08:48'),
(12, 4, '2025-12-15', 'DGROUP', 'Present', '', '2025-12-15 00:08:53', '2025-12-15 00:08:53'),
(13, 3, '2025-12-16', 'Bible study', 'Present', '', '2025-12-16 02:57:32', '2025-12-16 02:57:32');

-- --------------------------------------------------------

--
-- Table structure for table `events`
--

CREATE TABLE `events` (
  `id` int(11) NOT NULL,
  `event_name` varchar(255) NOT NULL,
  `event_date` date NOT NULL,
  `event_time` time NOT NULL,
  `location` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `reminder_date` date DEFAULT NULL,
  `reminder_sent` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `events`
--

INSERT INTO `events` (`id`, `event_name`, `event_date`, `event_time`, `location`, `description`, `reminder_date`, `reminder_sent`, `created_at`, `updated_at`) VALUES
(1, 'Year End Thanksigiving', '2025-12-28', '23:22:00', 'Pulang Duta, Bago City', 'Year-End Thanksgiving', '2025-12-14', 0, '2025-12-14 15:22:33', '2025-12-15 00:10:59');

-- --------------------------------------------------------

--
-- Table structure for table `expenses`
--

CREATE TABLE `expenses` (
  `id` int(11) NOT NULL,
  `expense_date` date NOT NULL,
  `expense_type` varchar(100) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `notes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `expenses`
--

INSERT INTO `expenses` (`id`, `expense_date`, `expense_type`, `amount`, `notes`, `created_at`, `updated_at`) VALUES
(1, '2025-12-14', 'Staff Salary', 100.00, 'Secret', '2025-12-14 15:35:42', '2025-12-14 15:35:42'),
(2, '2025-12-21', 'Bayad utang', 1000.00, '', '2025-12-14 15:39:10', '2025-12-14 15:39:10'),
(3, '2025-12-14', 'N/A', 500.00, '', '2025-12-14 15:42:35', '2025-12-14 15:42:35'),
(4, '2025-12-15', 'Pamahaw', 150.00, '', '2025-12-15 00:15:44', '2025-12-15 00:15:44'),
(5, '2025-12-15', 'Plete sang members', 299.99, '', '2025-12-15 00:15:54', '2025-12-15 00:15:54');

-- --------------------------------------------------------

--
-- Table structure for table `members`
--

CREATE TABLE `members` (
  `id` int(11) NOT NULL,
  `profile_picture` varchar(255) DEFAULT NULL,
  `full_name` varchar(255) NOT NULL,
  `birthdate` date NOT NULL,
  `address` text NOT NULL,
  `contact_number` varchar(20) NOT NULL,
  `status` enum('Active','Inactive') DEFAULT 'Active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `members`
--

INSERT INTO `members` (`id`, `profile_picture`, `full_name`, `birthdate`, `address`, `contact_number`, `status`, `created_at`, `updated_at`) VALUES
(2, 'uploads/members/693e0590224a2_1765672336.png', 'Ralph Espiritu', '2002-05-18', 'Brgy 32, Bacolod City ', '09157447039', 'Active', '2025-12-14 00:32:16', '2025-12-14 14:52:03'),
(3, 'uploads/members/693e7bea30020_1765702634.png', 'Loejie M. Logatiman', '2006-12-14', 'Dona Juliana', '09515885445', 'Active', '2025-12-14 08:57:14', '2025-12-14 14:53:53'),
(4, 'uploads/members/693ed017c2545_1765724183.jpg', 'Ronelyn D. Dato-on', '1999-02-04', 'Purok Tilapia Brgy 3, Bacolod city negros occidental ', '09318050655', 'Active', '2023-11-13 16:00:00', '2025-12-15 13:29:54');

-- --------------------------------------------------------

--
-- Table structure for table `offerings`
--

CREATE TABLE `offerings` (
  `id` int(11) NOT NULL,
  `offering_date` date NOT NULL,
  `member_id` int(11) DEFAULT NULL,
  `offering_type` enum('Sunday Offering','Special Offering','Pledge') NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `notes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `offerings`
--

INSERT INTO `offerings` (`id`, `offering_date`, `member_id`, `offering_type`, `amount`, `notes`, `created_at`, `updated_at`) VALUES
(1, '2025-12-14', NULL, 'Sunday Offering', 545.00, 'Secret', '2025-12-14 15:03:15', '2025-12-14 15:03:15'),
(2, '2025-12-21', NULL, 'Sunday Offering', 345.00, 'Aray ko', '2025-12-14 15:03:35', '2025-12-14 15:03:35'),
(3, '2025-12-21', NULL, 'Sunday Offering', 345.00, 'Aray ko', '2025-12-14 15:05:26', '2025-12-14 15:05:26'),
(4, '2025-12-28', NULL, 'Sunday Offering', 2000.00, '', '2025-12-14 15:42:07', '2025-12-14 15:42:07');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `fullname` varchar(100) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `email` varchar(255) DEFAULT NULL,
  `role` enum('Admin','User') DEFAULT 'User',
  `account_status` enum('Active','Disabled') DEFAULT 'Active',
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `password_reset_code` varchar(10) DEFAULT NULL,
  `password_reset_expiry` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `fullname`, `created_at`, `email`, `role`, `account_status`, `updated_at`, `password_reset_code`, `password_reset_expiry`) VALUES
(4, 'ralphtomespiritu18', '58d9c1095eead882759850baf09efa12', 'Ralph Espiritu', '2025-12-14 00:31:04', 'ralphtomespiritu@gmail.com', 'Admin', 'Active', '2025-12-14 13:58:25', '901718', '2025-12-14 15:13:25'),
(5, '', 'e10adc3949ba59abbe56e057f20f883e', 'Ronelyn Dato-on', '2025-12-14 13:45:50', 'ronelyndatoon04@gmail.com', 'User', 'Active', '2025-12-14 13:45:50', NULL, NULL),
(12, 'grandesign29@gmail.com', '58d9c1095eead882759850baf09efa12', 'John Andre N. Grandeza', '2025-12-15 13:07:19', 'grandesign29@gmail.com', 'Admin', 'Active', '2025-12-15 13:07:19', NULL, NULL),
(13, 'churchad@gmail.com', '0192023a7bbd73250516f069df18b500', 'Administrator', '2025-12-15 13:07:49', 'churchad@gmail.com', 'Admin', 'Active', '2025-12-15 13:07:49', NULL, NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `attendance`
--
ALTER TABLE `attendance`
  ADD PRIMARY KEY (`id`),
  ADD KEY `member_id` (`member_id`),
  ADD KEY `idx_date` (`attendance_date`),
  ADD KEY `idx_event_type` (`event_type`),
  ADD KEY `idx_status` (`status`);

--
-- Indexes for table `events`
--
ALTER TABLE `events`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_date` (`event_date`),
  ADD KEY `idx_reminder` (`reminder_date`);

--
-- Indexes for table `expenses`
--
ALTER TABLE `expenses`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_date` (`expense_date`),
  ADD KEY `idx_type` (`expense_type`);

--
-- Indexes for table `members`
--
ALTER TABLE `members`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `offerings`
--
ALTER TABLE `offerings`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_date` (`offering_date`),
  ADD KEY `idx_type` (`offering_type`),
  ADD KEY `idx_member_id` (`member_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `attendance`
--
ALTER TABLE `attendance`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `events`
--
ALTER TABLE `events`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `expenses`
--
ALTER TABLE `expenses`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `members`
--
ALTER TABLE `members`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `offerings`
--
ALTER TABLE `offerings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `attendance`
--
ALTER TABLE `attendance`
  ADD CONSTRAINT `attendance_ibfk_1` FOREIGN KEY (`member_id`) REFERENCES `members` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `offerings`
--
ALTER TABLE `offerings`
  ADD CONSTRAINT `offerings_ibfk_1` FOREIGN KEY (`member_id`) REFERENCES `members` (`id`) ON DELETE SET NULL;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
