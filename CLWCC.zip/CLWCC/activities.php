<?php
// This module has been deprecated and removed.
header("Location: dashboard.php");
exit();
