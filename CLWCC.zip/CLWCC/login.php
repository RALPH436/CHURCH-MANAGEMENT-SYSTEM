<?php
session_start();
include "db.php";

if (isset($_POST['login'])) {
    $email = trim(mysqli_real_escape_string($conn, $_POST['email']));
    $password = md5($_POST['password']);

    // Use LOWER() for case-insensitive comparison
    $query = "SELECT * FROM users WHERE LOWER(email) = LOWER('$email') AND password='$password'";
    $result = mysqli_query($conn, $query);

    if (mysqli_num_rows($result) == 1) {
        $user = mysqli_fetch_assoc($result);
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['fullname'] = $user['fullname'];
        header("Location: dashboard.php");
        exit();
    } else {
        $error = "Invalid email or password";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Login</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body { 
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; 
            background: linear-gradient(to bottom, #0a1929 0%, #1a2f4a 50%, #0f1b2e 100%);
            margin: 0;
            padding: 0;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            position: relative;
            overflow: hidden;
        }
        body::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-image: 
                radial-gradient(2px 2px at 20% 30%, white, transparent),
                radial-gradient(2px 2px at 60% 70%, white, transparent),
                radial-gradient(1px 1px at 50% 50%, white, transparent),
                radial-gradient(1px 1px at 80% 10%, white, transparent),
                radial-gradient(2px 2px at 90% 60%, white, transparent),
                radial-gradient(1px 1px at 33% 80%, white, transparent),
                radial-gradient(1px 1px at 15% 50%, white, transparent),
                radial-gradient(2px 2px at 70% 20%, white, transparent),
                radial-gradient(1px 1px at 40% 90%, white, transparent);
            background-size: 200% 200%;
            background-position: 0 0, 100% 0, 50% 50%, 0 100%, 100% 100%;
            opacity: 0.6;
            animation: twinkle 20s linear infinite;
        }
        body::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 0;
            width: 100%;
            height: 40%;
            background: linear-gradient(to top, #1a1a2e 0%, transparent 100%);
            clip-path: polygon(0% 100%, 100% 100%, 100% 60%, 90% 55%, 80% 50%, 70% 45%, 60% 40%, 50% 35%, 40% 30%, 30% 25%, 20% 20%, 10% 15%, 0% 10%);
        }
        @keyframes twinkle {
            0%, 100% { opacity: 0.6; }
            50% { opacity: 0.8; }
        }
        .container {
            display: flex;
            width: 900px;
            max-width: 95%;
            min-height: 500px;
            background: #fff;
            border-radius: 12px;
            box-shadow: 0 20px 60px rgba(0, 0, 0, 0.5);
            overflow: hidden;
            position: relative;
            z-index: 1;
        }
        .left-section {
            width: 50%;
            background: url('img/church.jpg') center center / cover no-repeat;
            position: relative;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .left-section::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.5);
        }
        .welcome-content {
            position: relative;
            z-index: 1;
            color: white;
            padding: 40px;
            text-align: center;
        }
        .welcome-content h1 {
            font-size: 36px;
            font-weight: 700;
            margin-bottom: 14px;
        }
        .welcome-content p {
            font-size: 15px;
            line-height: 1.6;
            opacity: 0.9;
        }
        .right-section {
            width: 50%;
            background: #fff;
            padding: 40px;
            position: relative;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
        }
        .form-wrapper {
            width: 100%;
            max-width: 100%;
        }
        .form-header {
            margin-bottom: 30px;
        }
        .form-header h2 {
            font-size: 28px;
            font-weight: 700;
            color: #000;
            text-transform: uppercase;
            text-align: center;
        }
        .form-group {
            margin-bottom: 18px;
        }
        .form-group input {
            width: 100%;
            padding: 12px;
            border: 1px solid #e0e0e0;
            border-radius: 4px;
            font-size: 14px;
            color: #424242;
            background: #fff;
            transition: border-color 0.3s;
        }
        .form-group input:focus {
            outline: none;
            border-color: #2D7A8F;
        }
        .form-group input::placeholder {
            color: #9e9e9e;
        }
        .password-wrapper {
            position: relative;
        }
        .password-toggle {
            position: absolute;
            right: 12px;
            top: 50%;
            transform: translateY(-50%);
            background: none;
            border: none;
            cursor: pointer;
            color: #9e9e9e;
            font-size: 18px;
            padding: 5px;
        }
        .forgot-password {
            text-align: right;
            margin-bottom: 20px;
        }
        .forgot-password a {
            color: #2D7A8F;
            font-size: 13px;
            text-decoration: none;
            transition: color 0.3s;
        }
        .forgot-password a:hover {
            color: #1F5F6F;
        }
        .login-button {
            width: 100%;
            padding: 12px;
            background: #2D7A8F;
            color: white;
            border: none;
            border-radius: 4px;
            font-size: 15px;
            font-weight: 600;
            cursor: pointer;
            transition: background-color 0.3s;
        }
        .login-button:hover {
            background: #1F5F6F;
        }
        .error {
            color: #d32f2f;
            font-size: 13px;
            margin-bottom: 16px;
            padding: 12px;
            background: #ffebee;
            border-radius: 4px;
            border-left: 3px solid #d32f2f;
        }
    </style>
</head>
<body>

<div class="container">
    <div class="left-section">
        <div class="welcome-content">
            <h1>Welcome Back</h1>
            <p>Sign in to continue managing church offerings with integrity, transparency, and faithful stewardship.</p>
        </div>
    </div>
    
    <div class="right-section">
        <div class="form-wrapper">
            <div class="form-header">
                <h2>LOGIN</h2>
            </div>
            
            <?php if (!empty($error)) echo "<p class='error'>$error</p>"; ?>

            <form method="POST">
                <div class="form-group">
                    <input type="email" name="email" placeholder="Email" required>
                </div>
                
                <div class="form-group">
                    <div class="password-wrapper">
                        <input type="password" id="password" name="password" placeholder="Password" required>
                        <button type="button" class="password-toggle" onclick="togglePassword()">👁</button>
                    </div>
                </div>
                
                <div class="forgot-password">
                    <a href="forgot_password.php">Forgot password?</a>
                </div>
                
                <button type="submit" name="login" class="login-button">Log In</button>
            </form>
        </div>
    </div>
</div>

<script>
function togglePassword() {
    const passwordInput = document.getElementById('password');
    const toggleButton = document.querySelector('.password-toggle');
    if (passwordInput.type === 'password') {
        passwordInput.type = 'text';
        toggleButton.textContent = '👁️';
    } else {
        passwordInput.type = 'password';
        toggleButton.textContent = '👁';
    }
}
</script>

</body>
</html>
