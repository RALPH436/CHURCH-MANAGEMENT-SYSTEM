<?php
session_start();
include "db.php";

if (!isset($_SESSION['user_id'])) {
    header('Content-Type: application/json');
    echo json_encode(['error' => 'Unauthorized']);
    exit();
}

// Initialize cleared notifications array in session if not exists
if (!isset($_SESSION['cleared_notifications'])) {
    $_SESSION['cleared_notifications'] = [];
}

// Get upcoming events for notifications (next 7 days)
$upcomingEventsList = [];
$eventsTableCheck = mysqli_query($conn, "SHOW TABLES LIKE 'events'");
if (mysqli_num_rows($eventsTableCheck) > 0) {
    $today = date('Y-m-d');
    $nextWeek = date('Y-m-d', strtotime('+7 days'));
    $eventsQuery = "SELECT * FROM events WHERE event_date >= '$today' AND event_date <= '$nextWeek' ORDER BY event_date ASC LIMIT 10";
    $eventsResult = mysqli_query($conn, $eventsQuery);
    if ($eventsResult) {
        while ($row = mysqli_fetch_assoc($eventsResult)) {
            // Generate notification ID for this event
            $notificationId = 'event_' . (isset($row['id']) ? $row['id'] : uniqid());
            // Only add if not cleared
            if (!in_array($notificationId, $_SESSION['cleared_notifications'])) {
                $upcomingEventsList[] = $row;
            }
        }
    }
}

// Get birthday celebrants (today and next 7 days)
$birthdayCelebrants = [];
$membersTableCheck = mysqli_query($conn, "SHOW TABLES LIKE 'members'");
if (mysqli_num_rows($membersTableCheck) > 0) {
    $todayFull = date('Y-m-d');
    $nextWeek = date('Y-m-d', strtotime('+7 days'));
    
    // Get members with birthdays in the next 7 days
    $birthdayQuery = "SELECT id, full_name, birthdate, profile_picture, status FROM members WHERE status = 'Active'";
    $birthdayResult = mysqli_query($conn, $birthdayQuery);
    if ($birthdayResult) {
        while ($member = mysqli_fetch_assoc($birthdayResult)) {
            $birthdate = $member['birthdate'];
            $birthMonthDay = date('m-d', strtotime($birthdate));
            
            // Check if birthday is today or in the next 7 days
            $currentYear = date('Y');
            $birthdayThisYear = $currentYear . '-' . $birthMonthDay;
            $birthdayDate = date('Y-m-d', strtotime($birthdayThisYear));
            
            // If birthday has passed this year, check next year
            if ($birthdayDate < $todayFull) {
                $nextYear = date('Y', strtotime('+1 year'));
                $birthdayThisYear = $nextYear . '-' . $birthMonthDay;
                $birthdayDate = date('Y-m-d', strtotime($birthdayThisYear));
            }
            
            // Check if birthday falls within the next 7 days
            if ($birthdayDate >= $todayFull && $birthdayDate <= $nextWeek) {
                // Generate notification ID for this birthday
                $notificationId = 'birthday_' . $member['id'];
                // Only add if not cleared
                if (!in_array($notificationId, $_SESSION['cleared_notifications'])) {
                    $daysUntil = (strtotime($birthdayDate) - strtotime($todayFull)) / (60 * 60 * 24);
                    $member['days_until'] = intval($daysUntil);
                    $member['birthday_date'] = $birthdayDate;
                    $birthdayCelebrants[] = $member;
                }
            }
        }
        
        // Sort by days until birthday
        usort($birthdayCelebrants, function($a, $b) {
            return $a['days_until'] - $b['days_until'];
        });
    }
}

// Format notifications for response
$notifications = [];

// Add events
foreach ($upcomingEventsList as $event) {
    $eventName = '';
    if (isset($event['event_name'])) {
        $eventName = htmlspecialchars($event['event_name']);
    } elseif (isset($event['title'])) {
        $eventName = htmlspecialchars($event['title']);
    } elseif (isset($event['name'])) {
        $eventName = htmlspecialchars($event['name']);
    } else {
        $eventName = 'Event';
    }
    
    $eventDate = isset($event['event_date']) ? $event['event_date'] : '';
    $daysUntil = 0;
    if ($eventDate) {
        $daysUntil = (strtotime($eventDate) - strtotime(date('Y-m-d'))) / (60 * 60 * 24);
    }
    
    $notifications[] = [
        'type' => 'event',
        'id' => 'event_' . (isset($event['id']) ? $event['id'] : uniqid()),
        'title' => 'Upcoming Event',
        'message' => $eventName,
        'date' => $eventDate,
        'days_until' => intval($daysUntil),
        'timestamp' => $eventDate ? strtotime($eventDate) : time(),
        'icon' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="#2D7A8F" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect><line x1="16" y1="2" x2="16" y2="6"></line><line x1="8" y1="2" x2="8" y2="6"></line><line x1="3" y1="10" x2="21" y2="10"></line></svg>'
    ];
}

// Add birthdays
foreach ($birthdayCelebrants as $celebrant) {
    $birthdate = new DateTime($celebrant['birthdate']);
    $today = new DateTime();
    $age = $today->diff($birthdate)->y;
    
    $notifications[] = [
        'type' => 'birthday',
        'id' => 'birthday_' . $celebrant['id'],
        'title' => 'Birthday Celebrant',
        'message' => htmlspecialchars($celebrant['full_name']) . ' is celebrating their birthday (turning ' . ($age + 1) . ')',
        'date' => $celebrant['birthday_date'],
        'days_until' => $celebrant['days_until'],
        'timestamp' => strtotime($celebrant['birthday_date']),
        'icon' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="#ff6b6b" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="12" width="20" height="8" rx="2" fill="#ff6b6b" opacity="0.2"></rect><rect x="4" y="8" width="16" height="6" rx="1" fill="#ff6b6b" opacity="0.3"></rect><line x1="6" y1="4" x2="6" y2="8" stroke="#ff6b6b"></line><line x1="10" y1="4" x2="10" y2="8" stroke="#ff6b6b"></line><line x1="14" y1="4" x2="14" y2="8" stroke="#ff6b6b"></line><line x1="18" y1="4" x2="18" y2="8" stroke="#ff6b6b"></line><circle cx="6" cy="3" r="1" fill="#ff6b6b"></circle><circle cx="10" cy="3" r="1" fill="#ff6b6b"></circle><circle cx="14" cy="3" r="1" fill="#ff6b6b"></circle><circle cx="18" cy="3" r="1" fill="#ff6b6b"></circle></svg>',
        'profile_picture' => $celebrant['profile_picture'] ?? null
    ];
}

// Sort by timestamp (soonest first)
usort($notifications, function($a, $b) {
    return $a['timestamp'] - $b['timestamp'];
});

header('Content-Type: application/json');
echo json_encode([
    'notifications' => $notifications,
    'count' => count($notifications)
]);
?>

