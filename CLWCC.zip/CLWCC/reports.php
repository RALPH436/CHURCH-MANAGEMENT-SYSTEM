<?php
session_start();
include "db.php";

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Get filter parameters
$report_type = isset($_GET['report_type']) ? mysqli_real_escape_string($conn, $_GET['report_type']) : 'financial';
$date_from = isset($_GET['date_from']) ? mysqli_real_escape_string($conn, $_GET['date_from']) : date('Y-m-01'); // First day of current month
$date_to = isset($_GET['date_to']) ? mysqli_real_escape_string($conn, $_GET['date_to']) : date('Y-m-t'); // Last day of current month

// Initialize data arrays
$financialData = [];
$attendanceData = [];
$memberData = [];

// Financial Report Data
if ($report_type == 'financial' || $report_type == 'all') {
    // Total offerings
    $offeringsTableCheck = mysqli_query($conn, "SHOW TABLES LIKE 'offerings'");
    if (mysqli_num_rows($offeringsTableCheck) > 0) {
        $offeringsQuery = "SELECT 
            COALESCE(SUM(amount), 0) as total,
            COUNT(*) as count,
            offering_type,
            DATE_FORMAT(offering_date, '%Y-%m') as month
            FROM offerings 
            WHERE offering_date >= '$date_from' AND offering_date <= '$date_to'
            GROUP BY offering_type, month
            ORDER BY month, offering_type";
        $offeringsResult = mysqli_query($conn, $offeringsQuery);
        
        $totalOfferings = 0;
        $offeringsByType = [];
        $monthlyOfferings = [];
        
        if ($offeringsResult) {
            while ($row = mysqli_fetch_assoc($offeringsResult)) {
                $totalOfferings += $row['total'];
                if (!isset($offeringsByType[$row['offering_type']])) {
                    $offeringsByType[$row['offering_type']] = 0;
                }
                $offeringsByType[$row['offering_type']] += $row['total'];
                
                if (!isset($monthlyOfferings[$row['month']])) {
                    $monthlyOfferings[$row['month']] = 0;
                }
                $monthlyOfferings[$row['month']] += $row['total'];
            }
        }
        
        // Get overall total
        $totalOfferingsQuery = "SELECT COALESCE(SUM(amount), 0) as total FROM offerings WHERE offering_date >= '$date_from' AND offering_date <= '$date_to'";
        $totalOfferingsResult = mysqli_query($conn, $totalOfferingsQuery);
        if ($totalOfferingsResult) {
            $totalOfferingsRow = mysqli_fetch_assoc($totalOfferingsResult);
            $totalOfferings = $totalOfferingsRow['total'];
        }
        
        $financialData['offerings'] = [
            'total' => $totalOfferings,
            'by_type' => $offeringsByType,
            'monthly' => $monthlyOfferings
        ];
    }
    
    // Total expenses
    $expensesTableCheck = mysqli_query($conn, "SHOW TABLES LIKE 'expenses'");
    if (mysqli_num_rows($expensesTableCheck) > 0) {
        $expensesQuery = "SELECT 
            COALESCE(SUM(amount), 0) as total,
            COUNT(*) as count,
            expense_type,
            DATE_FORMAT(expense_date, '%Y-%m') as month
            FROM expenses 
            WHERE expense_date >= '$date_from' AND expense_date <= '$date_to'
            GROUP BY expense_type, month
            ORDER BY month, expense_type";
        $expensesResult = mysqli_query($conn, $expensesQuery);
        
        $totalExpenses = 0;
        $expensesByType = [];
        $monthlyExpenses = [];
        
        if ($expensesResult) {
            while ($row = mysqli_fetch_assoc($expensesResult)) {
                $totalExpenses += $row['total'];
                if (!isset($expensesByType[$row['expense_type']])) {
                    $expensesByType[$row['expense_type']] = 0;
                }
                $expensesByType[$row['expense_type']] += $row['total'];
                
                if (!isset($monthlyExpenses[$row['month']])) {
                    $monthlyExpenses[$row['month']] = 0;
                }
                $monthlyExpenses[$row['month']] += $row['total'];
            }
        }
        
        // Get overall total
        $totalExpensesQuery = "SELECT COALESCE(SUM(amount), 0) as total FROM expenses WHERE expense_date >= '$date_from' AND expense_date <= '$date_to'";
        $totalExpensesResult = mysqli_query($conn, $totalExpensesQuery);
        if ($totalExpensesResult) {
            $totalExpensesRow = mysqli_fetch_assoc($totalExpensesResult);
            $totalExpenses = $totalExpensesRow['total'];
        }
        
        $financialData['expenses'] = [
            'total' => $totalExpenses,
            'by_type' => $expensesByType,
            'monthly' => $monthlyExpenses
        ];
    }
    
    // Net balance
    $financialData['net_balance'] = ($financialData['offerings']['total'] ?? 0) - ($financialData['expenses']['total'] ?? 0);
}

// Attendance Report Data
if ($report_type == 'attendance' || $report_type == 'all') {
    $attendanceTableCheck = mysqli_query($conn, "SHOW TABLES LIKE 'attendance'");
    if (mysqli_num_rows($attendanceTableCheck) > 0) {
        // Total attendance count
        $attendanceQuery = "SELECT 
            COUNT(DISTINCT member_id) as unique_members,
            COUNT(*) as total_records,
            DATE_FORMAT(attendance_date, '%Y-%m-%d') as date,
            DATE_FORMAT(attendance_date, '%Y-%m') as month
            FROM attendance 
            WHERE attendance_date >= '$date_from' AND attendance_date <= '$date_to'
            GROUP BY date
            ORDER BY date";
        $attendanceResult = mysqli_query($conn, $attendanceQuery);
        
        $dailyAttendance = [];
        $monthlyAttendance = [];
        $totalRecords = 0;
        $uniqueMembers = [];
        
        if ($attendanceResult) {
            while ($row = mysqli_fetch_assoc($attendanceResult)) {
                $dailyAttendance[$row['date']] = $row['unique_members'];
                $totalRecords += $row['total_records'];
                
                if (!isset($monthlyAttendance[$row['month']])) {
                    $monthlyAttendance[$row['month']] = 0;
                }
                $monthlyAttendance[$row['month']] += $row['unique_members'];
            }
        }
        
        // Get unique members who attended
        $uniqueMembersQuery = "SELECT COUNT(DISTINCT member_id) as count FROM attendance WHERE attendance_date >= '$date_from' AND attendance_date <= '$date_to'";
        $uniqueMembersResult = mysqli_query($conn, $uniqueMembersQuery);
        $uniqueMembersCount = 0;
        if ($uniqueMembersResult) {
            $uniqueMembersRow = mysqli_fetch_assoc($uniqueMembersResult);
            $uniqueMembersCount = $uniqueMembersRow['count'];
        }
        
        $attendanceData = [
            'total_records' => $totalRecords,
            'unique_members' => $uniqueMembersCount,
            'daily' => $dailyAttendance,
            'monthly' => $monthlyAttendance
        ];
    }
}

// Member Report Data
if ($report_type == 'members' || $report_type == 'all') {
    $membersTableCheck = mysqli_query($conn, "SHOW TABLES LIKE 'members'");
    if (mysqli_num_rows($membersTableCheck) > 0) {
        // Total members
        $totalMembersQuery = "SELECT COUNT(*) as total FROM members";
        $totalMembersResult = mysqli_query($conn, $totalMembersQuery);
        $totalMembers = 0;
        if ($totalMembersResult) {
            $totalMembersRow = mysqli_fetch_assoc($totalMembersResult);
            $totalMembers = $totalMembersRow['total'];
        }
        
        // Active members
        $activeMembersQuery = "SELECT COUNT(*) as total FROM members WHERE status = 'Active'";
        $activeMembersResult = mysqli_query($conn, $activeMembersQuery);
        $activeMembers = 0;
        if ($activeMembersResult) {
            $activeMembersRow = mysqli_fetch_assoc($activeMembersResult);
            $activeMembers = $activeMembersRow['total'];
        }
        
        // Inactive members
        $inactiveMembers = $totalMembers - $activeMembers;
        
        // Members by status
        $statusQuery = "SELECT status, COUNT(*) as count FROM members GROUP BY status";
        $statusResult = mysqli_query($conn, $statusQuery);
        $membersByStatus = [];
        if ($statusResult) {
            while ($row = mysqli_fetch_assoc($statusResult)) {
                $membersByStatus[$row['status']] = $row['count'];
            }
        }
        
        // New members in date range
        $newMembersQuery = "SELECT COUNT(*) as count FROM members WHERE created_at >= '$date_from' AND created_at <= '$date_to'";
        $newMembersResult = mysqli_query($conn, $newMembersQuery);
        $newMembers = 0;
        if ($newMembersResult) {
            $newMembersRow = mysqli_fetch_assoc($newMembersResult);
            $newMembers = $newMembersRow['count'];
        }
        
        $memberData = [
            'total' => $totalMembers,
            'active' => $activeMembers,
            'inactive' => $inactiveMembers,
            'by_status' => $membersByStatus,
            'new_in_period' => $newMembers
        ];
    }
}

// Get notification count
$notificationCount = 0;
$eventsTableCheck = mysqli_query($conn, "SHOW TABLES LIKE 'events'");
if (mysqli_num_rows($eventsTableCheck) > 0) {
    $today = date('Y-m-d');
    $nextWeek = date('Y-m-d', strtotime('+7 days'));
    $eventsQuery = "SELECT COUNT(*) as total FROM events WHERE event_date >= '$today' AND event_date <= '$nextWeek'";
    $eventsResult = mysqli_query($conn, $eventsQuery);
    if ($eventsResult && $row = mysqli_fetch_assoc($eventsResult)) {
        $notificationCount += $row['total'];
    }
}

$membersTableCheck = mysqli_query($conn, "SHOW TABLES LIKE 'members'");
if (mysqli_num_rows($membersTableCheck) > 0) {
    $todayFull = date('Y-m-d');
    $nextWeek = date('Y-m-d', strtotime('+7 days'));
    $birthdayQuery = "SELECT birthdate FROM members WHERE status = 'Active'";
    $birthdayResult = mysqli_query($conn, $birthdayQuery);
    if ($birthdayResult) {
        while ($member = mysqli_fetch_assoc($birthdayResult)) {
            $birthdate = $member['birthdate'];
            $birthMonthDay = date('m-d', strtotime($birthdate));
            $currentYear = date('Y');
            $birthdayThisYear = $currentYear . '-' . $birthMonthDay;
            $birthdayDate = date('Y-m-d', strtotime($birthdayThisYear));
            if ($birthdayDate < $todayFull) {
                $nextYear = date('Y', strtotime('+1 year'));
                $birthdayThisYear = $nextYear . '-' . $birthMonthDay;
                $birthdayDate = date('Y-m-d', strtotime($birthdayThisYear));
            }
            if ($birthdayDate >= $todayFull && $birthdayDate <= $nextWeek) {
                $notificationCount++;
            }
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Reports - Church Management</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        html, body {
            height: 100%;
            overflow: hidden;
        }
        body { 
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; 
            background: #f5f7fa;
            color: #333;
            position: relative;
        }
        .header {
            background: linear-gradient(135deg, #0a1929 0%, #1a2f4a 100%);
            color: white;
            padding: 0 30px;
            height: 70px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            width: 100%;
            z-index: 1000;
        }
        .header h1 {
            font-size: 24px;
            font-weight: 600;
            margin: 0;
            line-height: 1;
        }
        .header-right {
            display: flex;
            align-items: center;
            gap: 20px;
            height: 100%;
        }
        .user-info {
            display: flex;
            align-items: center;
            gap: 10px;
            height: 100%;
        }
        .user-name {
            font-size: 14px;
            font-weight: 500;
            margin: 0;
            line-height: 1;
        }
        .notification-icon {
            position: relative;
            cursor: pointer;
            padding: 8px;
            border-radius: 50%;
            transition: background-color 0.3s;
            display: flex;
            align-items: center;
            justify-content: center;
            width: 36px;
            height: 36px;
            text-decoration: none;
            color: white;
        }
        .notification-icon:hover {
            background: rgba(255, 255, 255, 0.1);
        }
        .notification-badge {
            position: absolute;
            top: 0;
            right: 0;
            background: #ff4444;
            color: white;
            border-radius: 50%;
            width: 20px;
            height: 20px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 11px;
            font-weight: 600;
            border: 2px solid #0a1929;
        }
        .notification-icon svg {
            width: 20px;
            height: 20px;
            stroke: white;
        }
        .notification-dropdown-container {
            position: relative;
        }
        .notification-dropdown {
            position: absolute;
            top: calc(100% + 10px);
            right: 0;
            width: 380px;
            max-height: 500px;
            background: white;
            border-radius: 8px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.15);
            z-index: 1001;
            display: none;
            overflow: hidden;
            animation: slideDown 0.2s ease-out;
        }
        @keyframes slideDown {
            from {
                opacity: 0;
                transform: translateY(-10px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        .notification-dropdown.active {
            display: block;
        }
        .notification-dropdown-header {
            padding: 15px 20px;
            border-bottom: 1px solid #e0e0e0;
            background: #f8f9fa;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .notification-dropdown-header h3 {
            margin: 0;
            font-size: 16px;
            font-weight: 600;
            color: #0a1929;
        }
        .notification-dropdown-close {
            background: none;
            border: none;
            font-size: 20px;
            cursor: pointer;
            color: #666;
            padding: 0;
            width: 24px;
            height: 24px;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 4px;
            transition: background 0.2s;
        }
        .notification-dropdown-close:hover {
            background: #e0e0e0;
        }
        .notification-dropdown-list {
            max-height: 400px;
            overflow-y: auto;
            overflow-x: hidden;
        }
        .notification-dropdown-list::-webkit-scrollbar {
            width: 6px;
        }
        .notification-dropdown-list::-webkit-scrollbar-track {
            background: #f1f1f1;
        }
        .notification-dropdown-list::-webkit-scrollbar-thumb {
            background: #888;
            border-radius: 3px;
        }
        .notification-dropdown-list::-webkit-scrollbar-thumb:hover {
            background: #555;
        }
        .notification-dropdown-item {
            padding: 12px 20px;
            border-bottom: 1px solid #f0f0f0;
            cursor: pointer;
            transition: background 0.2s;
            display: flex;
            align-items: flex-start;
            gap: 12px;
            position: relative;
        }
        .notification-dropdown-item:hover {
            background: #f8f9fa;
        }
        .notification-dropdown-item.read {
            opacity: 0.7;
            background: #fafafa;
        }
        .notification-dropdown-item.read:hover {
            background: #f0f0f0;
        }
        .notification-dropdown-item-icon {
            font-size: 24px;
            flex-shrink: 0;
            margin-top: 2px;
            display: inline-flex;
            align-items: center;
            justify-content: center;
        }
        .notification-dropdown-item-icon svg {
            width: 20px;
            height: 20px;
        }
        .notification-dropdown-item-content {
            flex: 1;
            min-width: 0;
        }
        .notification-dropdown-item-title {
            font-weight: 600;
            font-size: 14px;
            color: #0a1929;
            margin-bottom: 4px;
        }
        .notification-dropdown-item-message {
            font-size: 13px;
            color: #666;
            line-height: 1.4;
            margin-bottom: 6px;
            word-wrap: break-word;
        }
        .notification-dropdown-item-time {
            font-size: 11px;
            color: #999;
        }
        .notification-dropdown-item-profile {
            width: 36px;
            height: 36px;
            border-radius: 50%;
            object-fit: cover;
            border: 2px solid #e0e0e0;
            flex-shrink: 0;
        }
        .notification-dropdown-empty {
            padding: 40px 20px;
            text-align: center;
            color: #999;
            font-size: 14px;
        }
        .notification-dropdown-footer {
            padding: 12px 20px;
            border-top: 1px solid #e0e0e0;
            text-align: center;
            background: #f8f9fa;
        }
        .notification-dropdown-footer a {
            color: #2D7A8F;
            text-decoration: none;
            font-size: 13px;
            font-weight: 500;
        }
        .notification-dropdown-footer a:hover {
            text-decoration: underline;
        }
        @media (max-width: 768px) {
            .notification-dropdown {
                width: 320px;
                right: -10px;
            }
        }
        .logout-btn {
            background: #2D7A8F;
            color: white;
            padding: 8px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 14px;
            font-weight: 500;
            text-decoration: none;
            transition: background-color 0.3s;
        }
        .logout-btn:hover {
            background: #1F5F6F;
        }
        .container {
            display: flex;
            margin-top: 70px;
            height: calc(100vh - 70px);
            position: relative;
            overflow: hidden;
        }
        .sidebar {
            width: 260px;
            background: #fff;
            box-shadow: 2px 0 10px rgba(0, 0, 0, 0.05);
            position: fixed;
            left: 0;
            top: 70px;
            height: calc(100vh - 70px);
            overflow-y: auto;
            z-index: 999;
        }
        .sidebar-menu {
            list-style: none;
            padding: 20px 0;
        }
        .sidebar-menu li {
            margin-bottom: 5px;
        }
        .sidebar-menu a {
            display: flex;
            align-items: center;
            padding: 14px 25px;
            color: #555;
            text-decoration: none;
            font-size: 15px;
            font-weight: 500;
            transition: all 0.3s;
            border-left: 3px solid transparent;
        }
        .sidebar-menu a:hover {
            background: #f5f7fa;
            color: #2D7A8F;
            border-left-color: #2D7A8F;
        }
        .sidebar-menu a.active {
            background: #f0f8ff;
            color: #2D7A8F;
            border-left-color: #2D7A8F;
            font-weight: 600;
        }
        .sidebar-menu a .sidebar-icon {
            width: 18px;
            height: 18px;
            margin-right: 12px;
            flex-shrink: 0;
            stroke: currentColor;
            opacity: 0.7;
            transition: opacity 0.3s;
        }
        .sidebar-menu a:hover .sidebar-icon,
        .sidebar-menu a.active .sidebar-icon {
            opacity: 1;
        }
        .main-content {
            flex: 1;
            margin-left: 260px;
            padding: 30px;
            background: #f5f7fa;
            height: calc(100vh - 70px);
            overflow-y: auto;
            overflow-x: hidden;
        }
        .page-title {
            font-size: 28px;
            font-weight: 700;
            color: #0a1929;
            margin-bottom: 10px;
        }
        .page-subtitle {
            color: #666;
            font-size: 14px;
            margin-bottom: 30px;
        }
        .content-section {
            background: white;
            padding: 25px;
            border-radius: 8px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);
            margin-bottom: 20px;
        }
        .section-title {
            font-size: 18px;
            font-weight: 600;
            color: #0a1929;
            margin-bottom: 15px;
            padding-bottom: 10px;
            border-bottom: 2px solid #f0f0f0;
        }
        .filter-section {
            background: #f8f9fa;
            padding: 20px;
            border-radius: 8px;
            margin-bottom: 20px;
        }
        .filter-form {
            display: flex;
            gap: 15px;
            align-items: flex-end;
            flex-wrap: wrap;
        }
        .form-group {
            margin-bottom: 0;
        }
        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 500;
            color: #333;
            font-size: 14px;
        }
        .form-group select,
        .form-group input {
            padding: 10px 12px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 14px;
            font-family: inherit;
            transition: border-color 0.3s;
        }
        .form-group select:focus,
        .form-group input:focus {
            outline: none;
            border-color: #2D7A8F;
        }
        .btn {
            padding: 10px 24px;
            border: none;
            border-radius: 4px;
            font-size: 14px;
            font-weight: 500;
            cursor: pointer;
            transition: background-color 0.3s;
            text-decoration: none;
            display: inline-block;
        }
        .btn-primary {
            background: #2D7A8F;
            color: white;
        }
        .btn-primary:hover {
            background: #1F5F6F;
        }
        .btn-success {
            background: #4caf50;
            color: white;
        }
        .btn-success:hover {
            background: #2e7d32;
        }
        .report-cards {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }
        .report-card {
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);
            border-left: 4px solid #2D7A8F;
        }
        .report-card-title {
            font-size: 13px;
            color: #888;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            margin-bottom: 10px;
        }
        .report-card-value {
            font-size: 28px;
            font-weight: 700;
            color: #0a1929;
        }
        .report-card.positive .report-card-value {
            color: #2e7d32;
        }
        .report-card.negative .report-card-value {
            color: #d32f2f;
        }
        .chart-wrapper {
            background: white;
            padding: 25px;
            border-radius: 8px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);
            margin-bottom: 20px;
        }
        .chart-title {
            font-size: 16px;
            font-weight: 600;
            color: #0a1929;
            margin-bottom: 15px;
            text-align: center;
        }
        .chart-container {
            position: relative;
            height: 300px;
        }
        .charts-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 20px;
        }
        @media (max-width: 968px) {
            .charts-grid {
                grid-template-columns: 1fr;
            }
        }
        .data-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        .data-table th,
        .data-table td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #e0e0e0;
        }
        .data-table th {
            background: #f5f7fa;
            font-weight: 600;
            color: #0a1929;
            font-size: 13px;
            text-transform: uppercase;
        }
        .data-table td {
            font-size: 14px;
            color: #555;
        }
        .data-table tr:hover {
            background: #f9f9f9;
        }
        .export-buttons {
            display: flex;
            gap: 10px;
            margin-top: 20px;
            flex-wrap: wrap;
        }
        @media (max-width: 768px) {
            .sidebar {
                width: 100%;
                position: relative;
                top: 0;
                height: auto;
            }
            .main-content {
                margin-left: 0;
            }
            .container {
                flex-direction: column;
            }
            .header {
                flex-direction: column;
                gap: 15px;
                padding: 15px;
            }
            .filter-form {
                flex-direction: column;
                align-items: stretch;
            }
        }
    </style>
</head>
<body>

<div class="header">
    <h1>Church Management System</h1>
    <div class="header-right">
        <div class="notification-dropdown-container">
            <div class="notification-icon" id="notificationIcon" onclick="toggleNotificationDropdown(event)" title="View Notifications">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"></path>
                    <path d="M13.73 21a2 2 0 0 1-3.46 0"></path>
                </svg>
                <?php if ($notificationCount > 0): ?>
                    <span class="notification-badge" id="notificationBadge"><?php echo $notificationCount; ?></span>
                <?php endif; ?>
            </div>
            <div class="notification-dropdown" id="notificationDropdown">
                <div class="notification-dropdown-header">
                    <h3>Notifications</h3>
                    <button class="notification-dropdown-close" onclick="closeNotificationDropdown()" title="Close">×</button>
                </div>
                <div class="notification-dropdown-list" id="notificationDropdownList">
                    <div class="notification-dropdown-empty">Loading notifications...</div>
                </div>
                <div class="notification-dropdown-footer">
                    <a href="dashboard.php#notifications-section" onclick="closeNotificationDropdown();">View All Notifications</a>
                </div>
            </div>
        </div>
        <div class="user-info">
            <span class="user-name">Welcome, <?php echo htmlspecialchars($_SESSION['fullname']); ?></span>
        </div>
        <a href="logout.php" class="logout-btn">Logout</a>
    </div>
</div>

<div class="container">
    <aside class="sidebar">
        <ul class="sidebar-menu">
            <li><a href="dashboard.php">
                <svg class="sidebar-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="7" height="7"></rect><rect x="14" y="3" width="7" height="7"></rect><rect x="14" y="14" width="7" height="7"></rect><rect x="3" y="14" width="7" height="7"></rect></svg>
                Dashboard</a></li>
            <li><a href="members.php">
                <svg class="sidebar-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path><circle cx="9" cy="7" r="4"></circle><path d="M23 21v-2a4 4 0 0 0-3-3.87"></path><path d="M16 3.13a4 4 0 0 1 0 7.75"></path></svg>
                Members</a></li>
            <li><a href="attendance.php">
                <svg class="sidebar-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path><polyline points="14 2 14 8 20 8"></polyline><line x1="16" y1="13" x2="8" y2="13"></line><line x1="16" y1="17" x2="8" y2="17"></line><polyline points="10 9 9 9 8 9"></line></svg>
                Attendance</a></li>
            <li><a href="offerings.php">
                <svg class="sidebar-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="12" y1="1" x2="12" y2="23"></line><path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"></path></svg>
                Offerings</a></li>
            <li><a href="expenses.php">
                <svg class="sidebar-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path><polyline points="14 2 14 8 20 8"></polyline><line x1="16" y1="13" x2="8" y2="13"></line><line x1="16" y1="17" x2="8" y2="17"></line></svg>
                Expenses</a></li>
            <li><a href="events.php">
                <svg class="sidebar-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect><line x1="16" y1="2" x2="16" y2="6"></line><line x1="8" y1="2" x2="8" y2="6"></line><line x1="3" y1="10" x2="21" y2="10"></line></svg>
                Events</a></li>
            <li><a href="reports.php" class="active">
                <svg class="sidebar-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="20" x2="18" y2="10"></line><line x1="12" y1="20" x2="12" y2="4"></line><line x1="6" y1="20" x2="6" y2="14"></line></svg>
                Reports</a></li>
            <li><a href="users.php">
                <svg class="sidebar-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path><circle cx="12" cy="7" r="4"></circle></svg>
                Users</a></li>
        </ul>
    </aside>

    <main class="main-content">
        <h2 class="page-title">Reports</h2>
        <p class="page-subtitle">View comprehensive reports and analytics</p>

        <!-- Filter Section -->
        <div class="filter-section">
            <form method="GET" action="reports.php" class="filter-form">
                <div class="form-group">
                    <label for="report_type">Report Type</label>
                    <select id="report_type" name="report_type">
                        <option value="all" <?php echo $report_type == 'all' ? 'selected' : ''; ?>>All Reports</option>
                        <option value="financial" <?php echo $report_type == 'financial' ? 'selected' : ''; ?>>Financial</option>
                        <option value="attendance" <?php echo $report_type == 'attendance' ? 'selected' : ''; ?>>Attendance</option>
                        <option value="members" <?php echo $report_type == 'members' ? 'selected' : ''; ?>>Members</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="date_from">From Date</label>
                    <input type="date" id="date_from" name="date_from" value="<?php echo htmlspecialchars($date_from); ?>" required>
                </div>
                <div class="form-group">
                    <label for="date_to">To Date</label>
                    <input type="date" id="date_to" name="date_to" value="<?php echo htmlspecialchars($date_to); ?>" required>
                </div>
                <div class="form-group">
                    <button type="submit" class="btn btn-primary">Generate Report</button>
                </div>
            </form>
        </div>

        <!-- Financial Report -->
        <?php if ($report_type == 'financial' || $report_type == 'all'): ?>
        <div class="content-section">
            <h3 class="section-title">Financial Report</h3>
            
            <div class="report-cards">
                <div class="report-card positive">
                    <div class="report-card-title">Total Offerings</div>
                    <div class="report-card-value">₱<?php echo number_format($financialData['offerings']['total'] ?? 0, 2); ?></div>
                </div>
                <div class="report-card negative">
                    <div class="report-card-title">Total Expenses</div>
                    <div class="report-card-value">₱<?php echo number_format($financialData['expenses']['total'] ?? 0, 2); ?></div>
                </div>
                <div class="report-card <?php echo ($financialData['net_balance'] ?? 0) >= 0 ? 'positive' : 'negative'; ?>">
                    <div class="report-card-title">Net Balance</div>
                    <div class="report-card-value">₱<?php echo number_format($financialData['net_balance'] ?? 0, 2); ?></div>
                </div>
            </div>

            <div class="charts-grid">
                <?php if (!empty($financialData['offerings']['by_type'])): ?>
                <div class="chart-wrapper">
                    <h4 class="chart-title">Offerings by Type</h4>
                    <div class="chart-container">
                        <canvas id="offeringsByTypeChart"></canvas>
                    </div>
                </div>
                <?php endif; ?>
                
                <?php if (!empty($financialData['expenses']['by_type'])): ?>
                <div class="chart-wrapper">
                    <h4 class="chart-title">Expenses by Type</h4>
                    <div class="chart-container">
                        <canvas id="expensesByTypeChart"></canvas>
                    </div>
                </div>
                <?php endif; ?>
            </div>

            <?php if (!empty($financialData['offerings']['monthly']) || !empty($financialData['expenses']['monthly'])): ?>
            <div class="chart-wrapper">
                <h4 class="chart-title">Monthly Financial Overview</h4>
                <div class="chart-container">
                    <canvas id="monthlyFinancialChart"></canvas>
                </div>
            </div>
            <?php endif; ?>

            <div class="export-buttons">
                <a href="export_report.php?type=financial&from=<?php echo urlencode($date_from); ?>&to=<?php echo urlencode($date_to); ?>&format=csv" class="btn btn-success">Export Financial Report (CSV)</a>
                <a href="export_report.php?type=financial&from=<?php echo urlencode($date_from); ?>&to=<?php echo urlencode($date_to); ?>&format=excel" class="btn btn-success">Export Financial Report (Excel)</a>
            </div>
        </div>
        <?php endif; ?>

        <!-- Attendance Report -->
        <?php if ($report_type == 'attendance' || $report_type == 'all'): ?>
        <div class="content-section">
            <h3 class="section-title">Attendance Report</h3>
            
            <div class="report-cards">
                <div class="report-card">
                    <div class="report-card-title">Total Attendance Records</div>
                    <div class="report-card-value"><?php echo number_format($attendanceData['total_records'] ?? 0); ?></div>
                </div>
                <div class="report-card">
                    <div class="report-card-title">Unique Members Attended</div>
                    <div class="report-card-value"><?php echo number_format($attendanceData['unique_members'] ?? 0); ?></div>
                </div>
            </div>

            <?php if (!empty($attendanceData['daily'])): ?>
            <div class="chart-wrapper">
                <h4 class="chart-title">Daily Attendance Trend</h4>
                <div class="chart-container">
                    <canvas id="dailyAttendanceChart"></canvas>
                </div>
            </div>
            <?php endif; ?>

            <?php if (!empty($attendanceData['monthly'])): ?>
            <div class="chart-wrapper">
                <h4 class="chart-title">Monthly Attendance Summary</h4>
                <div class="chart-container">
                    <canvas id="monthlyAttendanceChart"></canvas>
                </div>
            </div>
            <?php endif; ?>

            <div class="export-buttons">
                <a href="export_report.php?type=attendance&from=<?php echo urlencode($date_from); ?>&to=<?php echo urlencode($date_to); ?>&format=csv" class="btn btn-success">Export Attendance Report (CSV)</a>
            </div>
        </div>
        <?php endif; ?>

        <!-- Member Report -->
        <?php if ($report_type == 'members' || $report_type == 'all'): ?>
        <div class="content-section">
            <h3 class="section-title">Member Report</h3>
            
            <div class="report-cards">
                <div class="report-card">
                    <div class="report-card-title">Total Members</div>
                    <div class="report-card-value"><?php echo number_format($memberData['total'] ?? 0); ?></div>
                </div>
                <div class="report-card positive">
                    <div class="report-card-title">Active Members</div>
                    <div class="report-card-value"><?php echo number_format($memberData['active'] ?? 0); ?></div>
                </div>
                <div class="report-card">
                    <div class="report-card-title">Inactive Members</div>
                    <div class="report-card-value"><?php echo number_format($memberData['inactive'] ?? 0); ?></div>
                </div>
                <div class="report-card">
                    <div class="report-card-title">New Members (Period)</div>
                    <div class="report-card-value"><?php echo number_format($memberData['new_in_period'] ?? 0); ?></div>
                </div>
            </div>

            <?php if (!empty($memberData['by_status'])): ?>
            <div class="chart-wrapper">
                <h4 class="chart-title">Members by Status</h4>
                <div class="chart-container">
                    <canvas id="membersByStatusChart"></canvas>
                </div>
            </div>
            <?php endif; ?>

            <div class="export-buttons">
                <a href="export_report.php?type=members&from=<?php echo urlencode($date_from); ?>&to=<?php echo urlencode($date_to); ?>&format=csv" class="btn btn-success">Export Member Report (CSV)</a>
            </div>
        </div>
        <?php endif; ?>
    </main>
</div>

<script>
// Notification Dropdown Functions
let notificationDropdownOpen = false;
let readNotifications = JSON.parse(localStorage.getItem('readNotifications') || '[]');

function toggleNotificationDropdown(event) {
    event.stopPropagation();
    const dropdown = document.getElementById('notificationDropdown');
    
    if (dropdown.classList.contains('active')) {
        closeNotificationDropdown();
    } else {
        dropdown.classList.add('active');
        notificationDropdownOpen = true;
        loadNotifications();
    }
}

function closeNotificationDropdown() {
    const dropdown = document.getElementById('notificationDropdown');
    dropdown.classList.remove('active');
    notificationDropdownOpen = false;
}

function loadNotifications() {
    const list = document.getElementById('notificationDropdownList');
    
    fetch('get_notifications.php')
        .then(response => response.json())
        .then(data => {
            if (data.error) {
                list.innerHTML = '<div class="notification-dropdown-empty">Error loading notifications</div>';
            } else {
                renderNotifications(data.notifications);
            }
        })
        .catch(error => {
            console.error('Error:', error);
            list.innerHTML = '<div class="notification-dropdown-empty">Error loading notifications</div>';
        });
}

function renderNotifications(notifications) {
    const list = document.getElementById('notificationDropdownList');
    
    if (!notifications || notifications.length === 0) {
        list.innerHTML = '<div class="notification-dropdown-empty">No notifications at this time.</div>';
        return;
    }
    
    list.innerHTML = notifications.map(notif => {
        const isRead = readNotifications.includes(notif.id);
        const timeAgo = formatTimeAgo(notif.timestamp, notif.days_until);
        const profileImg = notif.profile_picture && notif.profile_picture.trim() !== '' 
            ? `<img src="${escapeHtml(notif.profile_picture)}" alt="Profile" class="notification-dropdown-item-profile" onerror="this.style.display='none'">`
            : '';
        
        return `
            <div class="notification-dropdown-item ${isRead ? 'read' : ''}" 
                 onclick="markNotificationAsRead('${notif.id}', this)" 
                 data-notification-id="${notif.id}">
                <span class="notification-dropdown-item-icon">${notif.icon}</span>
                ${profileImg}
                <div class="notification-dropdown-item-content">
                    <div class="notification-dropdown-item-title">${escapeHtml(notif.title)}</div>
                    <div class="notification-dropdown-item-message">${escapeHtml(notif.message)}</div>
                    <div class="notification-dropdown-item-time">${timeAgo}</div>
                </div>
            </div>
        `;
    }).join('');
}

function markNotificationAsRead(notificationId, element) {
    if (!readNotifications.includes(notificationId)) {
        readNotifications.push(notificationId);
        localStorage.setItem('readNotifications', JSON.stringify(readNotifications));
        element.classList.add('read');
        updateNotificationBadge();
    }
}

function formatTimeAgo(timestamp, daysUntil) {
    const now = Math.floor(Date.now() / 1000);
    const diff = timestamp - now;
    const days = Math.floor(diff / 86400);
    
    if (days < 0) {
        return 'Past';
    } else if (days === 0) {
        return 'Today';
    } else if (days === 1) {
        return 'Tomorrow';
    } else {
        return `In ${days} days`;
    }
}

function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

function updateNotificationBadge() {
    const badge = document.getElementById('notificationBadge');
    if (!badge) return;
    
    const allItems = document.querySelectorAll('.notification-dropdown-item');
    const unreadCount = Array.from(allItems).filter(item => !item.classList.contains('read')).length;
    
    if (unreadCount > 0) {
        badge.textContent = unreadCount;
        badge.style.display = 'flex';
    } else {
        badge.style.display = 'none';
    }
}

// Close dropdown when clicking outside
document.addEventListener('click', function(event) {
    const container = document.querySelector('.notification-dropdown-container');
    if (container && !container.contains(event.target) && notificationDropdownOpen) {
        closeNotificationDropdown();
    }
});

// Charts
<?php if (!empty($financialData['offerings']['by_type'])): ?>
const offeringsByTypeCtx = document.getElementById('offeringsByTypeChart');
if (offeringsByTypeCtx) {
    new Chart(offeringsByTypeCtx.getContext('2d'), {
        type: 'pie',
        data: {
            labels: <?php echo json_encode(array_keys($financialData['offerings']['by_type'])); ?>,
            datasets: [{
                data: <?php echo json_encode(array_values($financialData['offerings']['by_type'])); ?>,
                backgroundColor: [
                    'rgba(45, 122, 143, 0.8)',
                    'rgba(26, 47, 74, 0.8)',
                    'rgba(76, 175, 80, 0.8)',
                    'rgba(255, 152, 0, 0.8)',
                    'rgba(156, 39, 176, 0.8)'
                ]
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false
        }
    });
}
<?php endif; ?>

<?php if (!empty($financialData['expenses']['by_type'])): ?>
const expensesByTypeCtx = document.getElementById('expensesByTypeChart');
if (expensesByTypeCtx) {
    new Chart(expensesByTypeCtx.getContext('2d'), {
        type: 'pie',
        data: {
            labels: <?php echo json_encode(array_keys($financialData['expenses']['by_type'])); ?>,
            datasets: [{
                data: <?php echo json_encode(array_values($financialData['expenses']['by_type'])); ?>,
                backgroundColor: [
                    'rgba(211, 47, 47, 0.8)',
                    'rgba(244, 67, 54, 0.8)',
                    'rgba(229, 57, 53, 0.8)',
                    'rgba(198, 40, 40, 0.8)',
                    'rgba(183, 28, 28, 0.8)'
                ]
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false
        }
    });
}
<?php endif; ?>

<?php if (!empty($financialData['offerings']['monthly']) || !empty($financialData['expenses']['monthly'])): ?>
const monthlyFinancialCtx = document.getElementById('monthlyFinancialChart');
if (monthlyFinancialCtx) {
    const offeringsMonthly = <?php echo json_encode($financialData['offerings']['monthly'] ?? []); ?>;
    const expensesMonthly = <?php echo json_encode($financialData['expenses']['monthly'] ?? []); ?>;
    const allMonths = [...new Set([
        ...Object.keys(offeringsMonthly),
        ...Object.keys(expensesMonthly)
    ])].sort();
    
    new Chart(monthlyFinancialCtx.getContext('2d'), {
        type: 'bar',
        data: {
            labels: allMonths.map(m => {
                const [year, month] = m.split('-');
                return new Date(year, month - 1).toLocaleDateString('en-US', { month: 'short', year: 'numeric' });
            }),
            datasets: [
                {
                    label: 'Offerings',
                    data: allMonths.map(m => offeringsMonthly[m] || 0),
                    backgroundColor: 'rgba(76, 175, 80, 0.8)'
                },
                {
                    label: 'Expenses',
                    data: allMonths.map(m => expensesMonthly[m] || 0),
                    backgroundColor: 'rgba(211, 47, 47, 0.8)'
                }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        callback: function(value) {
                            return '₱' + value.toLocaleString();
                        }
                    }
                }
            }
        }
    });
}
<?php endif; ?>

<?php if (!empty($attendanceData['daily'])): ?>
const dailyAttendanceCtx = document.getElementById('dailyAttendanceChart');
if (dailyAttendanceCtx) {
    const dailyData = <?php echo json_encode($attendanceData['daily']); ?>;
    const dates = Object.keys(dailyData).sort();
    
    new Chart(dailyAttendanceCtx.getContext('2d'), {
        type: 'line',
        data: {
            labels: dates.map(d => new Date(d).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })),
            datasets: [{
                label: 'Daily Attendance',
                data: dates.map(d => dailyData[d]),
                borderColor: 'rgba(45, 122, 143, 1)',
                backgroundColor: 'rgba(45, 122, 143, 0.1)',
                tension: 0.4
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        stepSize: 1
                    }
                }
            }
        }
    });
}
<?php endif; ?>

<?php if (!empty($attendanceData['monthly'])): ?>
const monthlyAttendanceCtx = document.getElementById('monthlyAttendanceChart');
if (monthlyAttendanceCtx) {
    const monthlyData = <?php echo json_encode($attendanceData['monthly']); ?>;
    const months = Object.keys(monthlyData).sort();
    
    new Chart(monthlyAttendanceCtx.getContext('2d'), {
        type: 'bar',
        data: {
            labels: months.map(m => {
                const [year, month] = m.split('-');
                return new Date(year, month - 1).toLocaleDateString('en-US', { month: 'short', year: 'numeric' });
            }),
            datasets: [{
                label: 'Monthly Attendance',
                data: months.map(m => monthlyData[m]),
                backgroundColor: 'rgba(45, 122, 143, 0.8)'
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        stepSize: 1
                    }
                }
            }
        }
    });
}
<?php endif; ?>

<?php if (!empty($memberData['by_status'])): ?>
const membersByStatusCtx = document.getElementById('membersByStatusChart');
if (membersByStatusCtx) {
    new Chart(membersByStatusCtx.getContext('2d'), {
        type: 'doughnut',
        data: {
            labels: <?php echo json_encode(array_keys($memberData['by_status'])); ?>,
            datasets: [{
                data: <?php echo json_encode(array_values($memberData['by_status'])); ?>,
                backgroundColor: [
                    'rgba(76, 175, 80, 0.8)',
                    'rgba(158, 158, 158, 0.8)',
                    'rgba(255, 152, 0, 0.8)'
                ]
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false
        }
    });
}
<?php endif; ?>

// Load notifications on page load
document.addEventListener('DOMContentLoaded', function() {
    fetch('get_notifications.php')
        .then(response => response.json())
        .then(data => {
            if (!data.error && data.notifications) {
                const unreadCount = data.notifications.filter(n => !readNotifications.includes(n.id)).length;
                const badge = document.getElementById('notificationBadge');
                if (badge) {
                    if (unreadCount > 0) {
                        badge.textContent = unreadCount;
                        badge.style.display = 'flex';
                    } else {
                        badge.style.display = 'none';
                    }
                }
            }
        })
        .catch(error => console.error('Error loading notifications:', error));
});
</script>

</body>
</html>

